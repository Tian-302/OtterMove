import Foundation

@main
@MainActor
struct CoreChecks {
    static func require(_ condition: @autoclosure () -> Bool, _ message: String) {
        guard condition() else { fatalError(message) }
    }

    static func main() throws {
        let start = Date(timeIntervalSince1970: 1_000)
        var clock = SessionProgress(seconds: 20)
        clock.resume(at: start)
        clock.tick(at: start.addingTimeInterval(2.2))
        require(clock.remaining == 18, "Countdown rounds up fractional seconds")
        clock.pause(at: start.addingTimeInterval(3))
        clock.tick(at: start.addingTimeInterval(80))
        require(clock.elapsed == 3 && !clock.running, "Paused time must not count")
        clock.resume(at: start.addingTimeInterval(100))
        clock.resume(at: start.addingTimeInterval(101))
        clock.tick(at: start.addingTimeInterval(102))
        require(clock.elapsed == 5, "Resuming twice must not restart the time anchor")
        clock.tick(at: start.addingTimeInterval(101))
        clock.tick(at: start.addingTimeInterval(103))
        require(clock.elapsed == 6, "A backwards clock jump must not double-count time")
        clock.tick(at: start.addingTimeInterval(200))
        require(clock.isFinished && clock.remaining == 0 && !clock.running, "Overshoot clamps at duration")
        clock.resume(at: start.addingTimeInterval(300))
        require(!clock.running, "Completed timers cannot restart")

        require(Set(Activity.all.map(\.id)).count == 9, "Each action needs a unique stable ID")
        for place in Place.allCases {
            let actions = Activity.list(for: place)
            require(actions.map(\.order) == [0, 1, 2], "Each place has a complete three-action unlock chain")
            require(Activity.next(after: actions[2]) == nil, "No dangling final unlock")
        }
        let layout = Furniture.all.map {
            FurniturePlacement(id: $0.id, x: $0.defaultX, z: $0.defaultZ, turns: 0)
        }
        require(layout.allSatisfy { Furniture.canPlace($0, in: layout) }, "Default furniture positions fit together")
        let rotatedDesk = FurniturePlacement(id: "desk", x: -0.65, z: -1.08, turns: 1)
        require(!Furniture.canPlace(rotatedDesk, in: []), "Rotation must check the changed footprint")
        let rug = FurniturePlacement(id: "rug", x: 0, z: 0.1, turns: 0)
        let plant = FurniturePlacement(id: "plant", x: 0, z: 0.1, turns: 0)
        require(Furniture.canPlace(plant, in: [rug]), "A rug is a floor layer")
        let overlap = FurniturePlacement(id: "chair", x: 0, z: 0.1, turns: 0)
        require(!Furniture.canPlace(overlap, in: [plant]), "Solid furniture cannot overlap")

        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let file = directory.appendingPathComponent("profile-v2.json")
        try JSONEncoder().encode(SavedProfile()).write(to: file)
        let store = AppStore(directory: directory)
        require(store.stars == 0 && store.unlockedIDs.count == 3, "Clean profile starts with three actions")
        require(store.setState(place: .outdoor, energy: .ready), "State is persisted")
        let first = Activity.list(for: .library)[0]
        let second = Activity.list(for: .library)[1]
        let third = Activity.list(for: .library)[2]
        require(store.finishExercise(id: UUID(), activity: second, seconds: 20, complete: true) == nil,
                "Locked actions cannot mint rewards")
        let session = UUID()
        let reward = store.finishExercise(id: session, activity: first, seconds: 20, complete: true)
        require(reward?.newActivity == second && store.stars == 1, "Completion unlocks the next action")
        require(reward?.furniture.first?.id == "plant", "A crossed furniture threshold grants ownership")
        require(store.finishExercise(id: session, activity: first, seconds: 20, complete: true) == nil && store.stars == 1,
                "A duplicate session must not mint another star")
        let partial = store.finishExercise(id: UUID(), activity: second, seconds: 3, complete: false)
        require(partial?.newActivity == nil && store.stars == 1 && !store.isUnlocked(third),
                "Early exits keep their time without stars or unlocks")
        let repeatReward = store.finishExercise(id: UUID(), activity: first, seconds: 20, complete: true)
        require(repeatReward?.newActivity == nil && store.stars == 2, "Repeat completion cannot re-unlock the same action")
        let nextReward = store.finishExercise(id: UUID(), activity: second, seconds: 20, complete: true)
        require(nextReward?.newActivity == third && store.stars == 3, "Second completion advances the chain")
        require(nextReward?.furniture.first?.id == "desk", "Desk is unlocked at three stars")
        require(store.checkin() && store.checkin() && store.profile.checkins.count == 1 && store.stars == 3,
                "Daily check-in is idempotent and grants no stars")
        let meditation = UUID()
        require(store.finishMeditation(id: meditation, seconds: 30), "Meditation is recorded")
        require(store.finishMeditation(id: meditation, seconds: 30) && store.stars == 3,
                "Meditation retry is idempotent and grants no stars")
        let recordsBefore = store.profile.records.count
        require(recordsBefore == 5, "Expected four exercise records and one meditation record")
        require(store.saveRoom([rug, plant]), "Valid user layout is persisted")
        let invalid = FurniturePlacement(id: "desk", x: 5, z: 0, turns: 0)
        require(!store.saveRoom([invalid]) && store.profile.placements == [rug, plant], "Invalid layout cannot replace saved data")
        let reloaded = AppStore(directory: directory)
        require(reloaded.stars == 3 && reloaded.profile.records.count == recordsBefore &&
                reloaded.profile.place == .outdoor && reloaded.profile.placements == [rug, plant],
                "State, history, unlocks and layout survive reloading")

        require(reloaded.profile.care == nil, "A v0.2 file opens without a care field")
        let today = Date()
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: today)!
        require(reloaded.toggleCare(.water, on: today) == .completed(earnedStar: true), "First daily check-in grants a star")
        require(reloaded.toggleCare(.water, on: today) == .removed, "Check-ins can be corrected")
        require(reloaded.toggleCare(.water, on: today) == .completed(earnedStar: false), "Corrections cannot repeat a reward")
        for habit in CareHabit.allCases where habit != .water {
            require(reloaded.toggleCare(habit, on: today) == .completed(earnedStar: true), "Other habits reward independently")
        }
        require(reloaded.careDay(on: today).completed.count == 6 && reloaded.stars == 9, "Six check-in stars share the furniture balance")
        require(reloaded.toggleCare(.water, on: yesterday) == .completed(earnedStar: true), "Another date has an independent ledger")
        reloaded.setCups(3, on: today)
        require(reloaded.configureCare(goal: 4, showsSleep: true), "Care preferences save")
        require(reloaded.setSleep(7.5, on: today), "Optional sleep record saves")
        require(reloaded.addHabit("课间走一走"), "Custom habit saves")
        let habit = reloaded.care.customHabits[0]
        require(reloaded.toggleCustomHabit(habit, on: today) == .completed(earnedStar: false), "Custom check-in does not raise the six-star limit")
        reloaded.removeHabit(habit.id)
        let restoredCare = AppStore(directory: directory)
        require(restoredCare.stars == 10 && restoredCare.care.waterGoal == 4 &&
                restoredCare.careDay(on: today).cups == 3 && restoredCare.careDay(on: today).sleepHours == 7.5 &&
                restoredCare.careDay(on: today).customDone[habit.id] == habit.title, "Care data and history survive reloading")
        require(restoredCare.careDay(on: yesterday).cups == 0, "Cup counts are independent per day")
        require(Activity.next(after: .careStretch) == nil, "Short care stretch is independent of regular unlock chains")
        let short = restoredCare.finishExercise(id: UUID(), activity: .careStretch, seconds: 60, complete: true)
        require(short != nil && short?.newActivity == nil && restoredCare.stars == 11, "Short stretch is a valid exercise session")

        let suiteName = "OtterMove-checks-" + UUID().uuidString
        guard let defaults = UserDefaults(suiteName: suiteName) else { fatalError("Unable to create test preferences") }
        defer { defaults.removePersistentDomain(forName: suiteName) }
        let mood = MoodStore(defaults: defaults)
        require(mood.save(.happy, summary: "开心的一天", date: today), "A mood saves for today")
        let firstMoodID = mood.record(for: today)?.id
        require(mood.save(.relaxed, summary: "慢慢来", date: today), "A mood can be replaced the same day")
        require(mood.save(.tired, summary: "好好休息", date: yesterday), "Different days retain independent moods")
        let restoredMood = MoodStore(defaults: defaults)
        require(restoredMood.history.count == 2 && restoredMood.record(for: today)?.id == firstMoodID &&
                restoredMood.record(for: today)?.mood == .relaxed && restoredMood.record(for: yesterday)?.mood == .tired,
                "Same-day replacement and separate days persist correctly")
        require(MoodType.relaxed.summary(excluding: MoodType.relaxed.summaries[0]) != MoodType.relaxed.summaries[0],
                "Changing a summary produces a different sentence")

        let broken = Data("invalid JSON".utf8)
        try broken.write(to: file)
        let damaged = AppStore(directory: directory)
        damaged.errorMessage = nil
        require(!damaged.checkin(), "Dismissing a read error cannot enable overwrite")
        let stillBroken = try Data(contentsOf: file)
        require(stillBroken == broken, "Unreadable user data must be preserved")
        print("Core checks passed: timers, unlocks, rewards, history, room layout, and persistence.")
    }
}
