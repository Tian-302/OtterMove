#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
check_dir="$(mktemp -d)"
trap 'rm -rf "$check_dir"' EXIT
xcrun swiftc -parse-as-library \
    "$project_dir/OtterMove/Activities.swift" "$project_dir/OtterMove/AppStore.swift" \
    "$project_dir/OtterMove/CareData.swift" "$project_dir/OtterMove/MoodType.swift" \
    "$project_dir/OtterMove/MoodRecord.swift" "$project_dir/OtterMove/MoodStore.swift" \
    "$project_dir/Tests/CoreChecks.swift" -o "$check_dir/corechecks"
"$check_dir/corechecks"
