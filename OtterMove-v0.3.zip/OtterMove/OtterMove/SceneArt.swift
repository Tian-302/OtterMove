import SwiftUI
import SceneKit
import UIKit

enum Miniature {
    static let white = UIColor(red: 0.98, green: 0.97, blue: 0.95, alpha: 1)
    static let wood = UIColor(red: 0.79, green: 0.66, blue: 0.51, alpha: 1)
    static let blue = UIColor(red: 0.63, green: 0.77, blue: 0.87, alpha: 1)
    static let ink = UIColor(red: 0.11, green: 0.14, blue: 0.17, alpha: 1)

    static func material(_ color: UIColor) -> SCNMaterial {
        let result = SCNMaterial()
        result.diffuse.contents = color
        result.lightingModel = .physicallyBased
        result.roughness.contents = 0.85
        return result
    }
    @discardableResult
    static func ball(_ parent: SCNNode, _ color: UIColor, _ size: SCNVector3, _ position: SCNVector3) -> SCNNode {
        let geometry = SCNSphere(radius: 0.5)
        geometry.segmentCount = 32
        geometry.firstMaterial = material(color)
        let node = SCNNode(geometry: geometry)
        node.scale = size
        node.position = position
        parent.addChildNode(node)
        return node
    }
    @discardableResult
    static func box(_ parent: SCNNode, _ color: UIColor, _ size: SCNVector3, _ position: SCNVector3, round: CGFloat = 0.03) -> SCNNode {
        let radius = min(round, CGFloat(min(size.x, min(size.y, size.z))) / 2)
        let geometry = SCNBox(width: CGFloat(size.x), height: CGFloat(size.y), length: CGFloat(size.z), chamferRadius: radius)
        geometry.firstMaterial = material(color)
        let node = SCNNode(geometry: geometry)
        node.position = position
        parent.addChildNode(node)
        return node
    }

    static func scene(room: Bool) -> SCNScene {
        let scene = SCNScene()
        scene.background.contents = UIColor.clear
        let camera = SCNNode()
        camera.camera = SCNCamera()
        camera.camera?.usesOrthographicProjection = true
        camera.camera?.orthographicScale = room ? 4.5 : 2.4
        camera.position = room ? SCNVector3(4, 4.0, 6) : SCNVector3(0, 1.2, 5)
        let target = SCNNode()
        target.position = room ? SCNVector3(0, 0.6, 0) : SCNVector3(0, 0.8, 0)
        scene.rootNode.addChildNode(target)
        let look = SCNLookAtConstraint(target: target)
        look.isGimbalLockEnabled = true
        camera.constraints = [look]
        scene.rootNode.addChildNode(camera)

        let ambient = SCNNode()
        ambient.light = SCNLight()
        ambient.light?.type = .ambient
        ambient.light?.intensity = 650
        ambient.light?.color = UIColor.white
        scene.rootNode.addChildNode(ambient)
        let sunlight = SCNNode()
        sunlight.light = SCNLight()
        sunlight.light?.type = .directional
        sunlight.light?.intensity = 1000
        sunlight.light?.castsShadow = true
        sunlight.light?.shadowColor = UIColor.black.withAlphaComponent(0.12)
        sunlight.light?.shadowRadius = 6
        sunlight.eulerAngles = SCNVector3(-0.7, -0.6, 0)
        scene.rootNode.addChildNode(sunlight)
        return scene
    }

    static func furniture(_ id: String) -> SCNNode {
        let node = SCNNode()
        node.name = "item." + id
        switch id {
        case "rug":
            let mat = SCNCylinder(radius: 0.57, height: 0.015)
            mat.firstMaterial = material(UIColor(red: 0.90, green: 0.85, blue: 0.77, alpha: 1))
            let rug = SCNNode(geometry: mat)
            rug.position.y = 0.012
            node.addChildNode(rug)
        case "desk":
            box(node, wood, SCNVector3(1.15, 0.065, 0.58), SCNVector3(0, 0.68, 0))
            for x: Float in [-0.5, 0.5] {
                for z: Float in [-0.22, 0.22] {
                    box(node, wood, SCNVector3(0.06, 0.65, 0.06), SCNVector3(x, 0.33, z))
                }
            }
            box(node, ink, SCNVector3(0.4, 0.25, 0.025), SCNVector3(0, 0.86, -0.08))
            box(node, blue, SCNVector3(0.36, 0.2, 0.01), SCNVector3(0, 0.86, -0.061))
            box(node, white, SCNVector3(0.35, 0.02, 0.15), SCNVector3(0, 0.73, 0.12))
        case "chair":
            box(node, white, SCNVector3(0.42, 0.09, 0.4), SCNVector3(0, 0.37, 0))
            box(node, white, SCNVector3(0.42, 0.4, 0.07), SCNVector3(0, 0.60, -0.19))
            for x: Float in [-0.16, 0.16] {
                for z: Float in [-0.14, 0.14] {
                    box(node, wood, SCNVector3(0.045, 0.35, 0.045), SCNVector3(x, 0.18, z))
                }
            }
        case "plant":
            let pot = SCNCone(topRadius: 0.16, bottomRadius: 0.12, height: 0.28)
            pot.firstMaterial = material(white)
            let potNode = SCNNode(geometry: pot)
            potNode.position.y = 0.14
            node.addChildNode(potNode)
            for index in 0..<7 {
                let angle = Float(index) * Float.pi * 2 / 7
                let leaf = ball(node, UIColor(red: 0.44, green: 0.62, blue: 0.34, alpha: 1),
                                SCNVector3(0.14, 0.32, 0.08),
                                SCNVector3(sin(angle) * 0.12, 0.40 + Float(index % 3) * 0.04, cos(angle) * 0.12))
                leaf.eulerAngles.z = sin(angle) * 0.6
            }
        case "lamp":
            ball(node, white, SCNVector3(0.32, 0.04, 0.32), SCNVector3(0, 0.02, 0))
            box(node, wood, SCNVector3(0.03, 0.65, 0.03), SCNVector3(0, 0.35, 0))
            let shade = SCNCone(topRadius: 0.11, bottomRadius: 0.19, height: 0.22)
            shade.firstMaterial = material(white)
            let shadeNode = SCNNode(geometry: shade)
            shadeNode.position.y = 0.76
            node.addChildNode(shadeNode)
        case "sofa":
            box(node, white, SCNVector3(0.70, 0.23, 1.03), SCNVector3(0, 0.21, 0), round: 0.10)
            box(node, white, SCNVector3(0.16, 0.52, 1.03), SCNVector3(0.29, 0.40, 0), round: 0.07)
            for z: Float in [-0.46, 0.46] {
                box(node, white, SCNVector3(0.7, 0.29, 0.13), SCNVector3(0, 0.39, z), round: 0.06)
            }
            box(node, blue, SCNVector3(0.18, 0.25, 0.28), SCNVector3(0.15, 0.46, -0.12), round: 0.07)
        case "sill":
            box(node, wood, SCNVector3(0.7, 0.4, 0.38), SCNVector3(0, 0.2, 0))
            box(node, white, SCNVector3(0.65, 0.03, 0.35), SCNVector3(0, 0.42, 0))
        case "easel":
            for x: Float in [-0.18, 0.18] {
                let leg = box(node, wood, SCNVector3(0.035, 0.78, 0.04), SCNVector3(x, 0.39, 0))
                leg.eulerAngles.z = x > 0 ? -0.1 : 0.1
            }
            box(node, wood, SCNVector3(0.5, 0.48, 0.045), SCNVector3(0, 0.58, 0))
            box(node, blue, SCNVector3(0.43, 0.40, 0.015), SCNVector3(0, 0.58, 0.035))
            ball(node, white, SCNVector3(0.14, 0.10, 0.01), SCNVector3(0.08, 0.67, 0.046))
        default: break
        }
        return node
    }

    static func addRoom(to root: SCNNode) {
        box(root, UIColor(red: 0.88, green: 0.79, blue: 0.67, alpha: 1), SCNVector3(3.05, 0.08, 3.05), SCNVector3(0, -0.04, 0))
        let wall = UIColor(red: 0.96, green: 0.94, blue: 0.90, alpha: 1)
        box(root, wall, SCNVector3(3.05, 1.7, 0.07), SCNVector3(0, 0.85, -1.52))
        box(root, wall, SCNVector3(0.07, 1.7, 3.05), SCNVector3(-1.52, 0.85, 0))
        for index in -5...5 {
            box(root, UIColor.white.withAlphaComponent(0.25), SCNVector3(0.009, 0.001, 3), SCNVector3(Float(index) * 0.26, 0.002, 0), round: 0)
        }
        // A window set against the back wall, with white mullions.
        box(root, blue.withAlphaComponent(0.55), SCNVector3(1.35, 1.0, 0.02), SCNVector3(-0.5, 1.05, -1.47))
        for x: Float in [-1.19, -0.73, -0.27, 0.19] {
            box(root, white, SCNVector3(0.035, 1.04, 0.04), SCNVector3(x, 1.05, -1.44))
        }
        for y: Float in [0.54, 1.05, 1.57] {
            box(root, white, SCNVector3(1.42, 0.035, 0.04), SCNVector3(-0.5, y, -1.44))
        }
    }
}

final class OtterRig {
    let root = SCNNode()
    private let body = SCNNode()
    private let head = SCNNode()
    private let leftArm = SCNNode()
    private let rightArm = SCNNode()
    private let leftFoot = SCNNode()
    private let rightFoot = SCNNode()
    private var fingers: [(SCNNode, Float)] = []
    private var eyes: [SCNNode] = []
    private var glints: [SCNNode] = []
    private let chair = Miniature.furniture("chair")

    init() {
        root.addChildNode(body)
        let white = Miniature.white
        Miniature.ball(body, white, SCNVector3(0.64, 0.88, 0.48), SCNVector3(0, 0.64, 0))
        Miniature.ball(body, UIColor.white, SCNVector3(0.43, 0.55, 0.06), SCNVector3(0, 0.60, 0.235))
        let tail = Miniature.ball(root, white, SCNVector3(0.35, 0.23, 0.85), SCNVector3(-0.28, 0.14, -0.28))
        tail.eulerAngles.y = -0.6
        body.addChildNode(head)
        head.position = SCNVector3(0, 1.18, 0.035)
        Miniature.ball(head, white, SCNVector3(0.78, 0.62, 0.57), SCNVector3(0, 0, 0))
        for side: Float in [-1, 1] {
            Miniature.ball(head, white, SCNVector3(0.16, 0.16, 0.10), SCNVector3(side * 0.32, 0.18, -0.02))
            eyes.append(Miniature.ball(head, Miniature.ink, SCNVector3(0.045, 0.055, 0.03), SCNVector3(side * 0.16, 0.06, 0.27)))
            glints.append(Miniature.ball(head, UIColor.white, SCNVector3(0.018, 0.018, 0.01), SCNVector3(side * 0.16 - 0.008, 0.072, 0.285)))
            Miniature.ball(head, .white, SCNVector3(0.24, 0.17, 0.12), SCNVector3(side * 0.09, -0.07, 0.275))
            for offset in -1...1 {
                let whisker = Miniature.box(head, UIColor.gray.withAlphaComponent(0.65),
                                            SCNVector3(0.19, 0.006, 0.006),
                                            SCNVector3(side * 0.31, -0.06 + Float(offset) * 0.04, 0.28), round: 0.002)
                whisker.eulerAngles.z = Float(offset) * side * 0.15
            }
        }
        Miniature.ball(head, UIColor(red: 0.37, green: 0.27, blue: 0.21, alpha: 1),
                       SCNVector3(0.13, 0.08, 0.08), SCNVector3(0, -0.015, 0.34))
        let mouth = Miniature.box(head, UIColor.brown.withAlphaComponent(0.6), SCNVector3(0.008, 0.06, 0.008),
                                  SCNVector3(0, -0.10, 0.34), round: 0.003)
        mouth.eulerAngles.z = 0
        for (arm, side) in [(leftArm, Float(-1)), (rightArm, Float(1))] {
            body.addChildNode(arm)
            arm.position = SCNVector3(side * 0.29, 0.90, 0)
            Miniature.ball(arm, white, SCNVector3(0.19, 0.46, 0.19), SCNVector3(0, -0.19, 0))
            Miniature.ball(arm, white, SCNVector3(0.19, 0.17, 0.12), SCNVector3(0, -0.41, 0.03))
            for index in 0..<5 {
                let pivot = SCNNode()
                let spread = Float(index - 2) * 0.042
                pivot.position = SCNVector3(spread, -0.45, 0.03)
                arm.addChildNode(pivot)
                Miniature.ball(pivot, white, SCNVector3(0.04, 0.10, 0.04), SCNVector3(0, -0.04, 0))
                fingers.append((pivot, Float(index - 2)))
            }
        }
        for (foot, side) in [(leftFoot, Float(-1)), (rightFoot, Float(1))] {
            root.addChildNode(foot)
            foot.position = SCNVector3(side * 0.18, 0.10, 0.12)
            Miniature.ball(foot, white, SCNVector3(0.24, 0.17, 0.38), SCNVector3(0, 0, 0))
        }
        chair.scale = SCNVector3(1.4, 1.4, 1.4)
        chair.position = SCNVector3(0, 0, -0.05)
        root.insertChildNode(chair, at: 0)
    }

    func relaxEyes() {
        for eye in eyes { eye.scale = SCNVector3(0.061, 0.013, 0.03) }
        for glint in glints { glint.isHidden = true }
    }

    func pose(motion: String, elapsed: Double) {
        let wave = Float(sin(elapsed * .pi))
        let open = (Float(sin(elapsed * .pi * 0.65)) + 1) / 2
        let seated = ["paws", "shrug", "look", "rest"].contains(motion)
        chair.isHidden = !seated
        body.position.y = seated ? 0.10 : 0
        body.scale = SCNVector3(1, 1, 1)
        body.eulerAngles = SCNVector3Zero
        head.eulerAngles = SCNVector3Zero
        leftArm.eulerAngles = SCNVector3Zero
        rightArm.eulerAngles = SCNVector3Zero
        leftArm.position.y = 0.90
        rightArm.position.y = 0.90
        leftArm.position.z = 0
        rightArm.position.z = 0
        leftFoot.position.y = seated ? 0.22 : 0.10
        rightFoot.position.y = seated ? 0.22 : 0.10
        leftFoot.position.z = seated ? 0.28 : 0.12
        rightFoot.position.z = seated ? 0.28 : 0.12
        for (finger, index) in fingers {
            finger.eulerAngles.x = motion == "paws" ? -1.3 * (1 - open) : -0.15
            finger.eulerAngles.z = motion == "paws" ? index * 0.12 * open : 0
        }
        switch motion {
        case "paws":
            leftArm.eulerAngles.x = -1.1
            rightArm.eulerAngles.x = -1.1
        case "shrug":
            leftArm.position.y += open * 0.07
            rightArm.position.y += open * 0.07
        case "look":
            head.eulerAngles.y = Float(sin(elapsed * 0.45)) * 0.35
        case "stretch":
            leftArm.eulerAngles.z = -(1.0 + open * 1.55)
            rightArm.eulerAngles.z = 1.0 + open * 1.55
        case "walk":
            leftFoot.position.z += wave * 0.15
            rightFoot.position.z -= wave * 0.15
            leftFoot.position.y += max(0, wave) * 0.06
            rightFoot.position.y += max(0, -wave) * 0.06
            leftArm.eulerAngles.x = wave * 0.30
            rightArm.eulerAngles.x = -wave * 0.30
        case "circle":
            leftArm.position.y += Float(sin(elapsed * 1.5)) * 0.05
            rightArm.position.y += Float(sin(elapsed * 1.5)) * 0.05
            leftArm.position.z = Float(cos(elapsed * 1.5)) * 0.035
            rightArm.position.z = Float(cos(elapsed * 1.5)) * 0.035
        case "rest", "wind", "stand":
            body.scale = SCNVector3(1, 1 + 0.012 * open, 1)
            head.eulerAngles.z = 0.025 * Float(sin(elapsed * 0.7))
        default: break
        }
    }
}

struct OtterScene: UIViewRepresentable {
    let motion: String
    let elapsed: Double

    final class Coordinator {
        let rig = OtterRig()
    }
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        let scene = Miniature.scene(room: false)
        scene.rootNode.addChildNode(context.coordinator.rig.root)
        view.scene = scene
        view.backgroundColor = .clear
        view.antialiasingMode = .multisampling4X
        view.isUserInteractionEnabled = false
        return view
    }
    func updateUIView(_ view: SCNView, context: Context) {
        context.coordinator.rig.pose(motion: motion, elapsed: elapsed)
    }
}

struct FurnitureScene: UIViewRepresentable {
    let item: Furniture
    final class Coordinator { var currentID = "" }
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        view.backgroundColor = .clear
        view.antialiasingMode = .multisampling4X
        view.isUserInteractionEnabled = false
        return view
    }
    func updateUIView(_ view: SCNView, context: Context) {
        guard context.coordinator.currentID != item.id else { return }
        context.coordinator.currentID = item.id
        let scene = Miniature.scene(room: false)
        let node = Miniature.furniture(item.id)
        node.eulerAngles.y = -0.55
        node.position.y = 0.3
        scene.rootNode.addChildNode(node)
        view.scene = scene
    }
}

enum CarePose: Hashable { case resting, stone, floating }

struct CarePoseScene: UIViewRepresentable {
    let pose: CarePose

    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        view.backgroundColor = .clear
        view.antialiasingMode = .multisampling4X
        view.isUserInteractionEnabled = false
        let scene = Miniature.scene(room: false)
        let rig = OtterRig()
        rig.pose(motion: "wind", elapsed: 0.3)
        rig.relaxEyes()
        scene.rootNode.addChildNode(rig.root)
        if pose == .floating {
            // The face turns upward while the body floats across the water.
            rig.root.eulerAngles = SCNVector3(-0.94, 0.12, -1.26)
            rig.root.position = SCNVector3(-0.62, 0.66, 0.13)
            for size: Float in [2.0, 1.65, 1.35] {
                Miniature.ball(scene.rootNode, Miniature.blue.withAlphaComponent(0.54),
                              SCNVector3(size, 0.025, size * 0.60),
                              SCNVector3(0, 0.05 + (2 - size) * 0.035, 0.13))
            }
        } else {
            rig.root.eulerAngles = SCNVector3(-0.15, 0.08, 1.34)
            rig.root.position = SCNVector3(0.64, 0.59, 0)
            Miniature.ball(scene.rootNode, Miniature.wood,
                          SCNVector3(1.83, 0.34, 0.96), SCNVector3(0, 0.26, -0.05))
        }
        view.scene = scene
        return view
    }

    func updateUIView(_ view: SCNView, context: Context) {}
}
