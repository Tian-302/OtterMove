import SwiftUI
import UIKit

struct MainTabView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("isFirstLaunch") private var firstLaunch = true
    @State private var page = AppPage.home
    @State private var choosingExerciseState = false
    @State private var shortExercise: Activity?

    init() {
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(WellnessPalette.cream)
        let normal = UIColor(WellnessPalette.muted)
        let selected = UIColor(WellnessPalette.sageInk)
        for item in [appearance.stackedLayoutAppearance, appearance.inlineLayoutAppearance, appearance.compactInlineLayoutAppearance] {
            item.normal.iconColor = normal
            item.normal.titleTextAttributes = [.foregroundColor: normal]
            item.selected.iconColor = selected
            item.selected.titleTextAttributes = [.foregroundColor: selected]
        }
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }

    var body: some View {
        Group {
            if firstLaunch {
                OnboardingView { firstLaunch = false }
            } else {
                TabView(selection: $page) {
                    HomeView(startStretch: startStretch, openMeditation: { page = .meditation })
                        .tabItem { Label("首页", systemImage: "house.fill") }
                        .tag(AppPage.home)
                    exercise
                        .tabItem { Label("运动", systemImage: "figure.run") }
                        .tag(AppPage.exercise)
                    MeditationView(isTabActive: page == .meditation)
                        .background(Palette.midnight.ignoresSafeArea())
                        .tabItem { Label("冥想", systemImage: "brain.head.profile") }
                        .tag(AppPage.meditation)
                    RoomView()
                        .background(Color.white.ignoresSafeArea())
                        .tabItem { Label("房间", systemImage: "bed.double.fill") }
                        .tag(AppPage.room)
                }
                .tint(WellnessPalette.sageInk)
            }
        }
        .font(WellnessPalette.font(.body))
        .foregroundStyle(WellnessPalette.ink)
        .preferredColorScheme(.light)
        .task(id: scenePhase) {
            if scenePhase == .active { await CareFocusState.refresh() }
        }
        .alert("暂时无法保存", isPresented: Binding(
            get: { store.errorMessage != nil },
            set: { if !$0 { store.errorMessage = nil } }
        )) {
            Button("知道了", role: .cancel) { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
        .fullScreenCover(item: $shortExercise) { activity in
            ExerciseView(activity: activity, openRoom: {
                shortExercise = nil
                page = .room
            })
            .environmentObject(store)
        }
    }

    private var exercise: some View {
        Group {
            if choosingExerciseState || !store.profile.hasChosenState {
                StateSelectionView { choosingExerciseState = false }
            } else {
                ExerciseSelectionView(openRoom: { page = .room }, changeState: { choosingExerciseState = true })
                    .id(store.profile.place.rawValue + store.profile.energy.rawValue)
            }
        }
        .foregroundStyle(Palette.ink)
        .background(WellnessPalette.page.ignoresSafeArea())
    }

    private func startStretch() {
        page = .exercise
        shortExercise = .careStretch
    }
}
