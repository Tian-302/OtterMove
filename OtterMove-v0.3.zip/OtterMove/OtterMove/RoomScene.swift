import SwiftUI
import SceneKit

struct RoomScene: UIViewRepresentable {
    @Binding var placements: [FurniturePlacement]
    @Binding var selected: String?
    let editing: Bool
    let onMessage: (String) -> Void

    final class Coordinator: NSObject {
        var owner: RoomScene
        weak var view: SCNView?
        var appliedKey = ""
        var dragging: String?
        var dragOffset = SCNVector3Zero
        var original: FurniturePlacement?
        var lastValid: FurniturePlacement?
        init(_ owner: RoomScene) { self.owner = owner }

        private func furnitureID(at point: CGPoint) -> String? {
            guard let view else { return nil }
            for hit in view.hitTest(point, options: [.searchMode: SCNHitTestSearchMode.all.rawValue]) {
                var node: SCNNode? = hit.node
                while let current = node {
                    if let name = current.name, name.hasPrefix("item.") {
                        return String(name.dropFirst(5))
                    }
                    node = current.parent
                }
            }
            return nil
        }

        private func floorPoint(_ point: CGPoint) -> SCNVector3? {
            guard let view else { return nil }
            let near = view.unprojectPoint(SCNVector3(Float(point.x), Float(point.y), 0))
            let far = view.unprojectPoint(SCNVector3(Float(point.x), Float(point.y), 1))
            let delta = far.y - near.y
            guard abs(delta) > 0.00001 else { return nil }
            let fraction = -near.y / delta
            return SCNVector3(near.x + fraction * (far.x - near.x), 0,
                              near.z + fraction * (far.z - near.z))
        }

        @objc func tap(_ recognizer: UITapGestureRecognizer) {
            guard owner.editing else { return }
            if let id = furnitureID(at: recognizer.location(in: view)) {
                owner.selected = id
            }
        }

        @objc func pan(_ recognizer: UIPanGestureRecognizer) {
            guard owner.editing, let view else { return }
            let location = recognizer.location(in: view)
            switch recognizer.state {
            case .began:
                guard let id = furnitureID(at: location),
                      let placement = owner.placements.first(where: { $0.id == id }),
                      let point = floorPoint(location) else { return }
                dragging = id
                original = placement
                lastValid = placement
                dragOffset = SCNVector3(placement.x - point.x, 0, placement.z - point.z)
                owner.selected = id
            case .changed:
                guard let id = dragging, let original, let point = floorPoint(location) else { return }
                var candidate = original
                candidate.x = point.x + dragOffset.x
                candidate.z = point.z + dragOffset.z
                if Furniture.canPlace(candidate, in: owner.placements) {
                    lastValid = candidate
                    let node = view.scene?.rootNode.childNode(withName: "item." + id, recursively: false)
                    node?.position = SCNVector3(candidate.x, 0, candidate.z)
                    view.scene?.rootNode.childNode(withName: "selection", recursively: false)?.position = SCNVector3(candidate.x, 0.025, candidate.z)
                }
            case .ended:
                if let valid = lastValid, let index = owner.placements.firstIndex(where: { $0.id == valid.id }) {
                    owner.placements[index] = valid
                    owner.onMessage("点击完成保存布局")
                }
                dragging = nil
                original = nil
            case .cancelled, .failed:
                if let original {
                    view.scene?.rootNode.childNode(withName: "item." + original.id, recursively: false)?.position = SCNVector3(original.x, 0, original.z)
                    view.scene?.rootNode.childNode(withName: "selection", recursively: false)?.position = SCNVector3(original.x, 0.025, original.z)
                }
                dragging = nil
                original = nil
            default: break
            }
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        view.backgroundColor = .clear
        view.antialiasingMode = .multisampling4X
        context.coordinator.view = view
        view.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tap(_:))))
        view.addGestureRecognizer(UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pan(_:))))
        return view
    }

    func updateUIView(_ view: SCNView, context: Context) {
        context.coordinator.owner = self
        let key = placements.map { "\($0.id):\($0.x):\($0.z):\($0.turns)" }.joined(separator: "|")
            + "|\(editing)|\(selected ?? "")"
        guard key != context.coordinator.appliedKey else { return }
        context.coordinator.appliedKey = key
        let scene = Miniature.scene(room: true)
        Miniature.addRoom(to: scene.rootNode)
        for placement in placements {
            let node = Miniature.furniture(placement.id)
            node.position = SCNVector3(placement.x, 0, placement.z)
            node.eulerAngles.y = Float(placement.turns) * Float.pi / 2
            scene.rootNode.addChildNode(node)
        }
        let otter = OtterRig()
        otter.pose(motion: "rest", elapsed: 0.5)
        otter.root.scale = SCNVector3(0.42, 0.42, 0.42)
        otter.root.position = SCNVector3(0, 0.015, 0.9)
        scene.rootNode.addChildNode(otter.root)
        if editing {
            let gridColor = Miniature.blue.withAlphaComponent(0.45)
            for index in -5...5 {
                let position = Float(index) * 0.27
                Miniature.box(scene.rootNode, gridColor, SCNVector3(3, 0.003, 0.006), SCNVector3(0, 0.006, position), round: 0)
                Miniature.box(scene.rootNode, gridColor, SCNVector3(0.006, 0.003, 3), SCNVector3(position, 0.006, 0), round: 0)
            }
            if let current = placements.first(where: { $0.id == selected }),
               let item = Furniture.find(current.id) {
                let outline = SCNNode()
                outline.name = "selection"
                outline.position = SCNVector3(current.x, 0.025, current.z)
                outline.eulerAngles.y = Float(current.turns) * Float.pi / 2
                for side: Float in [-1, 1] {
                    Miniature.box(outline, Miniature.blue, SCNVector3(item.width, 0.006, 0.012), SCNVector3(0, 0, side * item.depth / 2), round: 0)
                    Miniature.box(outline, Miniature.blue, SCNVector3(0.012, 0.006, item.depth), SCNVector3(side * item.width / 2, 0, 0), round: 0)
                }
                scene.rootNode.addChildNode(outline)
            }
        }
        view.scene = scene
    }
}
