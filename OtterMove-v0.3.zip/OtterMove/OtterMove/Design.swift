import SwiftUI
import UIKit

enum Palette {
    static let ink = Color(red: 0.14, green: 0.23, blue: 0.32)
    static let blue = Color(red: 0.39, green: 0.60, blue: 0.76)
    static let sky = Color(red: 0.86, green: 0.92, blue: 0.98)
    static let ivory = Color(red: 0.99, green: 0.98, blue: 0.96)
    static let midnight = Color(red: 0.07, green: 0.15, blue: 0.25)
}

enum AppPage: String, Hashable {
    case home, exercise, meditation, room
}

enum WellnessPalette {
    static let background = Color(red: 240 / 255, green: 248 / 255, blue: 1)
    static let cream = Color(red: 1, green: 249 / 255, blue: 242 / 255)
    static let blue = Color(red: 142 / 255, green: 201 / 255, blue: 232 / 255)
    static let sage = Color(red: 155 / 255, green: 175 / 255, blue: 136 / 255)
    static let sageInk = Color(red: 0.29, green: 0.37, blue: 0.23)
    static let greenSoft = Color(red: 0.89, green: 0.93, blue: 0.85)
    static let gold = Color(red: 246 / 255, green: 201 / 255, blue: 104 / 255)
    static let ink = Color(red: 64 / 255, green: 59 / 255, blue: 53 / 255)
    static let muted = Color(red: 0.43, green: 0.39, blue: 0.35)

    static let page = LinearGradient(colors: [background, cream], startPoint: .top, endPoint: .bottom)

    static func font(_ style: Font.TextStyle, weight: Font.Weight = .regular) -> Font {
        .system(style, design: .rounded).weight(weight)
    }
}

struct WellnessButton: View {
    let title: String
    var color = WellnessPalette.sage
    let perform: () -> Void

    var body: some View {
        Button(action: perform) {
            Text(title)
                .font(WellnessPalette.font(.headline, weight: .semibold))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 14)
                .frame(maxWidth: .infinity, minHeight: 50)
                .foregroundStyle(WellnessPalette.ink)
                .background(color, in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

struct OtterPortrait: View {
    let name: String
    var fallbackSymbol = "pawprint.fill"

    var body: some View {
        Group {
            if let asset = UIImage(named: name) ?? (name.hasPrefix("otter_") ? UIImage(named: "otter_main") : nil) {
                Image(uiImage: asset).resizable().interpolation(.high).scaledToFit()
            } else {
                Image(systemName: fallbackSymbol).font(.system(size: 52))
                    .foregroundStyle(WellnessPalette.sageInk)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .accessibilityHidden(true)
    }
}

extension View {
    func wellnessCard(fill: Color = .white) -> some View {
        background(fill, in: RoundedRectangle(cornerRadius: 24))
            .shadow(color: WellnessPalette.ink.opacity(0.06), radius: 9, x: 0, y: 4)
    }
}

struct PrimaryButton: View {
    let title: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .frame(maxWidth: .infinity, minHeight: 52)
                .foregroundStyle(.white)
                .background(Palette.ink, in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

struct RoundControl: View {
    let symbol: String
    let label: String
    var dark = false
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.title2.weight(.semibold))
                .frame(width: 64, height: 64)
                .foregroundStyle(dark ? Palette.ink : Color.white)
                .background(dark ? Color.white : Palette.ink, in: Circle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

struct SceneArt: View {
    let name: String
    var body: some View {
        Image(name).resizable().scaledToFit()
            .mask {
                LinearGradient(stops: [
                    .init(color: .clear, location: 0),
                    .init(color: .black, location: 0.10),
                    .init(color: .black, location: 0.90),
                    .init(color: .clear, location: 1)
                ], startPoint: .top, endPoint: .bottom)
            }
            .accessibilityHidden(true)
    }
}

extension View {
    func otterCard() -> some View {
        padding(16)
            .background(.white.opacity(0.85), in: RoundedRectangle(cornerRadius: 24))
    }
}
