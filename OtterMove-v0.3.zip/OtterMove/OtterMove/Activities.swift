import Foundation

enum Place: String, CaseIterable, Codable, Identifiable {
    case outdoor = "室外", library = "图书馆", dorm = "宿舍"
    var id: String { rawValue }
}

enum Energy: String, CaseIterable, Codable, Identifiable {
    case low = "低电量", ready = "有余力"
    var id: String { rawValue }
}

struct Activity: Identifiable, Hashable {
    let id: String
    let title: String
    let place: Place
    let seconds: Int
    let cue: String
    let motion: String
    let order: Int

    var durationText: String { "\(seconds) 秒" }
    static let careStretch = Activity(
        id: "care.shoulder", title: "1 分钟肩颈放松", place: .library, seconds: 60,
        cue: "坐稳，轻轻抬起双肩，再慢慢放下。", motion: "shrug", order: -1
    )
    static let all: [Activity] = [
        .init(id: "library.paws", title: "爪爪下班", place: .library, seconds: 20,
              cue: "双手缓慢张开、轻合。", motion: "paws", order: 0),
        .init(id: "library.shoulders", title: "肩膀松一松", place: .library, seconds: 20,
              cue: "轻轻抬起双肩，再慢慢放下。", motion: "shrug", order: 1),
        .init(id: "library.look", title: "看看远方", place: .library, seconds: 20,
              cue: "暂时离开屏幕，望向远处。", motion: "look", order: 2),
        .init(id: "dorm.stand", title: "站成一只獭", place: .dorm, seconds: 30,
              cue: "站稳，放松双手，舒服地站一会儿。", motion: "stand", order: 0),
        .init(id: "dorm.stretch", title: "伸个懒腰", place: .dorm, seconds: 20,
              cue: "站稳，双臂在舒适范围内缓慢向上伸展。", motion: "stretch", order: 1),
        .init(id: "dorm.walk", title: "小獭散步", place: .dorm, seconds: 60,
              cue: "放下手机，在附近慢走一会儿。", motion: "walk", order: 2),
        .init(id: "outdoor.walk", title: "出门走走", place: .outdoor, seconds: 60,
              cue: "找一段安全平坦的路，慢慢走。", motion: "walk", order: 0),
        .init(id: "outdoor.shoulders", title: "肩膀转一转", place: .outdoor, seconds: 20,
              cue: "站稳，手臂放松，肩膀缓慢向后绕动。", motion: "circle", order: 1),
        .init(id: "outdoor.wind", title: "风里站一会儿", place: .outdoor, seconds: 30,
              cue: "放松双手，感受周围环境。", motion: "wind", order: 2)
    ]
    static func list(for place: Place) -> [Activity] {
        all.filter { $0.place == place }.sorted { $0.order < $1.order }
    }
    static func next(after activity: Activity) -> Activity? {
        guard activity.order >= 0 else { return nil }
        return list(for: activity.place).first { $0.order == activity.order + 1 }
    }
}

struct ActivityRecord: Codable, Identifiable {
    var id: UUID
    var date: Date
    var kind: String
    var activityID: String
    var title: String
    var seconds: Int
    var complete: Bool
}

struct FurniturePlacement: Codable, Equatable, Identifiable {
    var id: String
    var x: Float
    var z: Float
    var turns: Int
}

struct Furniture: Identifiable, Hashable {
    let id: String
    let title: String
    let symbol: String
    let threshold: Int
    let width: Float
    let depth: Float
    let defaultX: Float
    let defaultZ: Float

    static let all: [Furniture] = [
        .init(id: "rug", title: "圆地毯", symbol: "circle", threshold: 0, width: 1.15, depth: 1.15, defaultX: 0, defaultZ: 0.1),
        .init(id: "plant", title: "绿植", symbol: "leaf", threshold: 1, width: 0.38, depth: 0.38, defaultX: -1.15, defaultZ: 0.25),
        .init(id: "desk", title: "书桌", symbol: "desktopcomputer", threshold: 3, width: 1.15, depth: 0.58, defaultX: -0.65, defaultZ: -1.08),
        .init(id: "chair", title: "椅子", symbol: "chair", threshold: 5, width: 0.42, depth: 0.48, defaultX: -0.65, defaultZ: -0.35),
        .init(id: "lamp", title: "落地灯", symbol: "lamp.floor", threshold: 7, width: 0.35, depth: 0.35, defaultX: 1.17, defaultZ: -1.14),
        .init(id: "sofa", title: "小沙发", symbol: "sofa", threshold: 9, width: 0.75, depth: 1.03, defaultX: 1.0, defaultZ: -0.25),
        .init(id: "sill", title: "窗边矮柜", symbol: "cabinet", threshold: 11, width: 0.7, depth: 0.38, defaultX: -1.0, defaultZ: 1.0),
        .init(id: "easel", title: "画板", symbol: "easel", threshold: 15, width: 0.5, depth: 0.4, defaultX: 0.5, defaultZ: 1.1)
    ]
    static func find(_ id: String) -> Furniture? { all.first { $0.id == id } }

    static func canPlace(_ candidate: FurniturePlacement, in placements: [FurniturePlacement]) -> Bool {
        guard let furniture = find(candidate.id), candidate.x.isFinite, candidate.z.isFinite else { return false }
        func extent(_ item: Furniture, turns: Int) -> (Float, Float) {
            turns % 2 == 0 ? (item.width / 2, item.depth / 2) : (item.depth / 2, item.width / 2)
        }
        let (halfX, halfZ) = extent(furniture, turns: candidate.turns)
        guard abs(candidate.x) + halfX <= 1.48, abs(candidate.z) + halfZ <= 1.48 else { return false }
        if candidate.id == "rug" { return true }
        for other in placements where other.id != candidate.id && other.id != "rug" {
            guard let item = find(other.id) else { continue }
            let (otherX, otherZ) = extent(item, turns: other.turns)
            if abs(candidate.x - other.x) < halfX + otherX + 0.03 &&
                abs(candidate.z - other.z) < halfZ + otherZ + 0.03 { return false }
        }
        // Keep a small space for the otter at the front of the room.
        return !(abs(candidate.x) < halfX + 0.24 && abs(candidate.z - 0.9) < halfZ + 0.20)
    }
}

struct Reward {
    var newActivity: Activity?
    var furniture: [Furniture]
}

struct SessionProgress {
    let duration: Double
    private(set) var elapsed = 0.0
    private(set) var running = false
    private var lastDate: Date?
    var isFinished: Bool { elapsed >= duration }
    var remaining: Int { max(0, Int(ceil(duration - elapsed))) }

    init(seconds: Int) { duration = Double(max(1, seconds)) }
    mutating func resume(at date: Date) {
        guard !isFinished, !running else { return }
        running = true
        lastDate = date
    }
    mutating func tick(at date: Date) {
        guard running, let previous = lastDate else { return }
        elapsed = min(duration, elapsed + max(0, date.timeIntervalSince(previous)))
        lastDate = max(previous, date)
        if isFinished { running = false; lastDate = nil }
    }
    mutating func pause(at date: Date) {
        tick(at: date)
        running = false
        lastDate = nil
    }
    static func clockText(_ seconds: Int) -> String {
        String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }
}
