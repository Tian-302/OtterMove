import Foundation
import Combine

struct SavedProfile: Codable {
    var version = 2
    var place = Place.library
    var energy = Energy.low
    var hasChosenState = false
    var legacyStars = 0
    var records: [ActivityRecord] = []
    var checkins: [String] = []
    var care: CareProfile?
    var placements: [FurniturePlacement] = [
        .init(id: "rug", x: 0, z: 0.1, turns: 0)
    ]
}

@MainActor
final class AppStore: ObservableObject {
    @Published private(set) var profile: SavedProfile
    @Published var errorMessage: String?
    @Published var demoMode = false
    private let file: URL
    private var damagedData = false

    init(directory: URL? = nil) {
        let base = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("OtterMove", isDirectory: true)
        file = base.appendingPathComponent("profile-v2.json")
        if FileManager.default.fileExists(atPath: file.path) {
            do {
                profile = try JSONDecoder().decode(SavedProfile.self, from: Data(contentsOf: file))
            } catch {
                profile = SavedProfile()
                damagedData = true
                errorMessage = "保存的数据暂时无法读取。原文件已保留，请先备份工程和数据后再重试。"
            }
        } else {
            var initial = SavedProfile()
            initial.legacyStars = max(0, UserDefaults.standard.integer(forKey: "otter.stars"))
            profile = initial
        }
    }

    var stars: Int {
        profile.legacyStars + profile.records.filter { $0.kind == "exercise" && $0.complete }.count + care.stars
    }
    var unlockedIDs: Set<String> {
        var result = Set(Activity.all.filter { $0.order == 0 }.map(\.id))
        for record in profile.records where record.kind == "exercise" && record.complete {
            if let activity = Activity.all.first(where: { $0.id == record.activityID }),
               let next = Activity.next(after: activity) {
                result.insert(next.id)
            }
        }
        return result
    }
    func isUnlocked(_ activity: Activity) -> Bool {
        activity.id == Activity.careStretch.id || unlockedIDs.contains(activity.id)
    }
    func recommendedID(for place: Place, energy: Energy) -> String {
        let available = Activity.list(for: place).filter { isUnlocked($0) }
        let preferred: String?
        if energy == .low {
            preferred = available.first(where: { $0.motion == "look" || $0.motion == "wind" || $0.motion == "paws" })?.id
        } else {
            preferred = available.last?.id
        }
        return preferred ?? available.first?.id ?? Activity.list(for: place)[0].id
    }

    @discardableResult
    func setState(place: Place, energy: Energy) -> Bool {
        var next = profile
        next.place = place
        next.energy = energy
        next.hasChosenState = true
        return persist(next)
    }

    /// Returns a reward only when this session was saved for the first time.
    func finishExercise(id: UUID, activity: Activity, seconds: Int, complete: Bool) -> Reward? {
        guard isUnlocked(activity), !profile.records.contains(where: { $0.id == id }) else { return nil }
        let oldStars = stars
        let previouslyUnlocked = unlockedIDs
        var next = profile
        next.records.append(.init(id: id, date: Date(), kind: "exercise",
                                  activityID: activity.id, title: activity.title,
                                  seconds: max(0, seconds), complete: complete))
        guard persist(next) else { return nil }
        return Reward(
            newActivity: complete ? Activity.next(after: activity).flatMap { previouslyUnlocked.contains($0.id) ? nil : $0 } : nil,
            furniture: complete ? Furniture.all.filter { $0.threshold > oldStars && $0.threshold <= stars } : []
        )
    }

    @discardableResult
    func finishMeditation(id: UUID, seconds: Int) -> Bool {
        guard !profile.records.contains(where: { $0.id == id }) else { return true }
        var next = profile
        next.records.append(.init(id: id, date: Date(), kind: "meditation", activityID: "rest",
                                  title: "静心休息", seconds: seconds, complete: true))
        return persist(next)
    }

    static func dayKey(_ date: Date) -> String {
        let values = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return "\(values.year ?? 0)-\(values.month ?? 0)-\(values.day ?? 0)"
    }
    func didCheckin(on date: Date) -> Bool {
        profile.checkins.contains(Self.dayKey(date)) || careDay(on: date).hasCheckin
    }

    var care: CareProfile { profile.care ?? CareProfile() }
    func careDay(on date: Date) -> CareDay { care.days[Self.dayKey(date)] ?? CareDay() }

    func completedExercise(on date: Date, sceneOnly: Bool = false) -> [ActivityRecord] {
        profile.records.filter {
            $0.kind == "exercise" && $0.complete &&
            Calendar.current.isDate($0.date, inSameDayAs: date) &&
            (!sceneOnly || $0.activityID != Activity.careStretch.id)
        }
    }

    func toggleCare(_ habit: CareHabit, on date: Date) -> CareChange? {
        var updated = care
        let change = updated.toggle(habit, on: Self.dayKey(date))
        return saveCare(updated) ? change : nil
    }

    func setCups(_ count: Int, on date: Date) {
        let key = Self.dayKey(date)
        var updated = care
        updated.days[key, default: CareDay()].cups = min(99, max(0, count))
        _ = saveCare(updated)
    }

    func configureCare(goal: Int?, showsSleep: Bool) -> Bool {
        var updated = care
        updated.waterGoal = goal.map { min(99, max(1, $0)) }
        updated.showsSleep = showsSleep
        return saveCare(updated)
    }

    func setSleep(_ hours: Double?, on date: Date) -> Bool {
        if let hours, !(0...24).contains(hours) { return false }
        let key = Self.dayKey(date)
        var updated = care
        updated.days[key, default: CareDay()].sleepHours = hours
        return saveCare(updated)
    }

    func addHabit(_ title: String) -> Bool {
        let name = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name.count <= 24, care.customHabits.count < 12,
              !care.customHabits.contains(where: { $0.title == name }) else { return false }
        var updated = care
        updated.customHabits.append(CustomHabit(id: UUID(), title: name))
        return saveCare(updated)
    }

    func removeHabit(_ id: UUID) {
        var updated = care
        updated.customHabits.removeAll { $0.id == id }
        _ = saveCare(updated)
    }

    func toggleCustomHabit(_ habit: CustomHabit, on date: Date) -> CareChange? {
        let key = Self.dayKey(date)
        var updated = care
        var day = updated.days[key] ?? CareDay()
        let wasDone = day.customDone.removeValue(forKey: habit.id) != nil
        if !wasDone { day.customDone[habit.id] = habit.title }
        updated.days[key] = day
        guard saveCare(updated) else { return nil }
        return wasDone ? .removed : .completed(earnedStar: false)
    }

    private func saveCare(_ care: CareProfile) -> Bool {
        var next = profile
        next.version = 3
        next.care = care
        return persist(next)
    }
    func hasActivity(on date: Date) -> Bool {
        profile.records.contains { $0.complete && Calendar.current.isDate($0.date, inSameDayAs: date) }
    }
    @discardableResult
    func checkin() -> Bool {
        let key = Self.dayKey(Date())
        guard !profile.checkins.contains(key) else { return true }
        var next = profile
        next.checkins.append(key)
        return persist(next)
    }

    @discardableResult
    func saveRoom(_ placements: [FurniturePlacement]) -> Bool {
        guard Set(placements.map(\.id)).count == placements.count,
              placements.allSatisfy({ item in
                  guard let furniture = Furniture.find(item.id), furniture.threshold <= stars,
                        (0...3).contains(item.turns) else { return false }
                  return Furniture.canPlace(item, in: placements)
              }) else {
            errorMessage = "家具重叠或超出房间，请调整后再保存。"
            return false
        }
        var next = profile
        next.placements = placements
        return persist(next)
    }

    private func persist(_ next: SavedProfile) -> Bool {
        // A damaged file is left intact rather than being overwritten with an empty profile.
        guard !damagedData else {
            errorMessage = "保存的数据暂时无法读取。原文件已保留，请先备份数据后再重试。"
            return false
        }
        do {
            try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(next).write(to: file, options: .atomic)
            profile = next
            return true
        } catch {
            errorMessage = "保存失败，请检查设备空间后重试。"
            return false
        }
    }
}
