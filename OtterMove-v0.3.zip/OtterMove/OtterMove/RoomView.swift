import SwiftUI

struct RoomView: View {
    @EnvironmentObject private var store: AppStore
    @State private var editing = false
    @State private var placements: [FurniturePlacement] = []
    @State private var selected: String?
    @State private var detail: Furniture?
    @State private var message = ""
    @State private var cancelConfirm = false

    private var nextReward: Furniture? { Furniture.all.first { $0.threshold > store.stars } }
    private var changed: Bool { placements != store.profile.placements }

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text(editing ? "布置小屋" : "我的休息小屋")
                            .font(.title2.weight(.semibold))
                        Spacer()
                        if editing {
                            Button("取消") {
                                if changed { cancelConfirm = true }
                                else { editing = false; selected = nil }
                            }
                            .frame(minHeight: 44)
                        } else {
                            Label("\(store.stars)", systemImage: "star.fill").foregroundStyle(Palette.blue)
                        }
                    }
                    .padding(.horizontal, 22)

                    RoomScene(placements: $placements, selected: $selected, editing: editing,
                              onMessage: { message = $0 })
                        .frame(height: editing ? min(geometry.size.height * 0.38, 300) : min(geometry.size.width * 1.02, 450))
                        .accessibilityLabel(editing ? "房间编辑区域。也可使用下方方向按钮移动家具。" : "水獭的三维小屋")
                        .accessibilityHidden(true)

                    if editing {
                        editorControls
                    } else {
                        Button {
                            editing = true
                            message = "拖动家具，选择位置"
                        } label: {
                            Label("布置小屋", systemImage: "plus")
                                .frame(maxWidth: .infinity, minHeight: 44)
                        }
                        .buttonStyle(.bordered)
                        .clipShape(Capsule())
                        .padding(.horizontal, 70)

                        if let item = nextReward {
                            VStack(spacing: 8) {
                                HStack {
                                    Text(item.title).font(.headline)
                                    Spacer()
                                    Text("\(store.stars) / \(item.threshold) ★").font(.subheadline)
                                }
                                ProgressView(value: Double(store.stars), total: Double(item.threshold)).tint(Palette.blue)
                                Text("再运动 \(item.threshold - store.stars) 次").font(.caption)
                            }
                            .otterCard()
                            .padding(.horizontal, 22)
                        }
                        Text("家具").font(.headline).padding(.horizontal, 22)
                        collection
                    }
                }
                .padding(.top, 14)
                .padding(.bottom, 22)
            }
        }
        .onAppear { placements = store.profile.placements }
        .sheet(item: $detail) { item in
            furnitureDetails(item)
        }
        .confirmationDialog("放弃这次布局调整？", isPresented: $cancelConfirm, titleVisibility: .visible) {
            Button("放弃调整", role: .destructive) {
                placements = store.profile.placements
                selected = nil
                editing = false
            }
            Button("继续布置", role: .cancel) {}
        }
    }

    private var collection: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 10) {
                ForEach(Furniture.all) { item in
                    furnitureCard(item)
                }
            }
            .padding(.horizontal, 22)
        }
        .scrollIndicators(.hidden)
    }

    private func furnitureCard(_ item: Furniture) -> some View {
        let unlocked = store.stars >= item.threshold
        return Button {
            if editing && unlocked { addOrSelect(item) }
            else if !editing { detail = item }
            else { message = "累计 \(item.threshold) 颗星解锁\(item.title)" }
        } label: {
            VStack(spacing: 5) {
                Image(systemName: item.symbol)
                    .font(.system(size: 27, weight: .light))
                    .frame(height: 38)
                Text(item.title).font(.caption)
                if !unlocked {
                    Label("\(item.threshold) ★", systemImage: "lock.fill").font(.caption2)
                } else {
                    Image(systemName: placements.contains { $0.id == item.id } ? "checkmark.circle.fill" : "plus.circle")
                        .font(.caption).foregroundStyle(Palette.blue)
                }
            }
            .frame(width: 86, height: 92)
            .background(Palette.ivory, in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(
                editing && selected == item.id ? Palette.blue : Color.clear, lineWidth: 2))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(item.title + (unlocked ? "，已解锁" : "，需要\(item.threshold)颗星"))
    }

    private var editorControls: some View {
        VStack(spacing: 8) {
            Text(message.isEmpty ? "拖动家具，选择位置" : message)
                .font(.caption).foregroundStyle(.secondary)
            collection
            if let item = Furniture.find(selected ?? "") {
                HStack {
                    Text(item.title).font(.subheadline.weight(.medium))
                    Spacer()
                    Button { rotateSelected() } label: {
                        Image(systemName: "rotate.right").frame(width: 44, height: 44)
                    }
                    .accessibilityLabel("旋转\(item.title)")
                    Button {
                        placements.removeAll { $0.id == item.id }
                        selected = nil
                    } label: {
                        Image(systemName: "archivebox").frame(width: 44, height: 44)
                    }
                    .accessibilityLabel("将\(item.title)收回收藏")
                }
                HStack(spacing: 16) {
                    nudgeButton("arrow.left", label: "左移", x: -0.12, z: 0)
                    nudgeButton("arrow.right", label: "右移", x: 0.12, z: 0)
                    nudgeButton("arrow.up", label: "向墙边移动", x: 0, z: -0.12)
                    nudgeButton("arrow.down", label: "向前移动", x: 0, z: 0.12)
                }
            }
            PrimaryButton(title: "完成") {
                if store.saveRoom(placements) { editing = false; selected = nil }
            }
        }
        .padding(.horizontal, 22)
        .buttonStyle(.plain)
    }

    private func nudgeButton(_ symbol: String, label: String, x: Float, z: Float) -> some View {
        Button {
            adjustSelected { $0.x += x; $0.z += z }
        } label: {
            Image(systemName: symbol).frame(maxWidth: .infinity, minHeight: 44)
                .background(Palette.sky, in: RoundedRectangle(cornerRadius: 12))
        }
        .accessibilityLabel(label)
    }

    private func furnitureDetails(_ item: Furniture) -> some View {
        let unlocked = store.stars >= item.threshold
        return NavigationStack {
            VStack(spacing: 14) {
                FurnitureScene(item: item).frame(height: 250)
                Text(item.title).font(.title2.weight(.semibold))
                Label(unlocked ? "已解锁" : "未解锁", systemImage: unlocked ? "checkmark.circle.fill" : "lock")
                    .foregroundStyle(unlocked ? Palette.blue : Color.gray)
                if unlocked {
                    PrimaryButton(title: placements.contains { $0.id == item.id } ? "调整位置" : "放入小屋") {
                        detail = nil
                        editing = true
                        addOrSelect(item)
                    }
                } else {
                    ProgressView(value: Double(store.stars), total: Double(item.threshold)).tint(Palette.blue)
                    Text("\(store.stars) / \(item.threshold) ★").font(.headline)
                    Text("再运动 \(item.threshold - store.stars) 次解锁").font(.subheadline)
                }
                Spacer(minLength: 0)
            }
            .padding(24)
            .background(Color.white)
            .toolbar { Button("关闭") { detail = nil } }
        }
        .presentationDetents([.large])
    }

    private func addOrSelect(_ item: Furniture) {
        guard store.stars >= item.threshold else { return }
        if placements.contains(where: { $0.id == item.id }) {
            selected = item.id
            message = "拖动家具，选择位置"
            return
        }
        var candidate = FurniturePlacement(id: item.id, x: item.defaultX, z: item.defaultZ, turns: 0)
        if Furniture.canPlace(candidate, in: placements) {
            placements.append(candidate)
            selected = item.id
            message = "拖到喜欢的位置，再点击完成"
            return
        }
        // Search for an available starting position; the user can adjust it before saving.
        for x in stride(from: Float(-1.2), through: Float(1.2), by: Float(0.24)) {
            for z in stride(from: Float(-1.2), through: Float(1.2), by: Float(0.24)) {
                candidate.x = x
                candidate.z = z
                if Furniture.canPlace(candidate, in: placements) {
                    placements.append(candidate)
                    selected = item.id
                    message = "拖到喜欢的位置，再点击完成"
                    return
                }
            }
        }
        message = "空间不足，请先收回一件家具"
    }

    private func rotateSelected() {
        adjustSelected { $0.turns = ($0.turns + 1) % 4 }
    }
    private func adjustSelected(_ transform: (inout FurniturePlacement) -> Void) {
        guard let index = placements.firstIndex(where: { $0.id == selected }) else { return }
        var candidate = placements[index]
        transform(&candidate)
        if Furniture.canPlace(candidate, in: placements) {
            placements[index] = candidate
            message = "点击完成保存布局"
        } else {
            message = "这里会重叠或超出房间，请换个位置"
        }
    }
}
