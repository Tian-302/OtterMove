import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: AppStore
    @AppStorage("isSoundEnabled") private var sound = true
    @AppStorage("isNotificationEnabled") private var notifications = true
    @State private var asksToClear = false
    @State private var showsCleared = false

    var body: some View {
        NavigationStack {
            List {
                HStack(spacing: 14) {
                    OtterPortrait(name: "otter_main")
                        .frame(width: 58, height: 58)
                        .background(WellnessPalette.greenSoft, in: Circle())
                        .clipShape(Circle())
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Otter").font(WellnessPalette.font(.headline, weight: .bold))
                        Text("每天都在慢慢变好。").font(.subheadline)
                            .foregroundStyle(WellnessPalette.muted)
                    }
                }
                .padding(.vertical, 6)

                Section {
                    Toggle(isOn: $sound) { Label("音效", systemImage: "speaker.wave.2") }
                    Toggle(isOn: $notifications) { Label("通知偏好", systemImage: "bell") }
                } header: {
                    Text("偏好设置")
                } footer: {
                    Text("通知偏好用于应用内提示。专注模式可在系统设置中添加 OtterMove 筛选条件。")
                }

                Section("演示") {
                    Toggle("快速运动演示", isOn: $store.demoMode)
                    Text("动作缩短为 5 秒，方便预览动画和完成页面。")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("关于") {
                    Label("OtterMove", systemImage: "info.circle")
                    LabeledContent("版本号", value: Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0.0")
                    Button(role: .destructive) { asksToClear = true } label: {
                        Label("清除缓存", systemImage: "trash")
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(WellnessPalette.cream)
            .tint(WellnessPalette.sageInk)
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("完成") { dismiss() } } }
            .alert("清除缓存？", isPresented: $asksToClear) {
                Button("取消", role: .cancel) {}
                Button("确认清除", role: .destructive) { showsCleared = true }
            } message: { Text("心情、打卡记录和偏好会保留。") }
            .alert("缓存清理演示完成", isPresented: $showsCleared) {
                Button("好的", role: .cancel) {}
            }
        }
    }
}
