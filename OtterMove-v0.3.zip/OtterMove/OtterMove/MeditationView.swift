import SwiftUI
import AVFoundation
import Combine

struct MeditationView: View {
    var isTabActive = true
    @EnvironmentObject private var store: AppStore
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var length = 60
    @State private var progress = SessionProgress(seconds: 60)
    @State private var sessionID = UUID()
    @State private var saved = false
    @AppStorage("isSoundEnabled") private var soundOn = true
    @State private var player: AVAudioPlayer?
    @State private var soundError = false
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                HStack {
                    Text("月下停泊").font(.title2.weight(.medium))
                    Spacer()
                    Menu {
                        ForEach([30, 60, 300], id: \.self) { seconds in
                            Button(label(seconds)) { reset(seconds: seconds) }
                        }
                    } label: {
                        Label(label(length), systemImage: "timer").font(.subheadline)
                    }
                    .accessibilityLabel("选择冥想时长")
                }
                SceneArt(name: "OtterLake").frame(maxHeight: 300)
                ZStack {
                    Circle().strokeBorder(.white.opacity(0.25), lineWidth: 1)
                    Circle().fill(.white.opacity(0.09))
                        .scaleEffect(reduceMotion ? 0.78 : 0.65 + 0.15 * (sin(progress.elapsed * .pi / 4) + 1))
                    Text(progress.isFinished ? "休息完成" : breathText)
                        .font(.title3.weight(.medium))
                }
                .frame(width: 145, height: 145)
                .accessibilityLabel(progress.isFinished ? "休息完成" : "按照舒适的节奏呼吸")
                Text(SessionProgress.clockText(progress.remaining))
                    .font(.system(.largeTitle, design: .rounded))
                    .monospacedDigit()
                HStack(spacing: 32) {
                    Button {
                        soundOn.toggle()
                        updateAudio()
                    } label: {
                        Image(systemName: soundOn ? "speaker.wave.2" : "speaker.slash")
                            .frame(width: 44, height: 44)
                    }
                    .accessibilityLabel(soundOn ? "关闭水声" : "打开水声")
                    RoundControl(symbol: progress.running ? "pause.fill" : "play.fill",
                                 label: progress.running ? "暂停" : "开始或继续", dark: true) {
                        if progress.running { pause() }
                        else {
                            if progress.isFinished { reset(seconds: length) }
                            progress.resume(at: Date())
                            updateAudio()
                        }
                    }
                    Button { reset(seconds: length) } label: {
                        Image(systemName: "arrow.counterclockwise").frame(width: 44, height: 44)
                    }
                    .accessibilityLabel("重新开始")
                }
                if progress.isFinished {
                    Text(saved ? "已记录这次休息" : "休息完成，记录尚未保存")
                        .font(.footnote)
                    if !saved {
                        Button("重新保存") { saveCompletion() }
                    }
                }
                if soundError { Text("水声暂不可用，可以静音继续。").font(.caption) }
            }
            .padding(24)
        }
        .foregroundStyle(.white)
        .buttonStyle(.plain)
        .onReceive(timer) { date in
            guard progress.running else { return }
            progress.tick(at: date)
            if progress.isFinished {
                player?.stop()
                saveCompletion()
            }
        }
        .onDisappear { pause() }
        .onChange(of: isTabActive) { active in if !active { pause() } }
        .onChange(of: scenePhase) { phase in if phase != .active { pause() } }
    }

    private var breathText: String {
        guard progress.running || progress.elapsed > 0 else { return "跟随呼吸" }
        return progress.elapsed.truncatingRemainder(dividingBy: 8) < 4 ? "轻轻吸气" : "慢慢呼气"
    }
    private func label(_ seconds: Int) -> String {
        seconds < 60 ? "\(seconds) 秒" : "\(seconds / 60) 分钟"
    }
    private func reset(seconds: Int) {
        player?.stop()
        length = seconds
        progress = SessionProgress(seconds: seconds)
        sessionID = UUID()
        saved = false
    }
    private func pause() {
        progress.pause(at: Date())
        player?.pause()
        if progress.isFinished { saveCompletion() }
    }
    private func saveCompletion() {
        guard !saved else { return }
        saved = store.finishMeditation(id: sessionID, seconds: length)
    }
    private func updateAudio() {
        guard soundOn && progress.running else { player?.pause(); return }
        do {
            if player == nil {
                guard let url = Bundle.main.url(forResource: "LakeAmbience", withExtension: "wav") else {
                    soundError = true; return
                }
                try AVAudioSession.sharedInstance().setCategory(.ambient)
                player = try AVAudioPlayer(contentsOf: url)
                player?.numberOfLoops = -1
                player?.volume = 0.35
                player?.prepareToPlay()
            }
            soundError = !(player?.play() ?? false)
        } catch { soundError = true }
    }
}
