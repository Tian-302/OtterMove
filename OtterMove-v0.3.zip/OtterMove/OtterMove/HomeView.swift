import SwiftUI
import Combine

struct HomeView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var moods: MoodStore
    @EnvironmentObject private var health: HealthReference
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    let startStretch: () -> Void
    let openMeditation: () -> Void

    @State private var selected: MoodType?
    @State private var summary = ""
    @State private var draftDay: String?
    @State private var interaction: String?
    @State private var pressed = false
    @State private var interactionTask: Task<Void, Never>?
    @State private var showsSettings = false
    @State private var showsSuccess = false
    @State private var moodError: String?
    @State private var now = Date()
    private let clock = Timer.publish(every: 20, on: .main, in: .common).autoconnect()

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(spacing: 20) {
                    greeting
                    character
                    moodPicker
                    summaryCard
                    WellnessButton(title: moods.record(for: now) == nil ? "记录今日心情" : "更新今日心情",
                                   perform: saveMood)
                    statistics
                    Button {
                        withAnimation(reduceMotion ? nil : .easeInOut) { proxy.scrollTo("daily-care", anchor: .top) }
                    } label: {
                        Label("今日小关照", systemImage: "arrow.down.circle")
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(WellnessPalette.sageInk)
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.plain)

                    CheckinView(day: now, startStretch: startStretch, openMeditation: openMeditation)
                        .id("daily-care")
                }
                .padding(.horizontal, 19)
                .padding(.top, 14)
                .padding(.bottom, 26)
                .frame(maxWidth: 590)
                .frame(maxWidth: .infinity)
            }
        }
        .background(WellnessPalette.page.ignoresSafeArea())
        .onAppear { refreshDay(Date()) }
        .onReceive(clock) { date in
            refreshDay(date)
            if scenePhase == .active { Task { await health.refreshIfNeeded() } }
        }
        .task { await health.refreshIfNeeded() }
        .onReceive(NotificationCenter.default.publisher(for: .NSCalendarDayChanged)) { _ in refreshDay(Date()) }
        .onChange(of: scenePhase) { phase in
            if phase == .active { refreshDay(Date()) }
        }
        .onDisappear { interactionTask?.cancel(); interaction = nil; pressed = false }
        .sheet(isPresented: $showsSettings) { SettingsView() }
        .sheet(isPresented: $showsSuccess) { successSheet }
        .alert("今日心情", isPresented: Binding(
            get: { moodError != nil }, set: { if !$0 { moodError = nil } }
        )) {
            Button("好的", role: .cancel) { moodError = nil }
        } message: { Text(moodError ?? "") }
    }

    private var greeting: some View {
        let hour = Calendar.current.component(.hour, from: now)
        let greeting = (5..<12).contains(hour) ? "早安" : (12..<18).contains(hour) ? "午安" : "晚安"
        return HStack(alignment: .top, spacing: 10) {
            VStack(alignment: .leading, spacing: 6) {
                Text("\(greeting)，Otter！")
                    .font(WellnessPalette.font(.largeTitle, weight: .bold))
                    .accessibilityAddTraits(.isHeader)
                Text("今天也要和水獭一起快乐生活呀～ 🌿")
                    .font(.subheadline)
                    .foregroundStyle(WellnessPalette.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
            Button { showsSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18))
                    .frame(width: 46, height: 46)
                    .background(.white, in: Circle())
                    .foregroundStyle(WellnessPalette.ink)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("设置")
        }
    }

    private var character: some View {
        Button(action: greetOtter) {
            ZStack(alignment: .topTrailing) {
                RoundedRectangle(cornerRadius: 28)
                    .fill(LinearGradient(colors: [WellnessPalette.background, .white],
                                         startPoint: .top, endPoint: .bottom))
                OtterPortrait(name: (selected ?? .happy).imageName)
                    .id(selected)
                    .transition(.opacity.combined(with: .scale(scale: reduceMotion ? 1 : 0.97)))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(.vertical, 6)
                    .scaleEffect(pressed ? 0.93 : 1)
                if let interaction {
                    Text(interaction)
                        .font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 12).padding(.vertical, 8)
                        .background(.white, in: Capsule())
                        .padding(10)
                        .transition(.opacity)
                }
            }
            .frame(height: 232)
            .clipShape(RoundedRectangle(cornerRadius: 28))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("和\((selected ?? .happy).title)的小水獭互动")
        .accessibilityValue(interaction ?? "")
    }

    private var moodPicker: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("今天的你是什么状态呢？")
                .font(WellnessPalette.font(.headline, weight: .semibold))
                .accessibilityAddTraits(.isHeader)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 87), spacing: 8)], spacing: 8) {
                ForEach(MoodType.allCases) { mood in
                    Button {
                        withAnimation(reduceMotion ? nil : .spring(response: 0.36, dampingFraction: 0.72)) {
                            selected = mood
                            summary = mood.summary(excluding: summary)
                        }
                    } label: {
                        VStack(spacing: 4) {
                            OtterPortrait(name: mood.imageName)
                                .frame(height: 53)
                                .clipShape(RoundedRectangle(cornerRadius: 9))
                            Text(mood.title).font(.subheadline.weight(.semibold))
                        }
                        .padding(7)
                        .frame(maxWidth: .infinity, minHeight: 84)
                        .background(selected == mood ? WellnessPalette.blue.opacity(0.38) : .white,
                                    in: RoundedRectangle(cornerRadius: 16))
                        .overlay(alignment: .topTrailing) {
                            if selected == mood {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 15))
                                    .foregroundStyle(WellnessPalette.sageInk)
                                    .padding(5)
                            }
                        }
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(selected == mood ? .isSelected : [])
                }
            }
        }
    }

    private var summaryCard: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 9) {
                summaryText
                Spacer(minLength: 6)
                changeSentence
            }
            VStack(alignment: .leading, spacing: 4) {
                summaryText
                changeSentence
            }
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(WellnessPalette.blue.opacity(0.28), in: RoundedRectangle(cornerRadius: 24))
    }

    private var summaryText: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "star.fill").foregroundStyle(WellnessPalette.gold)
                .accessibilityHidden(true)
            Text(summary.isEmpty ? "选一种心情，听听 Otter 的回应。" : summary)
                .id(summary)
                .transition(.opacity)
                .font(.subheadline.weight(.medium))
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var changeSentence: some View {
        Button {
            guard let selected else { return }
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                summary = selected.summary(excluding: summary)
            }
        } label: {
            Label("换一句", systemImage: "arrow.triangle.2.circlepath")
                .font(.caption.weight(.semibold))
                .fixedSize()
                .foregroundStyle(WellnessPalette.sageInk)
                .frame(minHeight: 44)
        }
        .buttonStyle(.plain)
        .disabled(selected == nil)
        .opacity(selected == nil ? 0.5 : 1)
    }

    private var statistics: some View {
        let seconds = store.completedExercise(on: now).reduce(0) { $0 + $1.seconds }
        let duration = seconds == 0 || seconds >= 60 ? "\(seconds / 60) 分钟" : "\(seconds) 秒"
        return ViewThatFits(in: .horizontal) {
            HStack(spacing: 10) {
                stat("今日运动", value: duration, icon: "figure.run", color: WellnessPalette.blue)
                stat("累计星星", value: "\(store.stars) 颗", icon: "star.fill", color: WellnessPalette.gold)
            }
            VStack(spacing: 10) {
                stat("今日运动", value: duration, icon: "figure.run", color: WellnessPalette.blue)
                stat("累计星星", value: "\(store.stars) 颗", icon: "star.fill", color: WellnessPalette.gold)
            }
        }
    }

    private func stat(_ title: String, value: String, icon: String, color: Color) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon).font(.title3.weight(.semibold))
                .foregroundStyle(color).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.caption.weight(.medium)).foregroundStyle(WellnessPalette.muted)
                Text(value).font(WellnessPalette.font(.title3, weight: .bold)).monospacedDigit()
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .wellnessCard()
        .accessibilityElement(children: .combine)
    }

    private var successSheet: some View {
        ScrollView {
            VStack(spacing: 12) {
                OtterPortrait(name: "otter_star").frame(height: 128)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                Text("心情记录成功！")
                    .font(WellnessPalette.font(.title2, weight: .bold))
                Text("今天的心情已保存，记得继续好好照顾自己哦～")
                    .font(.subheadline)
                    .foregroundStyle(WellnessPalette.muted)
                    .multilineTextAlignment(.center)
                WellnessButton(title: "好的", color: WellnessPalette.blue) { showsSuccess = false }
            }
            .padding(23)
            .frame(maxWidth: 440)
            .frame(maxWidth: .infinity)
        }
        .background(WellnessPalette.cream.ignoresSafeArea())
        .presentationDetents([.medium, .large])
    }

    private func refreshDay(_ date: Date) {
        now = date
        let key = AppStore.dayKey(date)
        guard draftDay != key else { return }
        draftDay = key
        let record = moods.record(for: date)
        selected = record?.mood
        summary = record?.summary ?? ""
    }

    private func saveMood() {
        let date = Date()
        refreshDay(date)
        guard let selected else { moodError = "请先选择今天的心情。"; return }
        guard moods.save(selected, summary: summary, date: date) else {
            moodError = "这次心情暂时无法保存，请稍后重试。"
            return
        }
        showsSuccess = true
    }

    private func greetOtter() {
        interactionTask?.cancel()
        let options = ["嘿嘿，被你发现啦！", "今天也要开心呀！", "抱抱你～", "Otter 一直陪着你！"]
        withAnimation(reduceMotion ? nil : .easeOut(duration: 0.12)) {
            pressed = !reduceMotion
            interaction = options.filter { $0 != interaction }.randomElement()
        }
        interactionTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 120_000_000)
            guard !Task.isCancelled else { return }
            withAnimation(.spring(response: 0.34, dampingFraction: 0.58)) { pressed = false }
            try? await Task.sleep(nanoseconds: 2_100_000_000)
            guard !Task.isCancelled else { return }
            withAnimation(reduceMotion ? nil : .easeOut) { interaction = nil }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(startStretch: {}, openMeditation: {})
            .environmentObject(AppStore())
            .environmentObject(MoodStore())
            .environmentObject(HealthReference())
    }
}
