import Foundation

enum MoodType: String, CaseIterable, Identifiable, Codable {
    case happy, relaxed, anxious, tired, hardworking, excited

    var id: Self { self }
    var imageName: String { "otter_" + rawValue }
    var title: String {
        switch self {
        case .happy: "开心"
        case .relaxed: "放松"
        case .anxious: "焦虑"
        case .tired: "疲惫"
        case .hardworking: "卷"
        case .excited: "兴奋"
        }
    }
    var summaries: [String] {
        switch self {
        case .happy:
            ["今天的快乐，好像连空气都变甜了！", "今天是元气满满的一天呀！", "把这份好心情偷偷收藏起来吧！"]
        case .relaxed:
            ["慢慢来，也是一种很棒的生活节奏。", "今天的你，值得享受一点宁静。", "像云朵一样轻轻松松地度过今天吧。"]
        case .anxious:
            ["心里有点乱也没关系，先照顾好自己。", "今天或许不太轻松，Otter 陪着你。", "不必急着解决所有事情，慢慢来就好。"]
        case .tired:
            ["辛苦啦，今天也要记得好好休息。", "累的时候，允许自己停下来。", "今天已经很努力了，给自己一个拥抱吧。"]
        case .hardworking:
            ["努力很棒，但休息也同样重要！", "今天是认真生活的小水獭！", "冲劲满满，也别忘了给自己充电。"]
        case .excited:
            ["今天的心情像星星一样闪闪发光！", "好像有很多美好的事情值得期待！", "把这份雀跃的心情好好珍藏吧！"]
        }
    }

    func summary(excluding current: String = "") -> String {
        summaries.filter { $0 != current }.randomElement() ?? summaries[0]
    }
}
