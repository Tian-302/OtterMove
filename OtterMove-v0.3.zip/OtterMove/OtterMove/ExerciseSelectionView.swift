import SwiftUI

struct StateSelectionView: View {
    @EnvironmentObject private var store: AppStore
    let next: () -> Void
    @State private var place = Place.library
    @State private var energy = Energy.low

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("给自己一点运动时间").font(.title2.weight(.semibold))
                    SceneArt(name: "OtterIdle")
                        .frame(height: min(geometry.size.height * 0.40, 300))
                        .frame(maxWidth: .infinity)
                    Text("你在哪里").font(.headline)
                    HStack {
                        ForEach(Place.allCases) { item in
                            choice(item.rawValue, selected: place == item) { place = item }
                        }
                    }
                    Text("还有多少电量").font(.headline)
                    HStack {
                        ForEach(Energy.allCases) { item in
                            choice(item.rawValue, selected: energy == item) { energy = item }
                        }
                    }
                    PrimaryButton(title: "去选一个动作") {
                        if store.setState(place: place, energy: energy) { next() }
                    }
                }
                .padding(22)
                .frame(minHeight: geometry.size.height, alignment: .top)
            }
        }
        .onAppear { place = store.profile.place; energy = store.profile.energy }

    }

    private func choice(_ title: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title).font(.subheadline.weight(.medium))
                .frame(maxWidth: .infinity, minHeight: 44)
                .foregroundStyle(selected ? Color.white : Palette.ink)
                .background(selected ? Palette.ink : Color.white.opacity(0.8), in: Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
}

struct ExerciseSelectionView: View {
    @EnvironmentObject private var store: AppStore
    let openRoom: () -> Void
    let changeState: () -> Void
    @State private var selectedID: String?
    @State private var session: Activity?
    @State private var pendingSession: Activity?

    private var activities: [Activity] { Activity.list(for: store.profile.place) }
    private var selected: Activity {
        activities.first { $0.id == selectedID } ?? activities[0]
    }

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 12) {
                    Button(action: changeState) {
                        Label("\(store.profile.place.rawValue) · \(store.profile.energy.rawValue)", systemImage: "square.and.pencil")
                            .font(.subheadline)
                    }
                    .buttonStyle(.plain)
                    Text(selected.title).font(.title2.weight(.semibold))
                    Text(selected.durationText).font(.subheadline)
                    OtterScene(motion: selected.motion, elapsed: 0.8)
                        .frame(height: min(geometry.size.height * 0.43, 310))
                        .accessibilityLabel(selected.title + "动作示意")
                    Text(selected.cue)
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 10)

                    TabView(selection: $selectedID) {
                        ForEach(activities) { activity in
                            actionCard(activity)
                                .padding(.horizontal, 24)
                                .tag(Optional(activity.id))
                        }
                    }
                    .tabViewStyle(.page(indexDisplayMode: .never))
                    .frame(height: 124)
                    HStack(spacing: 12) {
                        ForEach(activities) { activity in
                            Button {
                                withAnimation(.easeInOut(duration: 0.25)) { selectedID = activity.id }
                            } label: {
                                Circle()
                                    .fill(selected.id == activity.id ? Palette.ink : Palette.blue.opacity(0.35))
                                    .frame(width: 8, height: 8)
                                    .frame(width: 40, height: 36)
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel(activity.title)
                            .accessibilityAddTraits(selected.id == activity.id ? .isSelected : [])
                        }
                    }
                    Text("左右滑动选择").font(.caption).foregroundStyle(.secondary)
                    if store.isUnlocked(selected) {
                        PrimaryButton(title: "开始") { session = selected }
                            .padding(.horizontal, 22)
                    } else {
                        let predecessor = activities.first { $0.order == selected.order - 1 }
                        Text("完成「\(predecessor?.title ?? "前一个动作")」后解锁")
                            .font(.subheadline)
                            .padding()
                    }
                }
                .padding(.vertical, 12)
                .frame(minHeight: geometry.size.height, alignment: .top)
            }
        }
        .onAppear {
            selectedID = store.recommendedID(for: store.profile.place, energy: store.profile.energy)
        }
        .fullScreenCover(item: $session, onDismiss: {
            if let pending = pendingSession {
                pendingSession = nil
                session = pending
            }
        }) { activity in
            ExerciseView(activity: activity, openRoom: {
                session = nil
                openRoom()
            }, chooseNext: { next in
                pendingSession = next
                session = nil
            })
            .environmentObject(store)
        }
    }

    private func actionCard(_ activity: Activity) -> some View {
        let available = store.isUnlocked(activity)
        return Button {
            withAnimation(.easeInOut(duration: 0.25)) { selectedID = activity.id }
        } label: {
            VStack(spacing: 5) {
                Image(systemName: available ? icon(activity.motion) : "lock")
                    .font(.system(size: 28, weight: .light))
                    .frame(height: 46)
                Text(activity.title).font(.caption.weight(.medium)).lineLimit(2)
                Text(available ? activity.durationText : "待解锁").font(.caption2).foregroundStyle(.secondary)
            }
            .padding(8)
            .frame(maxWidth: .infinity, minHeight: 112)
            .background(.white.opacity(0.85), in: RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(
                selected.id == activity.id ? Palette.ink : Color.clear, lineWidth: 2))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(activity.title + (available ? "，已解锁" : "，未解锁"))
    }

    private func icon(_ motion: String) -> String {
        switch motion {
        case "paws": "hand.raised"
        case "look": "eye"
        case "walk": "figure.walk"
        case "stretch": "figure.flexibility"
        case "wind": "wind"
        case "stand": "figure.stand"
        default: "figure.cooldown"
        }
    }
}
