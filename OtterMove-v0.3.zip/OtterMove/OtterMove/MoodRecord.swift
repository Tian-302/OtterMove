import Foundation

struct MoodRecord: Codable, Identifiable {
    let id: UUID
    let date: Date
    let mood: MoodType
    let summary: String
}
