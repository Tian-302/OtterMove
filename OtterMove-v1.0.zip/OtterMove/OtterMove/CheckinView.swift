import SwiftUI
import Combine

struct CheckinPage: View {
    @EnvironmentObject private var health: HealthReference
    @Environment(\.scenePhase) private var scenePhase
    let startStretch: () -> Void
    let openMeditation: () -> Void
    @State private var today = Date()
    private let clock = Timer.publish(every: 20, on: .main, in: .common).autoconnect()

    var body: some View {
        ScrollView {
            CheckinView(day: today, startStretch: startStretch, openMeditation: openMeditation)
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 24)
                .frame(maxWidth: 600)
                .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .background {
            LinearGradient(colors: [Color(red: 0.95, green: 0.97, blue: 0.90), WellnessPalette.cream],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
        }
        .onAppear { today = Date() }
        .onReceive(clock) { date in
            today = date
            if scenePhase == .active { Task { await health.refreshIfNeeded() } }
        }
        .onReceive(NotificationCenter.default.publisher(for: .NSCalendarDayChanged)) { _ in today = Date() }
        .onChange(of: scenePhase) { phase in
            if phase == .active { today = Date() }
        }
        .task { await health.refreshIfNeeded() }
    }
}

struct CheckinView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var health: HealthReference
    @AppStorage("isNotificationEnabled") private var promptsEnabled = true
    @AppStorage(CareFocusState.quietKey) private var quiet = false
    @AppStorage(CareFocusState.resumedKey) private var resumedAt = 0.0
    @Environment(\.dynamicTypeSize) private var typeSize
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let day: Date
    let startStretch: () -> Void
    let openMeditation: () -> Void

    @State private var showsHistory = false
    @State private var showsSetup = false
    @State private var showsSleep = false
    @State private var feedback: String?
    @State private var feedbackTask: Task<Void, Never>?

    private var entries: CareDay { store.careDay(on: day) }
    private var hour: Int { Calendar.current.component(.hour, from: day) }
    private var suggestsMovement: Bool { !quiet && health.matches(day) && health.shouldSuggestMovement }
    private var showsFocusReturn: Bool {
        promptsEnabled && !quiet && (0..<300).contains(day.timeIntervalSince1970 - resumedAt)
    }
    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 10), count: typeSize.isAccessibilitySize ? 1 : 2)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            heading
            careHero
            if let feedback {
                Label(feedback, systemImage: "pawprint.fill")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(WellnessPalette.sageInk)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12)
                    .background(WellnessPalette.greenSoft, in: RoundedRectangle(cornerRadius: 15))
                    .transition(.opacity)
            }
            if showsFocusReturn && !entries.hasCheckin {
                Label("有空了，可以给自己留一点休息时间。", systemImage: "pawprint")
                    .font(.footnote)
                    .foregroundStyle(WellnessPalette.sageInk)
            }
            if suggestsMovement && !entries.completed.contains(.shoulders) {
                Label("坐了一阵吗？可以试试肩颈放松或出门透气。", systemImage: "leaf")
                    .font(.footnote)
                    .foregroundStyle(WellnessPalette.sageInk)
            }

            group("身体关照", habits: [.water, .shoulders, .outdoor])
            group("作息精力", habits: [.bedtime, .meals])
            group("用眼放松", habits: [.eyes])
            waterCounter
            quickActions
            if store.care.showsSleep { sleepButton }
            if !store.care.customHabits.isEmpty { customHabits }
            footer
        }
        .font(WellnessPalette.font(.body))
        .padding(15)
        .wellnessCard(fill: WellnessPalette.cream)
        .sheet(isPresented: $showsHistory) { CareHistoryView() }
        .sheet(isPresented: $showsSetup) { CareSetupView() }
        .sheet(isPresented: $showsSleep) { SleepEntryView(day: day) }
        .onChange(of: AppStore.dayKey(day)) { _ in
            feedbackTask?.cancel()
            feedback = nil
        }
        .onDisappear { feedbackTask?.cancel(); feedback = nil }
    }

    private var heading: some View {
        HStack(alignment: .top, spacing: 6) {
            VStack(alignment: .leading, spacing: 4) {
                Text("健康打卡")
                    .font(WellnessPalette.font(.largeTitle, weight: .bold))
                    .accessibilityAddTraits(.isHeader)
                Text(day.formatted(.dateTime.month().day().weekday()))
                    .font(.footnote).foregroundStyle(WellnessPalette.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
            Button { showsSetup = true } label: {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 18, weight: .medium))
                    .frame(width: 44, height: 44)
                    .background(.white, in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("打卡设置")
        }
    }

   
    private var careHero: some View {

        let hasCare = entries.hasCheckin

        let floated = hasCare &&
            !store.completedExercise(
                on: day,
                sceneOnly: true
            ).isEmpty

        let pose = floated
            ? CarePose.floating
            : hasCare ? .stone : .resting

        let completedCount = entries.completed.count
        let totalCount = CareHabit.allCases.count
        let allCompleted = completedCount >= totalCount

        let notes = [
            "不必全部完成，偶尔停下来就很好。",
            "哪怕一件小事，也是好好照顾自己的证明。",
            "照顾自己不需要满分，今天的一小步就足够。"
        ]

        let dailyNote = notes[
            AppStore.dayKey(day).utf8.reduce(0) {
                $0 + Int($1)
            } % notes.count
        ]

        let note = allCompleted
            ? "今天也有好好照顾自己，Otter 为你骄傲！⭐"
            : dailyNote

        return ViewThatFits(in: .horizontal) {

            HStack(spacing: 10) {
                carePortrait(pose)
                    .frame(width: 117, height: 116)

                careProgress(note)
            }

            VStack(spacing: 10) {
                carePortrait(pose)
                    .frame(height: 135)

                careProgress(note)
            }
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            allCompleted
                ? WellnessPalette.background
                : floated
                    ? WellnessPalette.background
                    : WellnessPalette.greenSoft,
            in: RoundedRectangle(cornerRadius: 22)
        )
        .animation(
            reduceMotion
                ? nil
                : .easeInOut(duration: 0.25),
            value: pose
        )
        .accessibilityElement(children: .combine)
    }


    private func carePortrait(_ pose: CarePose) -> some View {
        let art = pose == .resting ? OtterArtwork.mood(.tired) :
                  pose == .stone ? OtterArtwork.mood(.relaxed) : OtterArtwork.celebration
        return OtterMovingThumbnail(name: art, phase: 1.2)
            .padding(.vertical, 5)
    }

    private func careProgress(_ note: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("今日已记录 \(entries.completed.count) / \(CareHabit.allCases.count)")
                .font(.subheadline.weight(.semibold))
                .fixedSize(horizontal: false, vertical: true)
            ProgressView(value: Double(entries.completed.count), total: Double(CareHabit.allCases.count))
                .tint(WellnessPalette.sageInk)
            Text(note).font(.caption)
                .foregroundStyle(WellnessPalette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func group(_ title: String, habits: [CareHabit]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.footnote.weight(.semibold))
                .foregroundStyle(WellnessPalette.sageInk)
                .padding(.horizontal, 11)
                .padding(.vertical, 6)
                .background(WellnessPalette.greenSoft, in: Capsule())
                .accessibilityAddTraits(.isHeader)
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(habits) { habit in habitCard(habit) }
            }
        }
    }

    private func habitCard(_ habit: CareHabit) -> some View {
        let checked = entries.completed.contains(habit)
        let nudged = !quiet && !checked && ((habit == .bedtime && (hour >= 22 || hour < 5)) ||
                                  (suggestsMovement && (habit == .shoulders || habit == .outdoor)))
        return Button {
            let date = Date()
            if let change = store.toggleCare(habit, on: date) { respond(to: change) }
        } label: {
            VStack(alignment: .leading, spacing: 6) {
                OtterPortrait(name: habit == .shoulders ? OtterArtwork.activity(.careStretch) : habit.art,
                              fallbackSymbol: habit.symbol)
                    .frame(height: 56)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                Text(habit.title).font(.subheadline.weight(.bold))
                Text(habit.detail)
                    .font(.caption)
                    .foregroundStyle(WellnessPalette.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(10)
            .frame(maxWidth: .infinity, minHeight: 136, alignment: .topLeading)
            .background(checked ? WellnessPalette.greenSoft : Color.white,
                        in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16)
                .strokeBorder(nudged ? WellnessPalette.sage : .clear, lineWidth: 1.5))
            .overlay(alignment: .topTrailing) {
                Image(systemName: checked ? "checkmark.circle.fill" : "plus.circle")
                    .font(.title3.weight(.medium))
                    .foregroundStyle(WellnessPalette.sageInk)
                    .padding(8)
                    .accessibilityHidden(true)
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(habit.title)
        .accessibilityHint(habit.detail)
        .accessibilityValue(checked ? "已打卡，再点可撤销" : "可记录")
        .accessibilityAddTraits(checked ? .isSelected : [])
    }

    private var waterCounter: some View {
        VStack(alignment: .leading, spacing: 8) {
            Stepper(value: Binding(
                get: { entries.cups },
                set: { store.setCups($0, on: Date()) }
            ), in: 0...99) {
                Text("今天喝了 \(entries.cups) 杯").font(.subheadline.weight(.semibold))
            }
            if let goal = store.care.waterGoal {
                Text("我的目标 \(goal) 杯").font(.caption)
                    .foregroundStyle(WellnessPalette.muted)
            }
            if let water = health.waterMilliliters, health.matches(day) {
                Text("健康 App 饮水记录 \(water) 毫升").font(.caption)
                    .foregroundStyle(WellnessPalette.muted)
            }
        }
        .padding(12)
        .wellnessCard()
    }

    private var quickActions: some View {
        VStack(spacing: 2) {
            shortcut("做 1 分钟肩颈放松", icon: "figure.cooldown", action: startStretch)
            Divider()
            shortcut("做一次短时呼吸练习", icon: "wind", action: openMeditation)
        }
        .padding(.horizontal, 12)
        .wellnessCard()
    }

    private func shortcut(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Label(title, systemImage: icon)
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.semibold))
            }
            .font(.subheadline)
            .foregroundStyle(WellnessPalette.sageInk)
            .frame(minHeight: 44)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var sleepButton: some View {
        shortcut(entries.sleepHours.map {
            "睡眠约 \($0.formatted(.number.precision(.fractionLength(0...1)))) 小时"
        } ?? "记录睡眠", icon: "bed.double") { showsSleep = true }
        .padding(.horizontal, 12)
        .wellnessCard()
    }

    private var customHabits: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("我的小习惯").font(.subheadline.weight(.semibold))
            ForEach(store.care.customHabits) { habit in
                let done = entries.customDone[habit.id] != nil
                Button {
                    if let change = store.toggleCustomHabit(habit, on: Date()) { respond(to: change) }
                } label: {
                    Label(habit.title, systemImage: done ? "checkmark.circle.fill" : "plus.circle")
                        .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                        .foregroundStyle(done ? WellnessPalette.sageInk : WellnessPalette.ink)
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(done ? .isSelected : [])
            }
        }
        .padding(12)
        .wellnessCard()
    }

    private var footer: some View {
        HStack(alignment: .center, spacing: 8) {
            Label("\(store.stars) 颗星", systemImage: "star.fill")
                .font(.subheadline.weight(.semibold))
                .padding(.horizontal, 9)
                .padding(.vertical, 7)
                .background(WellnessPalette.gold.opacity(0.25), in: Capsule())
            Spacer(minLength: 0)
            Button { showsHistory = true } label: {
                Label("查看打卡日历", systemImage: "calendar")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(WellnessPalette.sageInk)
                    .frame(minHeight: 44)
            }
            .buttonStyle(.plain)
        }
    }

    private func respond(to change: CareChange) {
        feedbackTask?.cancel()
        let message: String
        switch change {
        case .completed(let earned):
            message = earned ? "今天也有好好照顾自己呀 · +1 星星" : "Otter 记下了这件照顾自己的小事。"
        case .removed:
            message = "已更新今天的记录。"
        }
        withAnimation(reduceMotion ? nil : .easeInOut) { feedback = message }
        feedbackTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 3_600_000_000)
            guard !Task.isCancelled else { return }
            withAnimation(reduceMotion ? nil : .easeOut) { feedback = nil }
        }
    }
}

private enum CarePose: Hashable { case resting, stone, floating }
