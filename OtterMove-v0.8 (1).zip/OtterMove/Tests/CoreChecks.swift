import Foundation

@main
@MainActor
struct CoreChecks {
    static func require(_ condition: @autoclosure () -> Bool, _ message: String) {
        guard condition() else { fatalError(message) }
    }

    static func checkMeditationTiming() {
        let formatter = ISO8601DateFormatter()
        let changes: [(String, LakeLight)] = [
            ("2026-11-20T21:59:59Z", .night),
            ("2026-11-20T22:00:00Z", .day),
            ("2026-11-21T08:59:59Z", .day),
            ("2026-11-21T09:00:00Z", .dusk),
            ("2026-11-21T10:59:59Z", .dusk),
            ("2026-11-21T11:00:00Z", .night)
        ]
        for (isoDate, mode) in changes {
            require(LakeLight.at(formatter.date(from: isoDate)!) == mode, "Beijing time boundary is independent of device time zone")
        }
        require(BreathCue.at(0) == BreathCue(phase: .inhale, seconds: 4), "Breathing starts with a four-second inhalation")
        require(BreathCue.at(3.99) == BreathCue(phase: .inhale, seconds: 1), "Remaining stage never flashes zero")
        require(BreathCue.at(4) == BreathCue(phase: .hold, seconds: 2), "Hold begins at the first boundary")
        require(BreathCue.at(6) == BreathCue(phase: .exhale, seconds: 6), "Exhale begins after the hold")
        require(BreathCue.at(12) == BreathCue(phase: .inhale, seconds: 4), "The complete cycle repeats")
    }

    static func checkOtterJoints() {
        let idle = OtterPose.sample(.stretch, time: 0)
        let extended = OtterPose.sample(.stretch, time: 2.6)
        let lowered = OtterPose.sample(.stretch, time: 5.29)
        require(extended.left.shoulder.z < -2.7 && extended.right.shoulder.z > 2.7,
                "Stretch lifts both arms with mirrored shoulder joints")
        require(abs(lowered.left.shoulder.z - idle.left.shoulder.z) < 0.01,
                "Stretch returns continuously to its first pose")
        let stepA = OtterPose.sample(.walk, time: 0, outdoors: true)
        let stepB = OtterPose.sample(.walk, time: 0.74, outdoors: true)
        require(abs(stepA.leftLeg.hip - stepA.rightLeg.hip) > 0.45, "Walking separates front and back feet")
        require(abs(stepA.leftLeg.hip - stepB.rightLeg.hip) < 0.01, "Walking alternates the legs")
        require(abs(stepA.left.shoulder.x - stepB.right.shoulder.x) < 0.01, "Arm swing alternates with the gait")
        let start = OtterPose.sample(.paws, time: 0)
        let closed = OtterPose.sample(.paws, time: 1.5)
        require(start.seated && closed.left.curl - start.left.curl > 0.9, "Paw demo closes the digits while seated")
        require(OtterPose.sample(.rest, time: 0, mood: .annoyed).eyes == .focused, "Mood selects a distinct expression")
        require(OtterPose.sample(.rest, time: 0, mood: .anxious).mouth == .worried, "Worried mood selects a different mouth")
    }

    static func main() throws {
        checkMeditationTiming()
        checkOtterJoints()
        let start = Date(timeIntervalSince1970: 1_000)
        var clock = SessionProgress(seconds: 20)
        clock.resume(at: start)
        clock.tick(at: start.addingTimeInterval(2.2))
        require(clock.remaining == 18, "Countdown rounds up fractional seconds")
        clock.pause(at: start.addingTimeInterval(3))
        clock.tick(at: start.addingTimeInterval(80))
        require(clock.elapsed == 3 && !clock.running, "Paused time must not count")
        clock.resume(at: start.addingTimeInterval(100))
        clock.resume(at: start.addingTimeInterval(101))
        clock.tick(at: start.addingTimeInterval(102))
        require(clock.elapsed == 5, "Resuming twice must not restart the time anchor")
        clock.tick(at: start.addingTimeInterval(101))
        clock.tick(at: start.addingTimeInterval(103))
        require(clock.elapsed == 6, "A backwards clock jump must not double-count time")
        clock.tick(at: start.addingTimeInterval(200))
        require(clock.isFinished && clock.remaining == 0 && !clock.running, "Overshoot clamps at duration")
        clock.resume(at: start.addingTimeInterval(300))
        require(!clock.running, "Completed timers cannot restart")

        require(Set(Activity.all.map(\.id)).count == 9, "Each action needs a unique stable ID")
        for place in Place.allCases {
            let actions = Activity.list(for: place)
            require(actions.map(\.order) == [0, 1, 2], "Each place has a complete three-action unlock chain")
            require(Activity.next(after: actions[2]) == nil, "No dangling final unlock")
        }
        let layout = Furniture.all.map {
            FurniturePlacement(id: $0.id, x: $0.defaultX, z: $0.defaultZ, turns: 0)
        }
        require(layout.allSatisfy { Furniture.canPlace($0, in: layout) }, "Default furniture positions fit together")
        let rotatedDesk = FurniturePlacement(id: "desk", x: -0.65, z: -1.08, turns: 1)
        require(!Furniture.canPlace(rotatedDesk, in: []), "Rotation must check the changed footprint")
        let rug = FurniturePlacement(id: "rug", x: 0, z: 0.1, turns: 0)
        let plant = FurniturePlacement(id: "plant", x: 0, z: 0.1, turns: 0)
        require(Furniture.canPlace(plant, in: [rug]), "A rug is a floor layer")
        let overlap = FurniturePlacement(id: "chair", x: 0, z: 0.1, turns: 0)
        require(!Furniture.canPlace(overlap, in: [plant]), "Solid furniture cannot overlap")

        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let file = directory.appendingPathComponent("profile-v2.json")
        try JSONEncoder().encode(SavedProfile()).write(to: file)
        let store = AppStore(directory: directory)
        require(store.stars == 0 && store.unlockedIDs.count == 3, "Clean profile starts with three actions")
        require(store.setState(place: .outdoor, energy: .ready), "State is persisted")
        let first = Activity.list(for: .library)[0]
        let second = Activity.list(for: .library)[1]
        let third = Activity.list(for: .library)[2]
        require(store.finishExercise(id: UUID(), activity: second, seconds: 20, complete: true) == nil,
                "Locked actions cannot mint rewards")
        let session = UUID()
        let reward = store.finishExercise(id: session, activity: first, seconds: 20, complete: true)
        require(reward?.newActivity == second && store.stars == 1, "Completion unlocks the next action")
        require(reward?.furniture.first?.id == "plant", "A crossed furniture threshold grants ownership")
        require(store.finishExercise(id: session, activity: first, seconds: 20, complete: true) == nil && store.stars == 1,
                "A duplicate session must not mint another star")
        let partial = store.finishExercise(id: UUID(), activity: second, seconds: 3, complete: false)
        require(partial?.newActivity == nil && store.stars == 1 && !store.isUnlocked(third),
                "Early exits keep their time without stars or unlocks")
        let repeatReward = store.finishExercise(id: UUID(), activity: first, seconds: 20, complete: true)
        require(repeatReward?.newActivity == nil && store.stars == 2, "Repeat completion cannot re-unlock the same action")
        let nextReward = store.finishExercise(id: UUID(), activity: second, seconds: 20, complete: true)
        require(nextReward?.newActivity == third && store.stars == 3, "Second completion advances the chain")
        require(nextReward?.furniture.first?.id == "desk", "Desk is unlocked at three stars")
        require(store.checkin() && store.checkin() && store.profile.checkins.count == 1 && store.stars == 3,
                "Daily check-in is idempotent and grants no stars")
        let meditation = UUID()
        require(store.finishMeditation(id: meditation, seconds: 30), "Meditation is recorded")
        require(store.finishMeditation(id: meditation, seconds: 30) && store.stars == 3,
                "Meditation retry is idempotent and grants no stars")
        let recordsBefore = store.profile.records.count
        require(recordsBefore == 5, "Expected four exercise records and one meditation record")
        require(store.saveRoom([rug, plant]), "Valid user layout is persisted")
        let invalid = FurniturePlacement(id: "desk", x: 5, z: 0, turns: 0)
        require(!store.saveRoom([invalid]) && store.profile.placements == [rug, plant], "Invalid layout cannot replace saved data")
        let reloaded = AppStore(directory: directory)
        require(reloaded.stars == 3 && reloaded.profile.records.count == recordsBefore &&
                reloaded.profile.place == .outdoor && reloaded.profile.placements == [rug, plant],
                "State, history, unlocks and layout survive reloading")

        require(reloaded.profile.care == nil, "A v0.2 file opens without a care field")
        let today = Date()
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: today)!
        require(reloaded.toggleCare(.water, on: today) == .completed(earnedStar: true), "First daily check-in grants a star")
        require(reloaded.toggleCare(.water, on: today) == .removed, "Check-ins can be corrected")
        require(reloaded.toggleCare(.water, on: today) == .completed(earnedStar: false), "Corrections cannot repeat a reward")
        for habit in CareHabit.allCases where habit != .water {
            require(reloaded.toggleCare(habit, on: today) == .completed(earnedStar: true), "Other habits reward independently")
        }
        require(reloaded.careDay(on: today).completed.count == 6 && reloaded.stars == 9, "Six check-in stars share the furniture balance")
        require(reloaded.toggleCare(.water, on: yesterday) == .completed(earnedStar: true), "Another date has an independent ledger")
        reloaded.setCups(3, on: today)
        require(reloaded.configureCare(goal: 4, showsSleep: true), "Care preferences save")
        require(reloaded.setSleep(7.5, on: today), "Optional sleep record saves")
        require(reloaded.addHabit("课间走一走"), "Custom habit saves")
        let habit = reloaded.care.customHabits[0]
        require(reloaded.toggleCustomHabit(habit, on: today) == .completed(earnedStar: false), "Custom check-in does not raise the six-star limit")
        reloaded.removeHabit(habit.id)
        let restoredCare = AppStore(directory: directory)
        require(restoredCare.stars == 10 && restoredCare.care.waterGoal == 4 &&
                restoredCare.careDay(on: today).cups == 3 && restoredCare.careDay(on: today).sleepHours == 7.5 &&
                restoredCare.careDay(on: today).customDone[habit.id] == habit.title, "Care data and history survive reloading")
        require(restoredCare.careDay(on: yesterday).cups == 0, "Cup counts are independent per day")
        require(Activity.next(after: .careStretch) == nil, "Short care stretch is independent of regular unlock chains")
        let short = restoredCare.finishExercise(id: UUID(), activity: .careStretch, seconds: 60, complete: true)
        require(short != nil && short?.newActivity == nil && restoredCare.stars == 11, "Short stretch is a valid exercise session")

        let originalRoom = restoredCare.activeRoom
        require(originalRoom.id == RoomSpace.legacyID && originalRoom.placements == [rug, plant],
                "Legacy layouts become the first space")
        require(restoredCare.createRoom(named: "窗边"), "Create an independent space")
        let windowRoom = restoredCare.activeRoom.id
        var decor = Furniture.decorations.map {
            FurniturePlacement(id: $0.id, x: $0.defaultX, z: $0.defaultZ, turns: 0)
        }
        decor[0].x += 0.1
        decor[1].z += 0.1
        decor[2].z -= 0.1
        let desk = FurniturePlacement(id: "desk", x: -0.65, z: -1.08, turns: 0, finish: .mistBlue)
        decor[3] = FurniturePlacement(id: "books", x: 0.31, z: 0.09, turns: 0, supportID: desk.id)
        require(!Furniture.canPlace(decor[3], in: decor), "Books cannot float when their support is missing")
        require(restoredCare.saveRoom(decor + [desk], in: windowRoom), "Move and save wall and floor decor with a blue desk")
        require(restoredCare.createRoom(named: "读书角"), "A third space can be created")
        let readingRoom = restoredCare.activeRoom.id
        require(!restoredCare.createRoom(named: "第四个"), "A fourth space is rejected")
        var pinkDesk = desk
        pinkDesk.finish = .blush
        require(restoredCare.saveRoom([pinkDesk], in: readingRoom), "Save a different finish for the same furniture in another room")
        require(restoredCare.selectRoom(windowRoom), "Switch back to the second space")
        let restartedRooms = AppStore(directory: directory)
        require(restartedRooms.rooms.count == 3 && restartedRooms.activeRoom.id == windowRoom &&
                restartedRooms.activeRoom.placements == decor + [desk], "Selected room, decor and finish survive reopening")
        require(restartedRooms.selectRoom(readingRoom) && restartedRooms.activeRoom.placements == [pinkDesk],
                "The third space retains its independent layout")
        require(restartedRooms.renameRoom(readingRoom, to: "阅读角") &&
                restartedRooms.activeRoom.title == "阅读角", "Rename saves the active space title")
        require(restartedRooms.deleteRoom(readingRoom) && restartedRooms.activeRoom == originalRoom,
                "Deleting the active room returns to the restored legacy layout")
        require(AppStore(directory: directory).rooms.count == 2, "Deletion survives reopening")

        let oldPlant = FurniturePlacement(id: "smallPlant", x: -1.19, z: -0.43, turns: 0)
        let oldRug = FurniturePlacement(id: "smallRug", x: 0.85, z: 0.85, turns: 0)
        var oldProfile = restartedRooms.profile
        oldProfile.roomSpaces = [
            originalRoom,
            RoomSpace(id: windowRoom, title: "窗边", placements: [oldPlant, oldRug, desk]),
            RoomSpace(id: readingRoom, title: "阅读角", placements: [oldRug])
        ]
        oldProfile.activeRoomID = windowRoom
        try JSONEncoder().encode(oldProfile).write(to: file)
        let migrated = AppStore(directory: directory)
        require(migrated.activeRoom.id == windowRoom &&
                Set(migrated.activeRoom.placements.map(\.id)) == ["wallClock", "books", "desk"] &&
                migrated.activeRoom.placements.contains(desk) &&
                migrated.activeRoom.placements.first(where: { $0.id == "books" })?.supportID == "desk",
                "Legacy decor moves to a wall clock and supported books without changing the desk")
        require(migrated.selectRoom(readingRoom) && migrated.activeRoom.placements.count == 1 &&
                migrated.activeRoom.placements.first?.id == "books" &&
                migrated.activeRoom.placements.first?.supportID == nil,
                "A second legacy arrangement uses the built-in shelf when a desk is unavailable")
        require(AppStore(directory: directory).activeRoom == migrated.activeRoom,
                "Migrated decor and active room survive save and reload")

        let suiteName = "OtterMove-checks-" + UUID().uuidString
        guard let defaults = UserDefaults(suiteName: suiteName) else { fatalError("Unable to create test preferences") }
        defer { defaults.removePersistentDomain(forName: suiteName) }
        let mood = MoodStore(defaults: defaults)
        require(mood.save(.happy, summary: "开心的一天", date: today), "A mood saves for today")
        let firstMoodID = mood.record(for: today)?.id
        require(mood.save(.relaxed, summary: "慢慢来", date: today), "A mood can be replaced the same day")
        require(mood.save(.tired, summary: "好好休息", date: yesterday), "Different days retain independent moods")
        let restoredMood = MoodStore(defaults: defaults)
        require(restoredMood.history.count == 2 && restoredMood.record(for: today)?.id == firstMoodID &&
                restoredMood.record(for: today)?.mood == .relaxed && restoredMood.record(for: yesterday)?.mood == .tired,
                "Same-day replacement and separate days persist correctly")
        require(MoodType.relaxed.summary(excluding: MoodType.relaxed.summaries[0]) != MoodType.relaxed.summaries[0],
                "Changing a summary produces a different sentence")
        for current in MoodType.allCases {
            require(restoredMood.save(current, summary: current.summaries[0], date: today) &&
                    MoodStore(defaults: defaults).record(for: today)?.mood == current,
                    "Each selectable mood survives reloading")
        }
        let oldMood = try JSONEncoder().encode(MoodRecord(id: UUID(), date: today, mood: .relaxed, summary: "旧记录"))
        let legacyMood = Data(String(decoding: oldMood, as: UTF8.self)
            .replacingOccurrences(of: "\"relaxed\"", with: "\"hardworking\"").utf8)
        let migratedMood = try JSONDecoder().decode(MoodRecord.self, from: legacyMood)
        require(migratedMood.mood == .tired,
                "An older hardworking record becomes tired")

        let broken = Data("invalid JSON".utf8)
        try broken.write(to: file)
        let damaged = AppStore(directory: directory)
        damaged.errorMessage = nil
        require(!damaged.checkin(), "Dismissing a read error cannot enable overwrite")
        let stillBroken = try Data(contentsOf: file)
        require(stillBroken == broken, "Unreadable user data must be preserved")
        print("Core checks passed: timers, unlocks, rewards, history, room layout, and persistence.")
    }
}
