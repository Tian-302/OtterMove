import Foundation
import Combine
import HealthKit

@MainActor
final class HealthReference: ObservableObject {
    private lazy var store = HKHealthStore()
    private let defaults = UserDefaults.standard
    private let preference = "otter.healthReference"
    private let water = HKQuantityType.quantityType(forIdentifier: .dietaryWater)
    private let stepCount = HKQuantityType.quantityType(forIdentifier: .stepCount)
    private let standHour = HKCategoryType.categoryType(forIdentifier: .appleStandHour)
    private var lastRefresh: Date?
    private var requestID = UUID()

    @Published private(set) var enabled = false
    @Published private(set) var loading = false
    @Published private(set) var message: String?
    @Published private(set) var steps: Int?
    @Published private(set) var waterMilliliters: Int?
    @Published private(set) var shouldSuggestMovement = false

    init() { enabled = defaults.bool(forKey: preference) }

    func matches(_ date: Date) -> Bool {
        lastRefresh.map { Calendar.current.isDate($0, inSameDayAs: date) } ?? false
    }

    func connect() async {
        guard !loading else { return }
        guard HKHealthStore.isHealthDataAvailable() else {
            message = "这台设备暂时无法提供健康数据，可以继续手动打卡。"
            return
        }
        var types: Set<HKObjectType> = []
        if let water { types.insert(water) }
        if let stepCount { types.insert(stepCount) }
        if let standHour { types.insert(standHour) }
        guard !types.isEmpty else { return }

        loading = true
        defer { loading = false }
        do {
            try await store.requestAuthorization(toShare: [], read: types)
            enabled = true
            defaults.set(true, forKey: preference)
            await readReferences()
        } catch {
            message = "暂时无法连接 Apple 健康，可以继续手动打卡。"
        }
    }

    func refreshIfNeeded() async {
        guard enabled, !loading else { return }
        if let lastRefresh, Date().timeIntervalSince(lastRefresh) < 300, matches(Date()) { return }
        await refresh()
    }

    func refresh() async {
        guard enabled, !loading else { return }
        loading = true
        defer { loading = false }
        await readReferences()
    }

    func disable() {
        defaults.set(false, forKey: preference)
        enabled = false
        requestID = UUID()
        lastRefresh = nil
        steps = nil
        waterMilliliters = nil
        shouldSuggestMovement = false
        message = nil
    }

    private func readReferences() async {
        guard HKHealthStore.isHealthDataAvailable() else {
            message = "健康数据暂不可用。"
            return
        }
        let id = UUID()
        requestID = id
        let end = Date()
        let start = Calendar.current.startOfDay(for: end)
        let today = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        async let waters = total(for: water, unit: .literUnit(with: .milli), predicate: today)
        async let stepSum = total(for: stepCount, unit: .count(), predicate: today)
        async let movement = recentIdleHours(before: end)
        let (waterValue, stepsValue, idleHours) = await (waters, stepSum, movement)
        guard enabled, requestID == id else { return }
        lastRefresh = end
        waterMilliliters = waterValue
        steps = stepsValue
        shouldSuggestMovement = idleHours
        message = waterValue == nil && stepsValue == nil
            ? "暂无可显示的饮水或步数记录。你可以在健康 App 管理授权。"
            : nil
    }

    private func total(for type: HKQuantityType?, unit: HKUnit, predicate: NSPredicate) async -> Int? {
        guard let type else { return nil }
        return await withCheckedContinuation { continuation in
            let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate, options: .cumulativeSum) {
                _, result, _ in
                let amount = result?.sumQuantity()?.doubleValue(for: unit)
                let value = amount.flatMap { Int(exactly: $0.rounded()) }
                continuation.resume(returning: value)
            }
            store.execute(query)
        }
    }

    private func recentIdleHours(before date: Date) async -> Bool {
        guard let standHour else { return false }
        let start = date.addingTimeInterval(-3 * 3600)
        let predicate = HKQuery.predicateForSamples(withStart: start, end: date, options: .strictEndDate)
        return await withCheckedContinuation { continuation in
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
            let query = HKSampleQuery(sampleType: standHour, predicate: predicate, limit: 12, sortDescriptors: [sort]) {
                _, samples, _ in
                let hours = (samples as? [HKCategorySample]) ?? []
                let calendar = Calendar.current
                let uniqueHours = Dictionary(grouping: hours) {
                    calendar.dateInterval(of: .hour, for: $0.startDate)?.start ?? $0.startDate
                }
                let recent = uniqueHours.keys.sorted(by: >).prefix(2)
                guard let latest = recent.first, let previous = recent.last, recent.count == 2,
                      latest.timeIntervalSince(previous) == 3600,
                      date.timeIntervalSince(latest) < 2 * 3600 else {
                    continuation.resume(returning: false)
                    return
                }
                let idle = HKCategoryValueAppleStandHour.idle.rawValue
                continuation.resume(returning: recent.allSatisfy {
                    uniqueHours[$0]?.allSatisfy { $0.value == idle } == true
                })
            }
            store.execute(query)
        }
    }
}
