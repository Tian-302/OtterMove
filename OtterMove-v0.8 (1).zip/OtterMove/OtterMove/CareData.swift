import Foundation

enum CareHabit: String, Codable, CaseIterable, Identifiable {
    case water, shoulders, outdoor, bedtime, meals, eyes
    var id: Self { self }
    var title: String {
        switch self {
        case .water: "好好喝水"
        case .shoulders: "肩颈放松"
        case .outdoor: "户外透气"
        case .bedtime: "按时休息"
        case .meals: "好好吃饭"
        case .eyes: "眼睛休息"
        }
    }
    var detail: String {
        switch self {
        case .water: "按自己的节奏，给自己补点水。"
        case .shoulders: "放下手头的事，轻轻活动肩颈。"
        case .outdoor: "到户外走动 5 分钟，透一口气。"
        case .bedtime: "比平时早一点放下手头的事。"
        case .meals: "给自己留出时间，好好吃正餐。"
        case .eyes: "离开屏幕，看看远处或闭眼休息。"
        }
    }
    var symbol: String {
        switch self {
        case .water: "drop.fill"
        case .shoulders: "figure.cooldown"
        case .outdoor: "leaf.fill"
        case .bedtime: "moon.zzz.fill"
        case .meals: "fork.knife"
        case .eyes: "eye"
        }
    }
    var art: String { "care_" + rawValue }
}

struct CustomHabit: Codable, Identifiable {
    let id: UUID
    let title: String
}

struct CareDay: Codable {
    var completed: Set<CareHabit> = []
    // Reward history is retained if the user edits a check-in.
    var rewarded: Set<CareHabit> = []
    var cups = 0
    var sleepHours: Double?
    var customDone: [UUID: String] = [:]

    var hasEntries: Bool {
        !completed.isEmpty || cups > 0 || sleepHours != nil || !customDone.isEmpty
    }
    var hasCheckin: Bool { !completed.isEmpty || !customDone.isEmpty }
}

struct CareProfile: Codable {
    var days: [String: CareDay] = [:]
    var waterGoal: Int?
    var showsSleep = false
    var customHabits: [CustomHabit] = []

    var stars: Int { days.values.reduce(0) { $0 + $1.rewarded.count } }

    mutating func toggle(_ habit: CareHabit, on key: String) -> CareChange {
        var day = days[key] ?? CareDay()
        let change: CareChange
        if day.completed.remove(habit) != nil {
            change = .removed
        } else {
            day.completed.insert(habit)
            change = .completed(earnedStar: day.rewarded.insert(habit).inserted)
        }
        days[key] = day
        return change
    }
}

enum CareChange: Equatable {
    case completed(earnedStar: Bool), removed
}
