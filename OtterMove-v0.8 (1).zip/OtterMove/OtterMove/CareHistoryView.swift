import SwiftUI

struct CareHistoryView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var moods: MoodStore
    @EnvironmentObject private var store: AppStore
    @State private var month = Calendar.current.dateInterval(of: .month, for: Date())?.start ?? Date()
    @State private var selectedDate = Calendar.current.startOfDay(for: Date())
    private let calendar = Calendar.current
    private let columns = Array(repeating: GridItem(.flexible()), count: 7)

    private var monthText: String { month.formatted(.dateTime.year().month(.wide)) }
    private var cells: [Date?] {
        guard let interval = calendar.dateInterval(of: .month, for: month),
              let range = calendar.range(of: .day, in: .month, for: month) else { return [] }
        let weekday = calendar.component(.weekday, from: interval.start)
        let empty = (weekday - calendar.firstWeekday + 7) % 7
        let days = range.compactMap { calendar.date(byAdding: .day, value: $0 - 1, to: interval.start) }
        return Array(repeating: nil, count: empty) + days.map { Optional($0) }
    }
    private var selectedRecords: [ActivityRecord] {
        store.profile.records.filter { calendar.isDate($0.date, inSameDayAs: selectedDate) }
            .sorted { $0.date > $1.date }
    }
    private var weekLabels: [String] {
        let symbols = calendar.veryShortStandaloneWeekdaySymbols
        let offset = calendar.firstWeekday - 1
        return Array(symbols[offset...]) + Array(symbols[..<offset])
    }

    var body: some View {
        NavigationStack {
            calendarContent
                .navigationTitle("打卡日历")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("完成") { dismiss() } } }
        }
        .tint(WellnessPalette.sageInk)
    }

    private var calendarContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                weeklyReview
                VStack(spacing: 14) {
                    HStack {
                        Button { moveMonth(-1) } label: { Image(systemName: "chevron.left").frame(width: 44, height: 44) }
                            .accessibilityLabel("上个月")
                        Spacer()
                        Text(monthText).font(.headline)
                        Spacer()
                        Button { moveMonth(1) } label: { Image(systemName: "chevron.right").frame(width: 44, height: 44) }
                            .accessibilityLabel("下个月")
                    }
                    LazyVGrid(columns: columns, spacing: 8) {
                        ForEach(weekLabels.indices, id: \.self) { index in
                            Text(weekLabels[index]).font(.caption).foregroundStyle(.secondary)
                        }
                        ForEach(cells.indices, id: \.self) { index in
                            if let date = cells[index] { dayCell(date) }
                            else { Color.clear.frame(height: 44) }
                        }
                    }
                }
                .otterCard()
                Text(selectedDate.formatted(.dateTime.month().day()) + "的记录")
                    .font(.headline)
                selectedCare
                ForEach(selectedRecords) { record in
                    HStack {
                        Image(systemName: record.kind == "meditation" ? "sun.horizon" : "dumbbell")
                        VStack(alignment: .leading, spacing: 4) {
                            Text(record.title).font(.subheadline.weight(.medium))
                            Text("\(record.seconds) 秒 · " + (record.complete ? "已完成" : "提前结束"))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(record.date.formatted(date: .omitted, time: .shortened))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    .otterCard()
                }
            }
            .padding(22)
        }
        .buttonStyle(.plain)
        .background(WellnessPalette.cream.ignoresSafeArea())
    }

    private var weeklyReview: some View {
        let now = Date()
        let start = calendar.dateInterval(of: .weekOfYear, for: now)?.start ?? calendar.startOfDay(for: now)
        let days = (0..<7).compactMap { calendar.date(byAdding: .day, value: $0, to: start) }
            .filter { $0 <= now }
        let entries = CareHabit.allCases.map { habit in
            (habit: habit, count: days.filter { store.careDay(on: $0).completed.contains(habit) }.count)
        }.filter { $0.count > 0 }

        return VStack(alignment: .leading, spacing: 10) {
            Label("本周的小关照", systemImage: "leaf.fill")
                .font(WellnessPalette.font(.headline, weight: .semibold))
                .foregroundStyle(WellnessPalette.sageInk)
            if entries.isEmpty {
                Text("这周记录的小事，会出现在这里。").font(.subheadline)
                    .foregroundStyle(WellnessPalette.muted)
            }
            ForEach(entries.indices, id: \.self) { index in
                let entry = entries[index]
                HStack {
                    Text(entry.habit.title)
                    Spacer()
                    Text("\(entry.count) 天").foregroundStyle(WellnessPalette.muted)
                }
                .font(.subheadline)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .wellnessCard(fill: WellnessPalette.greenSoft)
    }

    private var selectedCare: some View {
        let day = store.careDay(on: selectedDate)
        let mood = moods.record(for: selectedDate)
        return VStack(alignment: .leading, spacing: 9) {
            ForEach(CareHabit.allCases.filter { day.completed.contains($0) }) { habit in
                Label(habit.title, systemImage: habit.symbol)
            }
            ForEach(day.customDone.values.sorted(), id: \.self) { title in
                Label(title, systemImage: "checkmark.circle")
            }
            if day.cups > 0 { Label("喝水 \(day.cups) 杯", systemImage: "drop") }
            if let sleep = day.sleepHours {
                Label("睡眠 \(sleep.formatted(.number.precision(.fractionLength(0...1)))) 小时", systemImage: "bed.double")
            }
            if store.profile.checkins.contains(AppStore.dayKey(selectedDate)) {
                Label("打卡记号", systemImage: "pawprint")
            }
            if let mood {
                Label(mood.mood.title, systemImage: "heart")
                Text(mood.summary).foregroundStyle(WellnessPalette.muted)
            }
            if !day.hasEntries && mood == nil && selectedRecords.isEmpty && !store.didCheckin(on: selectedDate) {
                Text("这一天还没有记录。").foregroundStyle(WellnessPalette.muted)
            }
        }
        .font(.subheadline)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func moveMonth(_ delta: Int) {
        if let value = calendar.date(byAdding: .month, value: delta, to: month) { month = value }
    }
    private func dayCell(_ date: Date) -> some View {
        let selected = calendar.isDate(date, inSameDayAs: selectedDate)
        let hasCare = store.didCheckin(on: date) || store.careDay(on: date).hasEntries
        let hasOtherRecord = store.hasActivity(on: date) || moods.record(for: date) != nil
        return Button { selectedDate = date } label: {
            VStack(spacing: 3) {
                Text("\(calendar.component(.day, from: date))").font(.subheadline)
                Circle()
                    .fill(hasOtherRecord ? Palette.blue : Color.clear)
                    .frame(width: 5, height: 5)
            }
            .frame(maxWidth: .infinity, minHeight: 44)
            .background(hasCare ? WellnessPalette.greenSoft : Color.clear, in: RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(
                selected ? WellnessPalette.sageInk : Color.clear, lineWidth: 1.5))
        }
        .accessibilityLabel(date.formatted(date: .complete, time: .omitted) +
                            (hasCare ? "，有健康记录" : hasOtherRecord ? "，有记录" : ""))
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}
