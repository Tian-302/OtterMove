import Foundation

enum OtterMotion: String, Equatable {
    case rest, paws, shrug, look, stand, stretch, walk, circle, wind

    init(activity: Activity) { self = OtterMotion(rawValue: activity.motion) ?? .rest }
}

struct JointAngles {
    var x = 0.0
    var y = 0.0
    var z = 0.0
}

struct OtterArmPose {
    var shoulder = JointAngles()
    var lift = 0.0
    var reach = 0.0
    var elbow = -0.12
    var wrist = 0.0
    var curl = 0.15
}

struct OtterLegPose {
    var hip = 0.0
    var knee = 0.0
    var ankle = 0.0
}

enum OtterEyes: Equatable { case open, smiling, relaxed, worried, sleepy, focused, wide }
enum OtterMouth: Hashable { case gentle, laugh, worried, yawn, surprised, focused }

/// Angles are radians. Distance is expressed in the character's local units.
struct OtterPose {
    static let hipHeight = 0.664
    static let thigh = 0.29
    static let shin = 0.28
    static let ankleHeight = 0.12

    var rootYaw = 0.14
    var rootX = 0.0
    var rootY = 0.0
    var body = JointAngles()
    var head = JointAngles()
    var tail = JointAngles()
    var left = OtterArmPose(shoulder: JointAngles(z: -0.18))
    var right = OtterArmPose(shoulder: JointAngles(z: 0.18))
    var leftLeg = OtterLegPose()
    var rightLeg = OtterLegPose()
    var eyes = OtterEyes.open
    var mouth = OtterMouth.gentle
    var blinking = false
    var seated = false

    static func sample(_ motion: OtterMotion, time: TimeInterval, mood: MoodType? = nil,
                       outdoors: Bool = false) -> OtterPose {
        let t = max(0, time)
        let breath = sin(t * 1.8)
        var pose = OtterPose()
        pose.rootY = 0.006 * breath
        pose.body = JointAngles(x: 0.013 * breath, z: 0.023 * sin(t * 1.05))
        pose.head = JointAngles(x: -0.06 + 0.017 * breath, y: 0.05 * sin(t * 0.88))
        pose.tail = JointAngles(y: 0.10 * sin(t * 1.55), z: 0.027 * breath)
        let blink = t.truncatingRemainder(dividingBy: 4.7)
        pose.blinking = (3.98...4.12).contains(blink)
        pose.seated = motion == .paws || motion == .shrug || motion == .look

        switch motion {
        case .paws:
            let close = ease(cycle(t, duration: 3.0))
            pose.left.shoulder.x = -0.61
            pose.right.shoulder.x = -0.61
            pose.left.elbow = -0.89 + 0.15 * close
            pose.right.elbow = pose.left.elbow
            pose.left.wrist = -0.26 + 0.23 * close
            pose.right.wrist = pose.left.wrist
            pose.left.curl = close
            pose.right.curl = close
            pose.head.x += 0.09 * close
        case .shrug:
            let lift = 0.115 * ease(cycle(t, duration: 4.4))
            pose.left.lift = lift
            pose.right.lift = lift
            pose.left.shoulder.y = -0.16 * lift / 0.115
            pose.right.shoulder.y = -pose.left.shoulder.y
            pose.head.x -= lift * 0.26
        case .look:
            let gaze = ease(cycle(t, duration: 5.6))
            pose.head = JointAngles(x: -0.07 - 0.25 * gaze, y: 0.62 * gaze, z: 0.045 * gaze)
            pose.left.elbow = -0.38
            pose.right.elbow = -0.38
        case .stretch:
            let reach = holdAtTop(t, duration: 5.3)
            pose.left.shoulder = JointAngles(x: -0.13 - 0.16 * reach, z: -0.18 - 2.58 * reach)
            pose.right.shoulder = JointAngles(x: -0.15 - 0.15 * reach, z: 0.18 + 2.58 * reach)
            pose.left.elbow = -0.26 + 0.22 * reach
            pose.right.elbow = pose.left.elbow
            pose.left.lift = 0.042 * reach
            pose.right.lift = pose.left.lift
            pose.body.x = -0.145 * reach
            pose.head.x = -0.25 * reach
            pose.eyes = reach > 0.72 ? .smiling : .open
        case .walk:
            let period = outdoors ? 1.48 : 1.78
            let u = t / period
            let wave = cos(u * 2 * .pi)
            pose.rootYaw = outdoors ? 0.41 : 0.27
            pose.rootX = 0.074 * sin(u * 2 * .pi)
            let stepHeight = sin(u * 2 * .pi)
            pose.rootY = -0.042 + 0.028 * stepHeight * stepHeight
            pose.body = JointAngles(x: 0.10, y: 0.13 * wave, z: 0.055 * wave)
            pose.head = JointAngles(x: -0.06, y: -0.06 * wave, z: -0.027 * wave)
            pose.left.shoulder.x = -0.48 * wave
            pose.right.shoulder.x = 0.48 * wave
            pose.left.elbow = -0.19 - 0.21 * max(0, wave)
            pose.right.elbow = -0.19 - 0.21 * max(0, -wave)
            pose.tail.y = 0.21 * wave
            pose.leftLeg = walkingFoot(u, hipY: pose.rootY, stride: outdoors ? 0.47 : 0.40)
            pose.rightLeg = walkingFoot(u + 0.5, hipY: pose.rootY, stride: outdoors ? 0.47 : 0.40)
        case .circle:
            let phase = t * 2 * .pi / 4.4
            pose.left.lift = 0.052 + 0.061 * sin(phase)
            pose.right.lift = pose.left.lift
            pose.left.reach = 0.078 * cos(phase)
            pose.right.reach = pose.left.reach
            pose.left.shoulder.x = -0.19 * cos(phase)
            pose.right.shoulder.x = pose.left.shoulder.x
            pose.body.x = -0.043 * cos(phase)
        case .stand:
            let sway = sin(t * 2 * .pi / 6.4)
            pose.body.z = 0.046 * sway
            pose.head.z = -0.036 * sway
            pose.rootX = 0.033 * sway
        case .wind:
            pose.eyes = .relaxed
            pose.head = JointAngles(x: -0.19 - 0.055 * breath, y: 0.26 + 0.10 * sin(t * 0.86))
            pose.left.shoulder.z = -0.25 - 0.06 * breath
            pose.right.shoulder.z = 0.25 + 0.06 * breath
            pose.tail.y = 0.18 * sin(t * 1.1)
        case .rest:
            if let mood { pose.apply(mood, time: t) }
        }

        if pose.seated {
            pose.rootYaw = 0.08
            pose.rootY = 0.26 + 0.004 * breath
            pose.leftLeg = OtterLegPose(hip: -1.32, knee: 1.18, ankle: 0.11)
            pose.rightLeg = pose.leftLeg
        } else if motion != .walk {
            pose.leftLeg = leg(ankleY: ankleHeight, ankleZ: 0.017, hipY: pose.rootY, pitch: 0)
            pose.rightLeg = leg(ankleY: ankleHeight, ankleZ: -0.013, hipY: pose.rootY, pitch: 0)
        }

        return pose
    }

    func greeting(_ elapsed: TimeInterval) -> OtterPose {
        guard elapsed >= 0, elapsed < 2 else { return self }
        let lift = Self.ease(min(1, min(elapsed / 0.38, (2 - elapsed) / 0.43)))
        var pose = self
        pose.right.shoulder.z += (1.61 - pose.right.shoulder.z) * lift
        pose.right.shoulder.x += (-0.44 - pose.right.shoulder.x) * lift
        pose.right.elbow += (-0.49 - pose.right.elbow) * lift
        pose.right.wrist += lift * 0.36 * sin(elapsed * 11.0)
        pose.right.curl *= 1 - lift
        pose.head.z += 0.052 * lift
        return pose
    }

    private mutating func apply(_ mood: MoodType, time t: TimeInterval) {
        let rhythm = sin(t * 1.85)
        switch mood {
        case .happy:
            eyes = .smiling
            mouth = .laugh
            head.z = 0.06 + 0.055 * rhythm
            left.shoulder = JointAngles(x: -0.36, z: -0.36)
            right.shoulder = JointAngles(x: -0.36, z: 0.36)
            left.elbow = -0.87 - 0.12 * rhythm
            right.elbow = left.elbow
        case .relaxed:
            eyes = .relaxed
            head.x = -0.09 + 0.045 * rhythm
            head.z = 0.087 + 0.028 * rhythm
            left.elbow = -0.40
            right.elbow = -0.46
        case .anxious:
            eyes = .worried
            mouth = .worried
            head = JointAngles(x: 0.07, y: 0.16 * sin(t * 1.45), z: 0.052)
            left.shoulder = JointAngles(x: -0.54, z: -0.07)
            right.shoulder = JointAngles(x: -0.54, z: 0.07)
            left.elbow = -1.20 - 0.12 * rhythm
            right.elbow = left.elbow
            left.curl = 0.68
            right.curl = 0.68
        case .tired:
            eyes = .sleepy
            let yawn = Self.holdAtTop(t, duration: 6.6)
            mouth = yawn > 0.46 ? .yawn : .gentle
            head.x = -0.22 * yawn + 0.10
            head.z = 0.10
            right.shoulder.x = -0.68 * yawn
            right.elbow = -0.19 - 1.14 * yawn
            right.shoulder.z = 0.11
        case .annoyed:
            eyes = .focused
            mouth = .focused
            head.x = 0.11 + 0.041 * rhythm
            head.y = -0.12
            body.x = 0.10
            right.shoulder = JointAngles(x: -0.58, z: 0.28)
            right.elbow = -1.15 - 0.08 * rhythm
            right.curl = 0.65
        case .sad:
            eyes = .worried
            mouth = .worried
            head.x = 0.17
            head.z = 0.04 * rhythm
            left.shoulder = JointAngles(x: -0.42, z: -0.25)
            right.shoulder = JointAngles(x: -0.42, z: 0.25)
            left.elbow = -0.86
            right.elbow = left.elbow
        }
    }

    private static func walkingFoot(_ cycle: Double, hipY: Double, stride: Double) -> OtterLegPose {
        let phase = cycle - floor(cycle)
        let stance = 0.57
        let z: Double
        let y: Double
        let pitch: Double
        if phase < stance {
            let progress = phase / stance
            z = stride * (0.5 - progress)
            y = ankleHeight
            pitch = -0.15 * sin(progress * .pi * 2)
        } else {
            let u = (phase - stance) / (1 - stance)
            z = stride * (ease(u) - 0.5)
            y = ankleHeight + 0.18 * sin(.pi * u)
            pitch = 0.30 * sin(.pi * 2 * u)
        }
        return leg(ankleY: y, ankleZ: z, hipY: hipY, pitch: pitch)
    }

    /// Two-link inverse kinematics keep each stance foot on the ground.
    private static func leg(ankleY: Double, ankleZ: Double, hipY: Double, pitch: Double) -> OtterLegPose {
        let down = hipHeight + hipY - ankleY
        let distance = min(thigh + shin - 0.0001, max(0.10, hypot(down, ankleZ)))
        let target = atan2(-ankleZ, down)
        let angle = acos(clampCos((thigh * thigh + distance * distance - shin * shin) / (2 * thigh * distance)))
        let knee = .pi - acos(clampCos((thigh * thigh + shin * shin - distance * distance) / (2 * thigh * shin)))
        let hip = target - angle
        return OtterLegPose(hip: hip, knee: knee, ankle: -(hip + knee) + pitch)
    }

    private static func clampCos(_ value: Double) -> Double { min(1, max(-1, value)) }
    private static func cycle(_ t: Double, duration: Double) -> Double { (1 - cos(t / duration * 2 * .pi)) / 2 }
    private static func ease(_ t: Double) -> Double { t * t * (3 - 2 * t) }

    private static func holdAtTop(_ time: Double, duration: Double) -> Double {
        let p = time.truncatingRemainder(dividingBy: duration) / duration
        if p < 0.43 { return ease(p / 0.43) }
        if p < 0.64 { return 1 }
        return 1 - ease((p - 0.64) / 0.36)
    }
}
