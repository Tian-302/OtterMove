import AVFoundation
import Combine
import Foundation

@MainActor
final class MeditationAudio: ObservableObject {
    @Published private(set) var problem: String?

    private var player: AVAudioPlayer?
    private var loadedTrack: MeditationTrack?
    private var sessionIsActive = false

    /// Switches only the audio track. The session timer lives in MeditationView.
    func update(track: MeditationTrack, volume: Double, playing: Bool) {
        if loadedTrack != track {
            stop()
            player = nil
            loadedTrack = track
            problem = nil
        }
        guard let filename = track.filename else { return }
        guard playing else { pause(); return }

        do {
            if player == nil {
                guard let url = Bundle.main.url(forResource: filename, withExtension: "m4a") else {
                    problem = "缺少音频资源：\(filename).m4a"
                    return
                }
                let loop = try AVAudioPlayer(contentsOf: url)
                loop.numberOfLoops = -1
                loop.prepareToPlay()
                player = loop
            }
            guard let player else { return }
            if !sessionIsActive {
                let session = AVAudioSession.sharedInstance()
                try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
                try session.setActive(true)
                sessionIsActive = true
            }
            setVolume(volume)
            problem = (player.isPlaying || player.play()) ? nil : "音乐暂时无法播放"
        } catch {
            problem = "音乐暂时无法播放"
        }
    }

    func setVolume(_ volume: Double) {
        player?.volume = Float(min(1, max(0, volume)))
    }

    func pause() {
        player?.pause()
        releaseAudioSession()
    }

    func stop() {
        player?.stop()
        player?.currentTime = 0
        releaseAudioSession()
    }

    private func releaseAudioSession() {
        guard sessionIsActive else { return }
        try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
        sessionIsActive = false
    }
}
