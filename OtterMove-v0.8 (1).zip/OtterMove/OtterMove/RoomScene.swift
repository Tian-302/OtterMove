import SwiftUI

private let roomPitch: Float = 0.46

extension FurnitureSurface {
    func placementDelta(horizontal: Float, vertical: Float) -> (x: Float, z: Float) {
        if isWall {
            let alongWall = self == .windowWall ? horizontal : -horizontal
            return (alongWall, alongWall * roomPitch - vertical)
        }
        let sum = vertical / roomPitch
        return ((sum + horizontal) / 2, (sum - horizontal) / 2)
    }
}

extension FurniturePlacement {
    func dragDelta(horizontal: Float, vertical: Float, in placements: [FurniturePlacement]) -> (x: Float, z: Float) {
        let surface = Furniture.find(id)?.surface ?? .floor
        guard surface == .tabletop else {
            return surface.placementDelta(horizontal: horizontal, vertical: vertical)
        }
        guard let support = placements.first(where: { $0.id == supportID }) else {
            return (-horizontal, 0)
        }
        let delta = FurnitureSurface.floor.placementDelta(horizontal: horizontal, vertical: vertical)
        return support.rotateOffset(delta.x, delta.z, inverse: true)
    }
}

extension FurnitureFinish {
    var highlight: Color {
        switch self {
        case .cream: rgb(0xfff4df)
        case .wood: rgb(0xe8be86)
        case .mistBlue: rgb(0xb5ccdb)
        case .blush: rgb(0xefc9c3)
        }
    }

    fileprivate var shade: Color {
        switch self {
        case .cream: rgb(0xd5bca0)
        case .wood: rgb(0xb18355)
        case .mistBlue: rgb(0x7f9eaf)
        case .blush: rgb(0xc28e87)
        }
    }
}

/// One projection is used by the floor, hit targets, and movement gestures.
private struct RoomProjection {
    let center: CGPoint
    let unit: CGFloat

    init(_ size: CGSize) {
        let scale = min(size.width / 6.65, size.height / 5.35)
        unit = scale
        center = CGPoint(x: size.width / 2, y: size.height / 2 + 0.85 * scale)
    }

    init(center: CGPoint, unit: CGFloat) {
        self.center = center
        self.unit = unit
    }

    func project(_ x: CGFloat, _ z: CGFloat, _ y: CGFloat = 0) -> CGPoint {
        CGPoint(x: center.x + (x - z) * unit,
                y: center.y + ((x + z) * CGFloat(roomPitch) - y) * unit)
    }

    func wallPoint(_ surface: FurnitureSurface, _ along: CGFloat, _ height: CGFloat,
                   inset: CGFloat = -1.51) -> CGPoint {
        surface == .windowWall ? project(along, inset, height) : project(inset, along, height)
    }
}

struct RoomScene: View {
    @Binding var placements: [FurniturePlacement]
    @Binding var selected: String?
    let editing: Bool
    @State private var dragStart: FurniturePlacement?

    var body: some View {
        GeometryReader { geometry in
            let projection = RoomProjection(geometry.size)
            let items = sortedFurniture
            let books = placements.first { $0.id == "books" }
            ZStack {
                Canvas { context, _ in
                    drawRoom(context, projection)
                    var otterDrawn = false
                    for placement in items {
                        if !otterDrawn && drawLayer(for: placement.id) == 2 && placement.x + placement.z >= 0.9 {
                            drawOtter(context, projection)
                            otterDrawn = true
                        }
                        drawItem(context, projection: projection, placement: placement,
                                 selected: editing && placement.id == selected)
                        if let books, books.supportID == placement.id,
                           let style = Furniture.find(placement.id), let height = style.topHeight {
                            let world = bookWorldPlacement(books, on: placement)
                            drawBooks(context, projection: projection, placement: world, height: CGFloat(height),
                                      selected: editing && selected == books.id)
                        }
                    }
                    if !otterDrawn { drawOtter(context, projection) }
                }
                .allowsHitTesting(false)
                .accessibilityHidden(true)

                if editing {
                    ForEach(items) { placement in
                        if let item = Furniture.find(placement.id) {
                            handle(item: item, placement: placement, projection: projection)
                        }
                    }
                    if let books, books.supportID != nil, let item = Furniture.find(books.id) {
                        handle(item: item, placement: books, projection: projection)
                    }
                }
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .coordinateSpace(name: "room-floor")
        }
        .background(
            RadialGradient(colors: [rgb(0xfff9ee), rgb(0xf5ebdf)], center: .topLeading,
                           startRadius: 10, endRadius: 440),
            in: RoundedRectangle(cornerRadius: 25)
        )
    }

    private var sortedFurniture: [FurniturePlacement] {
        placements.filter { $0.supportID == nil }.sorted { a, b in
            let rankA = drawLayer(for: a.id), rankB = drawLayer(for: b.id)
            if rankA != rankB { return rankA < rankB }
            if a.x + a.z == b.x + b.z { return a.id < b.id }
            return a.x + a.z < b.x + b.z
        }
    }

    private func drawLayer(for id: String) -> Int {
        switch Furniture.find(id)?.surface ?? .floor {
        case .windowWall, .sideWall, .tabletop: 0
        case .rug: 1
        case .floor: 2
        }
    }

    private func bookWorldPlacement(_ books: FurniturePlacement, on support: FurniturePlacement) -> FurniturePlacement {
        let offset = support.rotateOffset(books.x, books.z)
        return FurniturePlacement(id: books.id, x: support.x + offset.x, z: support.z + offset.z,
                                  turns: support.turns)
    }

    private func drawOtter(_ context: GraphicsContext, _ p: RoomProjection) {
        let foot = p.project(0, 0.90, 0.014)
        drawContactShadow(context, at: foot, width: p.unit * 0.83, height: p.unit * 0.23, opacity: 0.23)
        let image = context.resolve(Image("otter8_room_seated"))
        let height = p.unit * 0.91
        let width = height * image.size.width / max(1, image.size.height)
        context.draw(image, in: CGRect(x: foot.x - width * 0.49, y: foot.y - height * 0.98,
                                       width: width, height: height))
    }

    private func handle(item: Furniture, placement: FurniturePlacement, projection: RoomProjection) -> some View {
        let isRug = item.surface == .rug
        let x = CGFloat(placement.x), z = CGFloat(placement.z)
        let center: CGPoint
        if item.id == "books" {
            if let support = placements.first(where: { $0.id == placement.supportID }),
               let height = Furniture.find(support.id)?.topHeight {
                let world = bookWorldPlacement(placement, on: support)
                center = projection.project(CGFloat(world.x), CGFloat(world.z), CGFloat(height) + 0.11)
            } else {
                center = projection.wallPoint(.sideWall, x, z + 0.10)
            }
        } else if item.surface.isWall {
            center = projection.wallPoint(item.surface, x, z)
        } else {
            center = projection.project(x, z, isRug ? 0.02 : 0.31)
        }
        let width = item.surface.isWall ? item.width : (item.width + item.depth) * 0.92
        let height: Float = item.surface.isWall ? item.depth + item.width * 0.36 :
            (item.id == "books" ? 0.34 : (isRug ? 0.49 : 0.96))
        let hitWidth = max(44, projection.unit * CGFloat(width))
        let hitHeight = max(38, projection.unit * CGFloat(height))
        return Color.clear
            .frame(width: hitWidth, height: hitHeight)
            .contentShape(AnyHitShape(ellipse: isRug))
            .position(center)
            .onTapGesture { selected = item.id }
            .highPriorityGesture(
                DragGesture(minimumDistance: 5, coordinateSpace: .named("room-floor"))
                    .onChanged { value in
                        if dragStart?.id != placement.id {
                            dragStart = placements.first { $0.id == placement.id }
                            selected = placement.id
                        }
                        guard projection.unit > 0, let start = dragStart,
                              let index = placements.firstIndex(where: { $0.id == start.id }) else { return }
                        let delta = start.dragDelta(
                            horizontal: Float(value.translation.width / projection.unit),
                            vertical: Float(value.translation.height / projection.unit),
                            in: placements
                        )
                        var candidate = start
                        candidate.x += delta.x
                        candidate.z += delta.z
                        guard Furniture.canPlace(candidate, in: placements) else { return }
                        placements[index] = candidate
                    }
                    .onEnded { _ in dragStart = nil }
            )
            .accessibilityLabel("移动\(item.title)")
            .accessibilityAddTraits(selected == item.id ? [.isButton, .isSelected] : .isButton)
            .accessibilityAction { selected = item.id }
    }

    private func drawRoom(_ context: GraphicsContext, _ p: RoomProjection) {
        let a = p.project(-1.53, -1.53), b = p.project(1.53, -1.53)
        let c = p.project(1.53, 1.53), d = p.project(-1.53, 1.53)
        let topA = p.project(-1.53, -1.53, 1.83), topB = p.project(1.53, -1.53, 1.83)
        let topD = p.project(-1.53, 1.53, 1.83)

        var shade = context
        shade.addFilter(.blur(radius: 11))
        fill(shade, [a, b, c, d].map { CGPoint(x: $0.x + 2, y: $0.y + 12) }, rgb(0x987658).opacity(0.35))
        fillGradient(context, [a, d, topD, topA], rgb(0xfff3e2), rgb(0xdcc2a5), from: topD, to: a)
        fillGradient(context, [a, b, topB, topA], rgb(0xf3ddc1), rgb(0xfff1dd), from: a, to: topB)
        let outerA = p.project(-1.64, -1.64, 1.83)
        let outerB = p.project(1.53, -1.64, 1.83)
        let outerD = p.project(-1.64, 1.53, 1.83)
        fill(context, [topD, topA, outerA, outerD], rgb(0xf9e6d0))
        fill(context, [topA, topB, outerB, outerA], rgb(0xfff1de))
        fill(context, [topD, outerD, p.project(-1.64,1.53), d], rgb(0xd8ba99))
        fill(context, [topB, outerB, p.project(1.53,-1.64), b], rgb(0xe7ccb0))
        stroke(context, [outerD, outerA, outerB], rgb(0xfff8eb), lineWidth: 1)
        let bottomC = p.project(1.53, 1.53, -0.20)
        fillGradient(context, [b, c, bottomC, p.project(1.53, -1.53, -0.20)],
                     rgb(0xe3be92), rgb(0xaf8058), from: b, to: bottomC)
        fillGradient(context, [d, c, bottomC, p.project(-1.53, 1.53, -0.20)],
                     rgb(0xefcfaa), rgb(0xc89d76), from: d, to: bottomC)
        fill(context, [a, b, c, d], rgb(0xe5cba8))

        let woodTones: [UInt32] = [0xf0d7b4, 0xeed2ad, 0xefdbbf, 0xe7caa4]
        for plank in 0..<12 {
            let x = -1.53 + CGFloat(plank) * (3.06 / 12)
            let next = x + 3.06 / 12
            let points = [p.project(x,-1.53), p.project(next,-1.53), p.project(next,1.53), p.project(x,1.53)]
            fillGradient(context, points, rgb(0xcdac89), rgb(woodTones[plank % woodTones.count]),
                         from: p.project(x,-1.75), to: p.project(next,0.37))
            stroke(context, [p.project(x,-1.53), p.project(x,1.53)], rgb(0xaa805a).opacity(0.24), lineWidth: 0.75)
            let joint = CGFloat(plank % 4) * 0.36 - 0.92
            for seam in [joint, joint + 1.31] {
                stroke(context, [p.project(x,seam), p.project(next,seam)], rgb(0xa37c56).opacity(0.26), lineWidth: 0.59)
            }
            for grain in 1...4 {
                let offset = CGFloat(grain) * 0.044
                let start = CGFloat((grain * 37 + plank * 17) % 150) / 100 - 1.5
                let end = min(1.50, start + 0.50 + CGFloat((grain + plank) % 6) * 0.23)
                stroke(context, [p.project(x+offset,start), p.project(x+offset-0.012,(start+end)/2),
                                 p.project(x+offset,end)], rgb(0xa4774e).opacity(0.10), lineWidth: 0.52)
            }
        }
        drawSunlight(context, projection: p, floor: [a, b, c, d], wall: [a, d, topD, topA])
        if editing {
            for step in -3...3 {
                let v = CGFloat(step) * 0.42
                stroke(context, [p.project(v,-1.51), p.project(v,1.51)], .white.opacity(0.37), lineWidth: 0.65)
                stroke(context, [p.project(-1.51,v), p.project(1.51,v)], .white.opacity(0.37), lineWidth: 0.65)
            }
        }

        let skirting = rgb(0xe9d0b3)
        fill(context, [a, d, p.project(-1.53,1.53,0.09), p.project(-1.53,-1.53,0.09)], skirting)
        fill(context, [a, b, p.project(1.53,-1.53,0.09), p.project(-1.53,-1.53,0.09)], skirting)
        drawWindow(context, projection: p)
        stroke(context, [d, a, b], rgb(0xa88260).opacity(0.33), lineWidth: 1.65)
    }
}

private struct AnyHitShape: Shape {
    let ellipse: Bool

    func path(in rect: CGRect) -> Path {
        ellipse ? Path(ellipseIn: rect) : Path(rect)
    }
}

private func drawWindow(_ context: GraphicsContext, projection p: RoomProjection) {
    let left: CGFloat = -1.13, right: CGFloat = 0.65
    let top: CGFloat = 1.52, bottom: CGFloat = 0.54, wall: CGFloat = -1.50
    let topLeft = p.project(left, wall, top)
    let topRight = p.project(right, wall, top)
    let bottomLeft = p.project(left, wall, bottom)
    let bottomRight = p.project(right, wall, bottom)
    let frame = [bottomLeft, bottomRight, topRight, topLeft]
    fill(context, frame.map { CGPoint(x: $0.x + 2, y: $0.y + 3) }, rgb(0xa28366).opacity(0.25))
    fill(context, frame, rgb(0xcbd0a4))

    var outside = context
    outside.clip(to: polygon(frame))
    let image = outside.resolve(Image("otter8_garden"))
    outside.transform = CGAffineTransform(
        a: (topRight.x - topLeft.x) / 400, b: (topRight.y - topLeft.y) / 400,
        c: (bottomLeft.x - topLeft.x) / 220, d: (bottomLeft.y - topLeft.y) / 220,
        tx: topLeft.x, ty: topLeft.y
    )
    outside.draw(image, in: CGRect(x: 0, y: 0, width: 400, height: 220))

    let wood = rgb(0xd3ad84)
    let sunlit = rgb(0xfce4c5)
    let molding = max(2, p.unit * 0.067)
    stroke(context, frame + [frame[0]], wood, lineWidth: molding * 1.4)
    stroke(context, frame + [frame[0]], sunlit, lineWidth: molding * 0.78)
    for section in 1...3 {
        let x = left + (right - left) * CGFloat(section) / 4
        stroke(context, [p.project(x,wall,top), p.project(x,wall,bottom)], wood, lineWidth: molding)
        stroke(context, [p.project(x,wall,top), p.project(x,wall,bottom)], sunlit, lineWidth: molding * 0.53)
    }
    let rail = [p.project(left,wall,1.00), p.project(right,wall,1.00)]
    stroke(context, rail, wood, lineWidth: molding)
    stroke(context, rail, sunlit, lineWidth: molding * 0.53)

    let ledge = [p.project(left-0.075,wall,bottom), p.project(right+0.075,wall,bottom),
                 p.project(right+0.075,-1.37,bottom), p.project(left-0.075,-1.37,bottom)]
    fillGradient(context, ledge, rgb(0xfff3d5), rgb(0xe5bc92), from: ledge[0], to: ledge[2])
    fill(context, [ledge[2], ledge[3], p.project(left-0.075,-1.37,bottom-0.055),
                   p.project(right+0.075,-1.37,bottom-0.055)], rgb(0xc79c74))
    stroke(context, [ledge[2], ledge[3]], rgb(0xfff0d1), lineWidth: 1)
}

private func drawSunlight(_ context: GraphicsContext, projection p: RoomProjection, floor: [CGPoint], wall: [CGPoint]) {
    var goldenFloor = context
    goldenFloor.clip(to: polygon(floor))
    goldenFloor.addFilter(.blur(radius: max(1, p.unit * 0.024)))
    for column in 0..<4 {
        let x = -1.10 + CGFloat(column) * 0.44
        for row in 0..<2 {
            let z = -0.65 + CGFloat(row) * 0.78
            let pane = [p.project(x-0.18,z), p.project(x+0.19,z),
                        p.project(x-0.05,z+0.73), p.project(x-0.43,z+0.73)]
            fillGradient(goldenFloor, pane, rgb(0xfff6d5).opacity(0.64), rgb(0xfff1ca).opacity(0.29),
                         from: pane[0], to: pane[2])
        }
    }
    var goldenWall = context
    goldenWall.clip(to: polygon(wall))
    goldenWall.addFilter(.blur(radius: max(1.5, p.unit * 0.052)))
    for patch in 0..<4 {
        let z = -1.28 + CGFloat(patch) * 0.43
        let y = 1.35 - CGFloat(patch % 2) * 0.13
        let light = [p.project(-1.53,z,y), p.project(-1.53,z+0.24,y-0.11),
                     p.project(-1.53,z+0.33,y-0.38), p.project(-1.53,z+0.08,y-0.24)]
        fillGradient(goldenWall, light, rgb(0xfff7df).opacity(0.69), rgb(0xfff2d4).opacity(0.12),
                     from: light[0], to: light[2])
    }
}

struct FurnitureIllustration: View {
    let item: Furniture
    var finish: FurnitureFinish? = nil

    var body: some View {
        Canvas { context, size in
            let placement = FurniturePlacement(id: item.id, x: 0, z: 0, turns: 0, finish: finish)
            if item.surface == .tabletop {
                let unit = min(size.width * 1.30, size.height * 2)
                let p = RoomProjection(center: CGPoint(x: size.width / 2, y: size.height * 0.72), unit: unit)
                drawBooks(context, projection: p, placement: placement, height: 0, selected: false)
                return
            }
            if item.surface.isWall {
                let unit = min(size.width / CGFloat(item.width + 0.22),
                               size.height / CGFloat(item.depth + item.width * roomPitch + 0.14))
                let p = RoomProjection(center: CGPoint(x: size.width / 2, y: size.height / 2), unit: unit)
                drawWallDecoration(context, projection: p, item: item, placement: placement,
                                   selected: false, inset: 0)
                return
            }
            let extent = max(item.width + item.depth, 1.0)
            let p = RoomProjection(center: CGPoint(x: size.width / 2,
                                                  y: size.height * (item.surface == .rug ? 0.52 : 0.77)),
                                   unit: min(size.width / CGFloat(extent + 0.28), size.height * 0.53))
            drawItem(context, projection: p, placement: placement, selected: false)
        }
        .accessibilityHidden(true)
    }
}

private struct FurniturePainter {
    let context: GraphicsContext
    let p: RoomProjection
    let placement: FurniturePlacement

    func point(_ x: CGFloat, _ z: CGFloat, _ y: CGFloat) -> CGPoint {
        let pair: (CGFloat, CGFloat)
        switch placement.turns % 4 {
        case 1: pair = (-z, x)
        case 2: pair = (-x, -z)
        case 3: pair = (z, -x)
        default: pair = (x, z)
        }
        return p.project(CGFloat(placement.x) + pair.0, CGFloat(placement.z) + pair.1, y)
    }

    func block(x: CGFloat = 0, z: CGFloat = 0, y: CGFloat, w: CGFloat, d: CGFloat,
               h: CGFloat, top: Color, side: Color) {
        let corners = [(x-w/2,z-d/2), (x+w/2,z-d/2), (x+w/2,z+d/2), (x-w/2,z+d/2)]
        let base = corners.map { point($0.0, $0.1, y) }
        let upper = corners.map { point($0.0, $0.1, y+h) }
        let clockwise = placement.turns % 4
        let front = (2 - clockwise + 4) % 4
        let right = (1 - clockwise + 4) % 4
        for index in [right, front] {
            let next = (index + 1) % 4
            let profile = [base[index], base[next], upper[next], upper[index]]
            let reflected = index == front ? side : top
            let radius = min(p.unit * 0.025, p.unit * min(w, d, h) * 0.25)
            fillGradient(context, profile, reflected, side, from: upper[index], to: base[next],
                         cornerRadius: radius)
        }
        fillGradient(context, upper, top, top.opacity(0.82), from: upper[0], to: upper[2],
                     cornerRadius: p.unit * 0.014)
        stroke(context, [upper[3], upper[0], upper[1]], .white.opacity(0.37), lineWidth: 0.75)
    }

    func ring(radius: CGFloat, height: CGFloat = 0.004) -> [CGPoint] {
        (0...52).map { index in
            let angle = CGFloat(index) / 52 * .pi * 2
            return point(radius * cos(angle), radius * sin(angle), height)
        }
    }
}

private func drawItem(_ context: GraphicsContext, projection: RoomProjection,
                      placement: FurniturePlacement, selected: Bool) {
    guard let item = Furniture.find(placement.id) else { return }
    if item.id == "books" {
        var world = placement
        world.x = -1.37
        world.z = placement.x
        world.turns = 1
        let height = CGFloat(placement.z)
        let shelf = FurniturePainter(context: context, p: projection, placement: world)
        shelf.block(y: height - 0.057, w: 0.49, d: 0.26, h: 0.057,
                    top: rgb(0xf0c99d), side: rgb(0xba8c66))
        drawBooks(context, projection: projection, placement: world, height: height, selected: selected)
        return
    }
    if item.surface.isWall {
        drawWallDecoration(context, projection: projection, item: item, placement: placement, selected: selected)
        return
    }
    let p = FurniturePainter(context: context, p: projection, placement: placement)
    let oak = rgb(0xe8be86), wood = rgb(0xb18355)
    let cream = rgb(0xfff4df), fabric = rgb(0xd5bca0)
    let green = rgb(0x849e75)
    let outline = rgb(0x397f86)
    let finish = placement.finish ?? item.defaultFinish
    let upholstery = finish?.highlight ?? cream
    let upholsteryShadow = finish?.shade ?? fabric

    if item.id == "rug" {
        drawContactShadow(context, at: p.point(0, 0.025, 0), width: projection.unit * 1.68,
                          height: projection.unit * 0.75, opacity: 0.21)
        let image = context.resolve(Image("otter8_room_rug"))
        let center = p.point(0, 0, 0.009)
        let width = projection.unit * CGFloat(item.width) * 1.414
        let height = width * image.size.height / max(1, image.size.width)
        context.draw(image, in: CGRect(x: center.x - width / 2, y: center.y - height / 2,
                                       width: width, height: height))
        if selected { stroke(context, p.ring(radius: 0.575, height: 0.014), outline, lineWidth: 2) }
    } else {
        let extent = max(CGFloat(item.width), CGFloat(item.depth))
        let shadowCenter = p.point(0.07, 0.09, 0)
        let uv = projection.unit
        drawContactShadow(context, at: shadowCenter, width: extent * uv * 1.46,
                          height: uv * 0.27, opacity: 0.24)
        switch item.id {
        case "desk":
            for x: CGFloat in [-0.48, 0.48] {
                for z: CGFloat in [-0.20, 0.20] {
                    p.block(x: x, z: z, y: 0, w: 0.08, d: 0.08, h: 0.62, top: oak, side: wood)
                }
            }
            p.block(x: 0.39, y: 0.10, w: 0.30, d: 0.53, h: 0.52, top: rgb(0xe8c29a), side: rgb(0xbe946c))
            for drawer in 0..<3 {
                let y = 0.14 + CGFloat(drawer) * 0.151
                p.block(x: 0.39, z: 0.266, y: y, w: 0.26, d: 0.023, h: 0.13,
                        top: rgb(0xe9c6a2), side: rgb(0xd4ab84))
                stroke(context, [p.point(0.36,0.281,y+0.077), p.point(0.42,0.281,y+0.077)],
                       rgb(0xaa7e57), lineWidth: 1.15)
            }
            p.block(y: 0.62, w: 1.15, d: 0.58, h: 0.09, top: upholstery, side: upholsteryShadow)
            p.block(x: -0.19, z: 0.035, y: 0.71, w: 0.35, d: 0.24, h: 0.023,
                    top: rgb(0xded3c1), side: rgb(0x9b9084))
            fillGradient(context, [p.point(-0.36,-0.075,0.73), p.point(-0.02,-0.075,0.73),
                                   p.point(-0.02,-0.13,0.96), p.point(-0.36,-0.13,0.96)],
                         rgb(0x77655a), rgb(0x3b3530), from: p.point(-0.36,-0.13,0.96),
                         to: p.point(-0.02,-0.075,0.73))
        case "chair":
            for x: CGFloat in [-0.15,0.15] {
                for z: CGFloat in [-0.15,0.15] {
                    p.block(x: x, z: z, y: 0, w: 0.055, d: 0.055, h: 0.34, top: oak, side: wood)
                }
            }
            p.block(y: 0.34, w: 0.42, d: 0.45, h: 0.10, top: upholstery, side: upholsteryShadow)
            p.block(z: -0.18, y: 0.44, w: 0.41, d: 0.08, h: 0.32, top: upholstery, side: upholsteryShadow)
        case "plant":
            let foot = p.point(0, 0, 0)
            let image = context.resolve(Image("otter8_room_plant"))
            let height = uv * 0.75
            let width = height * image.size.width / max(1, image.size.height)
            var plant = context
            let direction: CGFloat = placement.turns == 1 || placement.turns == 2 ? -1 : 1
            plant.transform = CGAffineTransform(a: direction, b: 0, c: 0, d: 1, tx: foot.x, ty: foot.y)
            plant.draw(image, in: CGRect(x: -width * 0.51, y: -height * 0.99, width: width, height: height))
        case "lamp":
            p.block(y: 0, w: 0.31, d: 0.31, h: 0.045, top: oak, side: wood)
            p.block(y: 0.045, w: 0.035, d: 0.035, h: 0.63, top: oak, side: wood)
            let shade = [p.point(-0.21,0,0.62), p.point(0.21,0,0.62),
                         p.point(0.105,0,0.85), p.point(-0.105,0,0.85)]
            fillGradient(context, shade, upholstery, upholsteryShadow, from: shade[3], to: shade[1],
                         cornerRadius: uv * 0.041)
            stroke(context, [p.point(-0.18,0,0.62),p.point(0.17,0,0.62)], upholsteryShadow, lineWidth: 1.1)
        case "sofa":
            for x: CGFloat in [-0.25, 0.25] {
                for z: CGFloat in [-0.38, 0.38] {
                    p.block(x: x, z: z, y: 0, w: 0.065, d: 0.065, h: 0.068, top: oak, side: wood)
                }
            }
            p.block(y: 0.063, w: 0.69, d: 1.00, h: 0.205, top: upholstery, side: upholsteryShadow)
            p.block(x: 0.28, y: 0.27, w: 0.17, d: 1.00, h: 0.29, top: upholstery, side: upholsteryShadow)
            for z: CGFloat in [-0.43, 0.43] {
                p.block(z: z, y: 0.26, w: 0.67, d: 0.15, h: 0.17, top: upholstery, side: upholsteryShadow)
            }
            for z: CGFloat in [-0.20, 0.20] {
                p.block(x: -0.07, z: z, y: 0.25, w: 0.46, d: 0.38, h: 0.075,
                        top: upholstery, side: upholsteryShadow)
            }
            p.block(x: 0.15, z: -0.15, y: 0.325, w: 0.17, d: 0.22, h: 0.14,
                    top: rgb(0xf4dfc2), side: rgb(0xd1ae90))
        case "sill":
            p.block(y: 0, w: 0.70, d: 0.36, h: 0.36, top: oak, side: wood)
            p.block(y: 0.36, w: 0.70, d: 0.38, h: 0.05, top: cream, side: fabric)
        case "easel":
            for x: CGFloat in [-0.16,0.16] {
                p.block(x: x, z: 0.02, y: 0, w: 0.04, d: 0.04, h: 0.70, top: oak, side: wood)
            }
            let board = [p.point(-0.24,0.02,0.33),p.point(0.24,0.02,0.33),
                         p.point(0.24,0.02,0.81),p.point(-0.24,0.02,0.81)]
            fill(context, board, rgb(0xbccdc8))
            stroke(context, board + [board[0]], wood, lineWidth: 1.7)
            fill(context, [p.point(-0.20,0.02,0.40),p.point(-0.06,0.02,0.60),
                           p.point(0.05,0.02,0.46),p.point(0.13,0.02,0.56),p.point(0.20,0.02,0.40)], green)
        default: break
        }
        if selected {
            let w = CGFloat(item.width) / 2, d = CGFloat(item.depth) / 2
            let ground = [p.point(-w,-d,0.004),p.point(w,-d,0.004),p.point(w,d,0.004),p.point(-w,d,0.004)]
            stroke(context, ground + [ground[0]], outline, lineWidth: 2)
        }
    }

    if selected {
        let label = Text(item.title)
            .font(.caption2.weight(.semibold))
            .foregroundColor(Color(red: 0.13, green: 0.34, blue: 0.36))
        let anchor = p.point(0,0,item.surface == .rug ? 0.13 : 1.03)
        let plate = CGRect(x: anchor.x - 37, y: anchor.y - 10, width: 74, height: 20)
        context.fill(Path(roundedRect: plate, cornerRadius: 9), with: .color(.white.opacity(0.94)))
        context.draw(label, at: anchor)
    }
}

private func drawBooks(_ context: GraphicsContext, projection: RoomProjection, placement: FurniturePlacement,
                       height: CGFloat, selected: Bool) {
    let p = FurniturePainter(context: context, p: projection, placement: placement)
    drawContactShadow(context, at: p.point(0.023, 0.024, height), width: projection.unit * 0.45,
                      height: projection.unit * 0.14, opacity: 0.20)
    let shades: [(UInt32, UInt32)] = [(0xd3a48f, 0x9f6d59), (0xbac0a2, 0x818d71), (0xf3d4a3, 0xbc945f)]
    for index in shades.indices {
        let x = CGFloat(index - 1) * 0.089
        let bookHeight: CGFloat = [0.195, 0.235, 0.171][index]
        let (cover, edge) = shades[index]
        p.block(x: x, y: height, w: 0.082, d: 0.15, h: bookHeight, top: rgb(cover), side: rgb(edge))
        p.block(x: x, y: height + bookHeight - 0.014, w: 0.060, d: 0.117, h: 0.015,
                top: rgb(0xfaf0db), side: rgb(0xe4cba9))
        stroke(context, [p.point(x-0.032,0.077,height+bookHeight*0.69),
                         p.point(x+0.032,0.077,height+bookHeight*0.69)],
               rgb(0xffedd2).opacity(0.71), lineWidth: 0.65)
    }
    if selected {
        let corners = [p.point(-0.167,-0.089,height), p.point(0.167,-0.089,height),
                       p.point(0.167,0.089,height), p.point(-0.167,0.089,height)]
        stroke(context, corners + [corners[0]], rgb(0x397f86), lineWidth: 1.65)
    }
}

private func drawWallDecoration(_ context: GraphicsContext, projection: RoomProjection, item: Furniture,
                                placement: FurniturePlacement, selected: Bool, inset: CGFloat = -1.51) {
    let width = CGFloat(item.width), height = CGFloat(item.depth)
    func point(_ x: CGFloat, _ y: CGFloat) -> CGPoint {
        projection.wallPoint(item.surface, CGFloat(placement.x) + x, CGFloat(placement.z) + y, inset: inset)
    }
    func rectangle(_ left: CGFloat, _ right: CGFloat, _ bottom: CGFloat, _ top: CGFloat) -> [CGPoint] {
        [point(left, bottom), point(right, bottom), point(right, top), point(left, top)]
    }

    let bounds = rectangle(-width / 2, width / 2, -height / 2, height / 2)
    let shadow = bounds.map { CGPoint(x: $0.x + 1.5, y: $0.y + 2.5) }
    if item.id == "curtain" {
        let top = height / 2, bottom = -height / 2
        let panelWidth = width * 0.218
        for direction: CGFloat in [-1, 1] {
            let edge = direction * width / 2
            func foldPoint(_ fraction: CGFloat, _ y: CGFloat, spread: CGFloat, drift: CGFloat) -> CGPoint {
                point(edge - direction * (drift + fraction * panelWidth * spread), y)
            }
            let strips = 7
            for fold in 0..<strips {
                let a = CGFloat(fold) / CGFloat(strips), b = CGFloat(fold + 1) / CGFloat(strips)
                let topOuter = foldPoint(a, top-0.023, spread: 1, drift: 0.015)
                let topInner = foldPoint(b, top-0.021, spread: 1, drift: 0.015)
                let midOuter = foldPoint(a, -0.10, spread: 0.47, drift: 0.025)
                let midInner = foldPoint(b, -0.10, spread: 0.47, drift: 0.025)
                let tipOuter = foldPoint(a, bottom+0.036+0.05*a, spread: 0.72, drift: 0.031)
                let tipInner = foldPoint(b, bottom+0.036+0.05*b, spread: 0.72, drift: 0.031)
                var cloth = Path()
                cloth.move(to: topOuter)
                cloth.addLine(to: topInner)
                let control = foldPoint(b, 0.16, spread: 0.88, drift: 0.037)
                cloth.addQuadCurve(to: midInner, control: control)
                cloth.addQuadCurve(to: tipInner, control: foldPoint(b, -0.28, spread: 0.53, drift: 0.045))
                cloth.addLine(to: tipOuter)
                cloth.addQuadCurve(to: midOuter, control: foldPoint(a, -0.28, spread: 0.53, drift: 0.045))
                cloth.addQuadCurve(to: topOuter, control: foldPoint(a, 0.16, spread: 0.88, drift: 0.037))
                cloth.closeSubpath()
                let warmShadow = rgb(fold.isMultiple(of: 2) ? 0xe1c5a4 : 0xcbb197)
                context.fill(cloth, with: .linearGradient(Gradient(colors: [rgb(0xfff4e0), warmShadow]),
                                                          startPoint: topOuter, endPoint: tipInner))
                stroke(context, [midOuter, tipOuter], rgb(0x9e8062).opacity(0.24), lineWidth: 0.54)
            }
            let gather = [foldPoint(0,-0.10,spread: 0.48,drift: 0.02),
                          foldPoint(1,-0.10,spread: 0.48,drift: 0.02)]
            stroke(context, gather, rgb(0xa48260), lineWidth: 1.5)
        }
        let rod = [point(-width / 2, top), point(width / 2, top)]
        stroke(context, rod, rgb(0xa9815f), lineWidth: 2.8)
        stroke(context, rod.map { CGPoint(x: $0.x, y: $0.y-0.65) }, rgb(0xefcc9f), lineWidth: 0.8)
    } else if item.id == "wallClock" {
        func disc(_ radius: CGFloat) -> [CGPoint] {
            (0...48).map {
                let angle = CGFloat($0) / 48 * .pi * 2
                return point(cos(angle) * radius, sin(angle) * radius)
            }
        }
        let rim = disc(width / 2)
        fill(context, rim.map { CGPoint(x: $0.x + 1.25, y: $0.y + 2) }, rgb(0x947559).opacity(0.26))
        fillGradient(context, rim, rgb(0xe5bd91), rgb(0xa67552),
                     from: point(-0.13,0.13), to: point(0.14,-0.13))
        fillGradient(context, disc(width / 2 - 0.033), rgb(0xfff7e3), rgb(0xe8d2b5),
                     from: point(-0.11,0.11), to: point(0.13,-0.12))
        for mark in 0..<12 {
            let angle = CGFloat(mark) * .pi / 6
            let inner: CGFloat = mark.isMultiple(of: 3) ? 0.133 : 0.151
            stroke(context, [point(sin(angle)*inner,cos(angle)*inner), point(sin(angle)*0.169,cos(angle)*0.169)],
                   rgb(0x94765c), lineWidth: 0.68)
        }
        stroke(context, [point(-0.070,0.046),point(0,0),point(0.112,0.064)], rgb(0x77563e), lineWidth: 1.45)
    } else {
        let w = width / 2 - 0.043, h = height / 2 - 0.043
        fill(context, shadow, rgb(0x967969).opacity(0.27))
        fill(context, bounds, rgb(0xb88a63))
        fill(context, rectangle(-w, w, -h, h), rgb(0xfaf0dc))
        fill(context, rectangle(-w + 0.028, w - 0.028, -h + 0.028, h - 0.028), rgb(0xc5dfe3))
        let sun = point(0.11, 0.095)
        let radius = projection.unit * 0.047
        context.fill(Path(ellipseIn: CGRect(x: sun.x - radius, y: sun.y - radius,
                                            width: radius * 2, height: radius * 2)),
                     with: .color(rgb(0xf5d396)))
        let edge = w - 0.028, floor = -h + 0.028
        fill(context, [point(-edge,floor), point(-edge,-0.01), point(-0.091,0.069),
                       point(0.036,-0.031), point(0.152,0.017), point(edge,-0.047),
                       point(edge,floor)], rgb(0x839c84))
        stroke(context, bounds + [bounds[0]], rgb(0xeed0a3), lineWidth: 1)
    }
    if selected {
        stroke(context, bounds + [bounds[0]], rgb(0x397f86), lineWidth: 2)
    }
}

private func rgb(_ hex: UInt32) -> Color {
    Color(red: Double((hex >> 16) & 255) / 255,
          green: Double((hex >> 8) & 255) / 255, blue: Double(hex & 255) / 255)
}

private func fill(_ context: GraphicsContext, _ points: [CGPoint], _ color: Color) {
    context.fill(polygon(points), with: .color(color))
}

private func polygon(_ points: [CGPoint], cornerRadius: CGFloat = 0) -> Path {
    var path = Path()
    if cornerRadius <= 0 || points.count < 3 {
        path.addLines(points)
    } else {
        func near(_ vertex: CGPoint, _ neighbour: CGPoint) -> CGPoint {
            let dx = neighbour.x - vertex.x, dy = neighbour.y - vertex.y
            let length = hypot(dx, dy)
            let ratio = min(0.35, cornerRadius / max(0.001, length))
            return CGPoint(x: vertex.x + dx * ratio, y: vertex.y + dy * ratio)
        }
        for index in points.indices {
            let current = points[index]
            let before = near(current, points[(index + points.count - 1) % points.count])
            let after = near(current, points[(index + 1) % points.count])
            if index == 0 { path.move(to: before) }
            else { path.addLine(to: before) }
            path.addQuadCurve(to: after, control: current)
        }
    }
    path.closeSubpath()
    return path
}

private func fillGradient(_ context: GraphicsContext, _ points: [CGPoint], _ light: Color, _ shadow: Color,
                          from start: CGPoint, to end: CGPoint, cornerRadius: CGFloat = 0) {
    context.fill(polygon(points, cornerRadius: cornerRadius),
                 with: .linearGradient(Gradient(colors: [light, shadow]), startPoint: start, endPoint: end))
}

private func drawContactShadow(_ context: GraphicsContext, at center: CGPoint, width: CGFloat,
                               height: CGFloat, opacity: Double) {
    guard width > 0, height > 0 else { return }
    var shadow = context
    shadow.addFilter(.blur(radius: max(0.7, height * 0.18)))
    let rect = CGRect(x: center.x - width / 2, y: center.y - height / 2,
                      width: width, height: height)
    shadow.fill(Path(ellipseIn: rect), with: .color(rgb(0x71543e).opacity(opacity)))
}

private func stroke(_ context: GraphicsContext, _ points: [CGPoint], _ color: Color, lineWidth: CGFloat) {
    var path = Path()
    path.addLines(points)
    context.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: lineWidth, lineCap: .round, lineJoin: .round))
}
