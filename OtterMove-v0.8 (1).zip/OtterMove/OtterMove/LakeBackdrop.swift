import SwiftUI

private func lakeFrame(_ size: CGSize) -> CGRect {
    let scale = max(size.width / 863, size.height / 1823)
    let width = 863 * scale, height = 1823 * scale
    return CGRect(x: (size.width - width) / 2, y: (size.height - height) / 2, width: width, height: height)
}

struct LakeBreathingPrompt: View {
    let cue: BreathCue
    let ink: Color

    var body: some View {
        GeometryReader { geometry in
            let art = lakeFrame(geometry.size)
            VStack(spacing: 1) {
                Text(cue.phase.prompt)
                    .font(.system(size: 38, weight: .semibold, design: .rounded))
                Text("\(cue.seconds) 秒")
                    .font(.system(.title3, design: .rounded).weight(.semibold))
                    .monospacedDigit()
            }
            .foregroundStyle(ink)
            .shadow(color: ink == .white ? Color.black.opacity(0.35) : Color.white.opacity(0.65), radius: 7)
            .position(x: art.midX, y: max(150, art.minY + art.height * 0.281))
            .accessibilityElement(children: .combine)
        }
    }
}

struct LakeBackdrop: View {
    let light: LakeLight

    var body: some View {
        ZStack {
            Palette.midnight
            LakeArtwork(light: light)
                .id(light)
                .transition(.opacity)
        }
        .allowsHitTesting(false)
    }
}

private struct LakeArtwork: View {
    let light: LakeLight
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase

    private var artwork: String {
        switch light {
        case .day: return "otter5_lake_day"
        case .dusk: return "otter5_lake_dusk"
        case .night: return "otter4_lake"
        }
    }

    var body: some View {
        GeometryReader { geometry in
            let art = lakeFrame(geometry.size)
            ZStack {
                Image(artwork)
                    .resizable()
                    .interpolation(.high)
                    .frame(width: art.width, height: art.height)
                    .position(x: art.midX, y: art.midY)
                if light == .night {
                    starField(art)
                }
                if !reduceMotion && scenePhase == .active {
                    TimelineView(.animation(minimumInterval: 1.0 / 24)) { timeline in
                        let time = timeline.date.timeIntervalSinceReferenceDate
                        WaterRipples(artwork: artwork, frame: art, light: light, time: time)
                    }
                }
                tint
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .clipped()
        }
    }

    private var tint: some View {
        LinearGradient(stops: [
            .init(color: Color(red: 0.06, green: 0.16, blue: 0.29).opacity(light == .day ? 0.60 : 0.25), location: 0),
            .init(color: .clear, location: 0.21),
            .init(color: .clear, location: 0.63),
            .init(color: light == .day ? Color(red: 0.84, green: 0.92, blue: 0.98).opacity(0.73)
                                       : Color.black.opacity(0.39), location: 1)
        ], startPoint: .top, endPoint: .bottom)
    }

    private func starField(_ frame: CGRect) -> some View {
        Canvas { context, _ in
            let stars: [(CGFloat, CGFloat, CGFloat)] = [
                (0.18,0.086,0.85), (0.28,0.065,0.72), (0.45,0.107,0.90),
                (0.60,0.075,0.70), (0.82,0.083,0.96), (0.93,0.126,0.76), (0.12,0.16,0.65)
            ]
            for (x, y, radius) in stars {
                let point = CGPoint(x: frame.minX + x * frame.width, y: frame.minY + y * frame.height)
                let dot = CGRect(x: point.x - radius, y: point.y - radius, width: radius * 2, height: radius * 2)
                context.fill(Path(ellipseIn: dot), with: .color(.white.opacity(0.62)))
            }
        }
    }
}

private struct WaterRipples: View {
    let artwork: String
    let frame: CGRect
    let light: LakeLight
    let time: TimeInterval

    var body: some View {
        Canvas { context, size in
            let image = context.resolve(Image(artwork))
            let horizon = frame.minY + frame.height * 0.441
            let otterBottom = frame.minY + frame.height * 0.546
            let protectedLeft = frame.minX + frame.width * 0.326
            let protectedRight = frame.minX + frame.width * 0.679
            let lastY = min(size.height, frame.maxY)
            guard horizon < lastY else { return }

            // Re-sample only horizontal water strips. Retain the original strip under
            // the otter silhouette, then move its reflection just below the feet.
            let height = max(7, (lastY - horizon) / 38)
            var y = max(0, horizon)
            while y < lastY {
                let end = min(lastY, y + height)
                let depth = (y - horizon) / frame.height
                let amplitude = min(1, depth * 15) * (1.35 + depth * 2.6)
                let shift = sin(time * 0.92 + Double(depth) * 134) * Double(amplitude)
                if y < otterBottom {
                    let far = min(otterBottom, end)
                    drawStrip(context, image, y: y, end: far, left: 0,
                              right: min(size.width, protectedLeft), shift: shift)
                    drawStrip(context, image, y: y, end: far, left: max(0, protectedRight),
                              right: size.width, shift: shift)
                    if far < end {
                        drawStrip(context, image, y: far, end: end, left: 0, right: size.width, shift: shift)
                    }
                } else {
                    drawStrip(context, image, y: y, end: end, left: 0, right: size.width, shift: shift)
                }
                y = end
            }

            for index in 0..<3 {
                let phase = ((time / 5.6) + Double(index) / 3).truncatingRemainder(dividingBy: 1)
                let width = frame.width * CGFloat(0.30 + phase * 0.42)
                let h = width * 0.112
                let oval = CGRect(x: frame.midX - width / 2, y: otterBottom + 5 - h * 0.24, width: width, height: h)
                var water = context
                water.clip(to: Path(CGRect(x: 0, y: otterBottom, width: size.width,
                                           height: max(0, lastY - otterBottom))))
                let sheen = light == .day ? Color.white : Color(red: 0.75, green: 0.88, blue: 1)
                water.stroke(Path(ellipseIn: oval), with: .color(sheen.opacity((1 - phase) * 0.16)), lineWidth: 0.65)
            }
        }
    }

    private func drawStrip(_ context: GraphicsContext, _ image: GraphicsContext.ResolvedImage,
                           y: CGFloat, end: CGFloat, left: CGFloat, right: CGFloat, shift: Double) {
        // Leave a few pixels of base imagery on the outside to absorb offset.
        let start = max(3, left)
        let finish = min(right, frame.maxX - 3)
        guard finish > start, end > y else { return }
        var strip = context
        strip.clip(to: Path(CGRect(x: start, y: y, width: finish - start, height: end - y)))
        strip.draw(image, in: frame.offsetBy(dx: CGFloat(shift), dy: 0))
    }
}
