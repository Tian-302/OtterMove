import Foundation

enum MoodType: String, CaseIterable, Identifiable, Codable {
    case happy, anxious, annoyed, sad, tired, relaxed

    var id: Self { self }
    var title: String {
        switch self {
        case .happy: "开心"
        case .anxious: "有点焦虑"
        case .annoyed: "有点烦"
        case .sad: "有点难过"
        case .tired: "有点累"
        case .relaxed: "很放松"
        }
    }
    var summaries: [String] {
        switch self {
        case .happy:
            ["今天的快乐，好像连空气都变甜了！", "今天是元气满满的一天呀！", "把这份好心情偷偷收藏起来吧！"]
        case .relaxed:
            ["慢慢来，也是一种很棒的生活节奏。", "今天的你，值得享受一点宁静。", "像云朵一样轻轻松松地度过今天吧。"]
        case .anxious:
            ["心里有点乱也没关系，先照顾好自己。", "今天或许不太轻松，Otter 陪着你。", "不必急着解决所有事情，慢慢来就好。"]
        case .tired:
            ["辛苦啦，今天也要记得好好休息。", "累的时候，允许自己停下来。", "今天已经很努力了，给自己一个拥抱吧。"]
        case .annoyed:
            ["今天有点烦，先给自己一点空间。", "可以先把手边的事放一放。", "歇一会儿，等自己准备好再继续。"]
        case .sad:
            ["有点难过的时候，水獭也会陪着你。", "今天可以慢一点，对自己温柔一点。", "先把自己照顾好，其他事情可以等等。"]
        }
    }

    func summary(excluding current: String = "") -> String {
        summaries.filter { $0 != current }.randomElement() ?? summaries[0]
    }
}
