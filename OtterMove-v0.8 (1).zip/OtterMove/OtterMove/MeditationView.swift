import SwiftUI
import AVFoundation
import Combine

struct MeditationView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("isSoundEnabled") private var soundOn = true
    @AppStorage("meditationTrack") private var track = MeditationTrack.water
    @AppStorage("meditationVolume") private var volume = 0.40
    @StateObject private var audio = MeditationAudio()
    @State private var light = LakeLight.at(Date())
    @State private var length = 300
    @State private var progress = SessionProgress(seconds: 300)
    @State private var sessionID = UUID()
    @State private var saved = false
    @State private var showsSettings = false
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 0) {
                    Text("小憩")
                        .font(WellnessPalette.font(.title2, weight: .semibold))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 10)
                    Spacer(minLength: max(197, geometry.size.height * 0.42))
                    controls
                }
                .padding(.horizontal, 27)
                .padding(.bottom, 19)
                .frame(maxWidth: 520)
                .frame(maxWidth: .infinity, minHeight: geometry.size.height)
            }
            .scrollIndicators(.hidden)
        }
        .background {
            LakeBackdrop(light: light)
                .ignoresSafeArea()
                .accessibilityHidden(true)
        }
        .overlay {
            if !progress.isFinished && (progress.running || progress.elapsed > 0) {
                LakeBreathingPrompt(cue: .at(progress.elapsed), ink: ink)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
            }
        }
        .foregroundStyle(ink)
        .buttonStyle(.plain)
        .onAppear { updateLight(at: Date()) }
        .onReceive(timer) { now in
            // Light changes describe the wall clock, independent of the practice clock.
            updateLight(at: now)
            guard progress.running else { return }
            progress.tick(at: now)
            if progress.isFinished {
                audio.stop()
                saveCompletion()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: AVAudioSession.interruptionNotification)) { note in
            if let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
               AVAudioSession.InterruptionType(rawValue: raw) == .began {
                pause()
            }
        }
        .onChange(of: soundOn) { _ in syncMusic() }
        .onChange(of: track) { _ in syncMusic() }
        .onChange(of: volume) { audio.setVolume($0) }
        .onChange(of: scenePhase) { phase in
            if phase == .active { updateLight(at: Date()) }
            else { pause() }
        }
        .onDisappear { pause() }
        .sheet(isPresented: $showsSettings) { settings }
    }

    private var ink: Color { light == .day ? Color(red: 0.075, green: 0.23, blue: 0.36) : .white }
    private var title: String {
        switch light {
        case .day: return "湖畔小憩"
        case .dusk: return "晚霞入湖"
        case .night: return "月下停泊"
        }
    }

    private var controls: some View {
        VStack(spacing: 11) {
            Text(title)
                .font(.system(size: 32, weight: .medium, design: .rounded))
                .accessibilityAddTraits(.isHeader)

            if progress.isFinished {
                Text(saved ? "已记录这次休息" : "休息完成，记录尚未保存")
                    .font(.subheadline)
                if !saved { Button("重新保存", action: saveCompletion).frame(minHeight: 44) }
            } else if progress.running || progress.elapsed > 0 {
                Text(SessionProgress.clockText(progress.remaining))
                    .font(.system(size: 40, weight: .light, design: .rounded))
                    .monospacedDigit()
                    .accessibilityLabel("练习剩余 \(progress.remaining) 秒")
                if !progress.running { Text("已暂停").font(.subheadline) }
            } else {
                Text(label(length) + " · " + (soundOn ? track.label : MeditationTrack.silent.label))
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(ink.opacity(0.82))
            }

            HStack(spacing: 34) {
                Button {
                    if track == .silent {
                        track = .water
                        soundOn = true
                    } else {
                        soundOn.toggle()
                    }
                } label: {
                    Image(systemName: soundOn && track != .silent ? "speaker.wave.2" : "speaker.slash")
                        .font(.system(size: 19, weight: .medium))
                        .frame(width: 46, height: 46)
                        .background(ink.opacity(0.12), in: Circle())
                }
                .accessibilityLabel(soundOn && track != .silent ? "关闭背景音乐" : "打开背景音乐")

                RoundControl(symbol: progress.running ? "pause.fill" : "play.fill",
                             label: progress.running ? "暂停冥想" : "开始或继续冥想", dark: true) {
                    if progress.running { pause() }
                    else {
                        if progress.isFinished { reset(seconds: length) }
                        progress.resume(at: Date())
                        syncMusic()
                    }
                }
                .shadow(color: .black.opacity(0.18), radius: 14, y: 4)

                Button { showsSettings = true } label: {
                    Image(systemName: "slider.horizontal.3")
                        .font(.system(size: 19, weight: .medium))
                        .frame(width: 46, height: 46)
                        .background(ink.opacity(0.12), in: Circle())
                }
                .accessibilityLabel("冥想设置")
            }
            .padding(.top, 7)
            if let problem = audio.problem, soundOn && track != .silent {
                Text(problem).font(.caption)
            }
        }
        .multilineTextAlignment(.center)
    }

    private var settings: some View {
        NavigationStack {
            Form {
                Section("背景音乐") {
                    ForEach(MeditationTrack.allCases) { item in
                        Button {
                            track = item
                            if item != .silent { soundOn = true }
                        } label: {
                            HStack {
                                Label(item.label, systemImage: item.icon)
                                Spacer()
                                if track == item { Image(systemName: "checkmark.circle.fill").foregroundStyle(Palette.blue) }
                            }
                        }
                        .foregroundStyle(.primary)
                        .accessibilityAddTraits(track == item ? .isSelected : [])
                    }
                    HStack(spacing: 12) {
                        Image(systemName: "speaker")
                        Slider(value: $volume, in: 0...1).accessibilityLabel("冥想音乐音量")
                        Text("\(Int((volume * 100).rounded()))%")
                            .monospacedDigit()
                    }
                    if let problem = audio.problem {
                        Text(problem).font(.footnote).foregroundStyle(.secondary)
                    }
                }
                Section("练习时长") {
                    ForEach([30, 60, 300], id: \.self) { seconds in
                        Button {
                            if length != seconds { reset(seconds: seconds) }
                        } label: {
                            HStack {
                                Text(label(seconds))
                                Spacer()
                                if length == seconds { Image(systemName: "checkmark").foregroundStyle(Palette.blue) }
                            }
                        }
                        .foregroundStyle(.primary)
                        .accessibilityAddTraits(length == seconds ? .isSelected : [])
                    }
                    if progress.running || progress.elapsed > 0 {
                        Button { reset(seconds: length) } label: {
                            Label("重新开始", systemImage: "arrow.counterclockwise")
                        }
                    }
                }
            }
            .navigationTitle("冥想设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { showsSettings = false } } }
        }
        .presentationDetents([.medium, .large])
    }

    private func updateLight(at date: Date) {
        let next = LakeLight.at(date)
        guard light != next else { return }
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 1.5)) { light = next }
    }

    private func label(_ seconds: Int) -> String {
        seconds < 60 ? "\(seconds) 秒" : "\(seconds / 60) 分钟"
    }

    private func reset(seconds: Int) {
        audio.stop()
        length = seconds
        progress = SessionProgress(seconds: seconds)
        sessionID = UUID()
        saved = false
    }

    private func pause() {
        progress.pause(at: Date())
        audio.pause()
        if progress.isFinished { saveCompletion() }
    }

    private func saveCompletion() {
        guard !saved else { return }
        saved = store.finishMeditation(id: sessionID, seconds: length)
    }

    private func syncMusic() {
        audio.update(track: track, volume: volume, playing: soundOn && progress.running && scenePhase == .active)
    }
}
