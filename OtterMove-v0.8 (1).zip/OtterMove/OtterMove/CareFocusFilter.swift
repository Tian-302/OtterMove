import AppIntents
import Foundation

struct CareFocusFilter: SetFocusFilterIntent {
    static var title: LocalizedStringResource = "小关照提醒"
    static var description: LocalizedStringResource? = "专注时暂停 OtterMove 的打卡提示。"

    @Parameter(title: "暂停打卡提示", default: false)
    var pausesPrompts: Bool

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: pausesPrompts ? "暂停打卡提示" : "显示打卡提示")
    }

    func perform() async throws -> some IntentResult {
        await CareFocusState.update(pausesPrompts)
        return .result()
    }
}

enum CareFocusState {
    static let quietKey = "otter.focus.quiet"
    static let resumedKey = "otter.focus.resumed"

    @MainActor
    static func update(_ quiet: Bool) {
        let defaults = UserDefaults.standard
        let wasQuiet = defaults.bool(forKey: quietKey)
        guard wasQuiet != quiet else { return }
        defaults.set(quiet, forKey: quietKey)
        defaults.set(quiet ? 0 : Date().timeIntervalSince1970, forKey: resumedKey)
    }

    @MainActor
    static func refresh() async {
        guard let filter = try? await CareFocusFilter.current, !Task.isCancelled else { return }
        update(filter.pausesPrompts)
    }
}
