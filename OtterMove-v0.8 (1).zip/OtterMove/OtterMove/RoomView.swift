import SwiftUI

struct RoomDraft {
    var editing = false
    var roomID: UUID?
    var placements: [FurniturePlacement] = []
    var selected: String?
}

private enum RoomNameForm: Identifiable {
    case add
    case rename(RoomSpace)

    var id: String {
        switch self {
        case .add: "add"
        case .rename(let room): room.id.uuidString
        }
    }
    var title: String {
        switch self {
        case .add: "添加空间"
        case .rename: "重命名空间"
        }
    }
}

private struct RoomNameSheet: View {
    let title: String
    @Binding var name: String
    let cancel: () -> Void
    let submit: (String) -> Void

    var body: some View {
        let cleanName = RoomSpace.cleanTitle(name)
        NavigationStack {
            Form {
                TextField("空间名称", text: $name)
                    .onChange(of: name) { text in
                        if text.count > 18 { name = String(text.prefix(18)) }
                    }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消", action: cancel)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { submit(cleanName) }
                        .disabled(cleanName.isEmpty)
                }
            }
        }
        .presentationDetents([.medium])
    }
}

struct RoomView: View {
    @EnvironmentObject private var store: AppStore
    @Binding var draft: RoomDraft
    private var editing: Bool {
        get { draft.editing }
        nonmutating set { draft.editing = newValue }
    }
    private var placements: [FurniturePlacement] {
        get { draft.placements }
        nonmutating set { draft.placements = newValue }
    }
    private var selected: String? {
        get { draft.selected }
        nonmutating set { draft.selected = newValue }
    }
    @State private var detail: Furniture?
    @State private var cancelConfirm = false
    @State private var deleteConfirm = false
    @State private var placementError = false
    @State private var nameForm: RoomNameForm?
    @State private var roomName = ""
    @State private var showsDecorations = false

    private var nextReward: Furniture? { Furniture.all.first { $0.threshold > store.stars } }
    private var room: RoomSpace { store.activeRoom }
    private var limitReached: Bool { store.rooms.count >= RoomSpace.limit }
    private var visiblePlacements: [FurniturePlacement] { editing ? placements : room.placements }
    private var changed: Bool { placements != room.placements }

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text(editing ? "布置空间" : "我的空间")
                            .font(WellnessPalette.font(.title, weight: .semibold))
                        Spacer()
                        if editing {
                            Button("取消") {
                                if changed { cancelConfirm = true }
                                else { draft = RoomDraft() }
                            }
                            .frame(minHeight: 44)
                        } else {
                            Label("\(store.stars)", systemImage: "star.fill")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(Palette.ink)
                                .padding(.vertical, 9).padding(.horizontal, 13)
                                .background(.white.opacity(0.8), in: Capsule())
                        }
                    }
                    .padding(.horizontal, 22)

                    if !editing { roomSelector.padding(.horizontal, 22) }

                    RoomScene(placements: editing ? $draft.placements : .constant(room.placements),
                              selected: $draft.selected, editing: editing)
                        .id(room.id)
                        .frame(height: editing ? max(240, min(geometry.size.height * 0.43, 330)) : min(geometry.size.width * 1.12, 500))
                        .accessibilityLabel(editing ? "房间编辑区域。选中家具后，可以拖动或使用下方方向键。" : "水獭的小屋")
                        .padding(.horizontal, 18)

                    if editing {
                        editorControls
                    } else {
                        Button {
                            enterEditing()
                        } label: {
                            Label("布置空间", systemImage: "plus")
                                .frame(maxWidth: .infinity, minHeight: 44)
                        }
                        .buttonStyle(.plain)
                        .background(.white.opacity(0.58), in: Capsule())
                        .overlay(Capsule().strokeBorder(Palette.ink.opacity(0.21), lineWidth: 1))
                        .padding(.horizontal, 70)

                        if let item = nextReward {
                            VStack(spacing: 8) {
                                HStack {
                                    Text(item.title).font(.headline)
                                    Spacer()
                                    Text("\(store.stars) / \(item.threshold) ★").font(.subheadline)
                                }
                                ProgressView(value: Double(store.stars), total: Double(item.threshold)).tint(Palette.blue)
                                Text("再收集 \(item.threshold - store.stars) 颗星").font(.caption)
                            }
                            .otterCard()
                            .padding(.horizontal, 22)
                        }
                        collection
                    }
                }
                .padding(.top, 14)
                .padding(.bottom, 22)
            }
        }
        .background(ExerciseStyle.warm.ignoresSafeArea())
        .foregroundStyle(Palette.ink)
        .sheet(item: $detail) { item in
            furnitureDetails(item)
        }
        .sheet(item: $nameForm) { form in roomNameSheet(form) }
        .confirmationDialog("放弃这次布局调整？", isPresented: $cancelConfirm, titleVisibility: .visible) {
            Button("放弃调整", role: .destructive) {
                draft = RoomDraft()
            }
            Button("继续布置", role: .cancel) {}
        }
        .alert("删除「\(room.title)」？", isPresented: $deleteConfirm) {
            Button("删除空间", role: .destructive) { store.deleteRoom(room.id) }
            Button("取消", role: .cancel) {}
        } message: {
            Text("这个空间的布置将被移除。")
        }
        .alert("没有合适的位置", isPresented: $placementError) {
            Button("好的", role: .cancel) {}
        } message: {
            Text("可以先移动或收回一件家具。")
        }
    }

    private var roomSelector: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) {
                roomMenu
                addRoomControl
            }
            VStack(alignment: .leading, spacing: 7) {
                roomMenu
                addRoomControl
            }
        }
    }

    private var roomMenu: some View {
        Menu {
            ForEach(store.rooms) { space in
                Button { store.selectRoom(space.id) } label: {
                    if room.id == space.id { Label(space.title, systemImage: "checkmark") }
                    else { Text(space.title) }
                }
            }
            Divider()
            Button {
                roomName = room.title
                nameForm = .rename(room)
            } label: { Label("重命名", systemImage: "pencil") }
            Button(role: .destructive) {
                deleteConfirm = true
            } label: { Label("删除空间", systemImage: "trash") }
            .disabled(store.rooms.count <= 1)
        } label: {
            HStack(spacing: 9) {
                Image(systemName: "square.stack")
                Text(room.title)
                    .fontWeight(.semibold)
                    .lineLimit(1)
                Spacer(minLength: 4)
                Image(systemName: "chevron.down").font(.caption2.weight(.semibold))
            }
            .font(.subheadline)
            .padding(.horizontal, 13)
            .frame(minHeight: 44)
            .background(.white.opacity(0.85), in: RoundedRectangle(cornerRadius: 15))
        }
        .accessibilityLabel("切换空间")
        .accessibilityValue(room.title)
    }

    @ViewBuilder
    private var addRoomControl: some View {
        if limitReached {
            Text("已达上限 · 3 个")
                .font(.caption.weight(.medium))
                .foregroundStyle(Palette.ink.opacity(0.72))
                .fixedSize()
        } else {
            Button {
                roomName = ""
                nameForm = .add
            } label: {
                Label("添加空间", systemImage: "plus")
                    .font(.subheadline.weight(.semibold))
                    .fixedSize()
                    .padding(.horizontal, 12)
                    .frame(minHeight: 44)
                    .background(Palette.sky, in: RoundedRectangle(cornerRadius: 15))
            }
            .buttonStyle(.plain)
        }
    }

    private func roomNameSheet(_ form: RoomNameForm) -> some View {
        RoomNameSheet(title: form.title, name: $roomName, cancel: { nameForm = nil }) { title in
            let saved: Bool
            switch form {
            case .add: saved = store.createRoom(named: title)
            case .rename(let space): saved = store.renameRoom(space.id, to: title)
            }
            if saved { nameForm = nil }
        }
    }

    private var collection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 7) {
                catalogTab("家具", decorations: false)
                catalogTab("装饰", decorations: true)
            }
            .padding(.horizontal, 22)

            ScrollView(.horizontal) {
                HStack(spacing: 10) {
                    ForEach(showsDecorations ? Furniture.decorations : Furniture.all.filter {
                        !Furniture.decorations.contains($0)
                    }) { item in
                        furnitureCard(item)
                    }
                }
                .padding(.horizontal, 22)
            }
            .scrollIndicators(.hidden)
        }
    }

    private func catalogTab(_ label: String, decorations: Bool) -> some View {
        let isSelected = showsDecorations == decorations
        return Button { showsDecorations = decorations } label: {
            Text(label)
                .font(.subheadline.weight(.semibold))
                .padding(.horizontal, 15)
                .frame(minHeight: 42)
                .foregroundStyle(isSelected ? Color.white : Palette.ink)
                .background(isSelected ? Palette.ink : .white.opacity(0.65), in: Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }

    private func furnitureCard(_ item: Furniture) -> some View {
        let unlocked = store.stars >= item.threshold
        let placement = visiblePlacements.first { $0.id == item.id }
        return Button {
            if unlocked {
                if !editing { enterEditing() }
                addOrSelect(item)
            } else {
                detail = item
            }
        } label: {
            VStack(spacing: 5) {
                FurnitureIllustration(item: item, finish: placement?.finish)
                    .frame(width: 61, height: 38)
                    .opacity(unlocked ? 1 : 0.52)
                Text(item.title).font(.caption)
                if !unlocked {
                    Label("\(item.threshold) ★", systemImage: "lock.fill").font(.caption2)
                } else {
                    Image(systemName: placement != nil ? "checkmark.circle.fill" : "plus.circle")
                        .font(.caption).foregroundStyle(Palette.blue)
                }
            }
            .frame(width: 86, height: 92)
            .background(Palette.ivory, in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(
                editing && selected == item.id ? Palette.blue : Color.clear, lineWidth: 2))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(item.title + (unlocked ? "，已解锁" : "，需要\(item.threshold)颗星"))
    }

    private var editorControls: some View {
        VStack(spacing: 10) {
            if let placement = placements.first(where: { $0.id == selected }),
               let item = Furniture.find(placement.id) {
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(item.title).font(.subheadline.weight(.semibold))
                        Spacer()
                        if !item.surface.isWall && item.surface != .tabletop {
                            Button { adjustSelected { $0.turns = ($0.turns + 1) % 4 } } label: {
                                Image(systemName: "rotate.right").frame(width: 44, height: 44)
                            }
                            .accessibilityLabel("旋转\(item.title)")
                        }
                        Button {
                            removeSelected(item)
                        } label: {
                            Image(systemName: "archivebox").frame(width: 44, height: 44)
                        }
                        .accessibilityLabel("收回\(item.title)")
                    }
                    HStack(spacing: 12) {
                        nudgeButton("arrow.left", label: "左移", dx: -1, dy: 0, placement: placement)
                        nudgeButton("arrow.right", label: "右移", dx: 1, dy: 0, placement: placement)
                        nudgeButton("arrow.up", label: "上移", dx: 0, dy: -1, placement: placement)
                        nudgeButton("arrow.down", label: "下移", dx: 0, dy: 1, placement: placement)
                    }
                    if item.id == "books" {
                        bookSupportMenu(placement)
                    }
                    if let defaultFinish = item.defaultFinish {
                        colorChoices(selection: placement.finish ?? defaultFinish)
                    }
                }
                .padding(.horizontal, 22)
            }
            collection
            PrimaryButton(title: "完成") {
                if store.saveRoom(placements, in: draft.roomID) { draft = RoomDraft() }
            }
            .padding(.horizontal, 22)
        }
        .buttonStyle(.plain)
    }

    private func colorChoices(selection: FurnitureFinish) -> some View {
        HStack(spacing: 6) {
            ForEach(FurnitureFinish.allCases) { finish in
                let chosen = finish == selection
                Button { adjustSelected { $0.finish = finish } } label: {
                    VStack(spacing: 4) {
                        Circle()
                            .fill(finish.highlight)
                            .frame(width: 27, height: 27)
                            .overlay(Circle().strokeBorder(Palette.ink.opacity(chosen ? 0.9 : 0.19),
                                                           lineWidth: chosen ? 1.8 : 1))
                            .overlay {
                                if chosen { Image(systemName: "checkmark").font(.caption2.weight(.bold)) }
                            }
                        Text(finish.title).font(.caption2).multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity, minHeight: 52)
                }
                .accessibilityAddTraits(chosen ? .isSelected : [])
            }
        }
        .padding(.vertical, 3)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("家具颜色")
    }

    private func nudgeButton(_ symbol: String, label: String, dx: Float, dy: Float,
                             placement: FurniturePlacement) -> some View {
        Button {
            let delta = placement.dragDelta(horizontal: dx * 0.13, vertical: dy * 0.065,
                                            in: placements)
            adjustSelected {
                $0.x += delta.x
                $0.z += delta.z
            }
        } label: {
            Image(systemName: symbol).frame(maxWidth: .infinity, minHeight: 44)
                .background(Palette.sky, in: RoundedRectangle(cornerRadius: 12))
        }
        .accessibilityLabel(label)
        .disabled(placement.id == "books" && placement.supportID == nil && dy != 0)
    }

    private func bookSupportMenu(_ book: FurniturePlacement) -> some View {
        let supports = placements.filter { Furniture.find($0.id)?.topHeight != nil }
        let current = book.supportID.flatMap(Furniture.find)?.title ?? "墙上书架"
        return Menu {
            Button("墙上书架") { moveBooks(to: nil) }
            ForEach(supports) { support in
                Button(Furniture.find(support.id)?.title ?? support.id) { moveBooks(to: support) }
            }
        } label: {
            Label(current, systemImage: "books.vertical")
                .font(.subheadline.weight(.semibold))
                .frame(minHeight: 38)
        }
        .accessibilityLabel("书本摆放位置")
        .accessibilityValue(current)
    }

    private func moveBooks(to support: FurniturePlacement?) {
        guard let index = placements.firstIndex(where: { $0.id == "books" }),
              placements[index].supportID != support?.id else { return }
        guard let book = Furniture.books(on: support, in: placements) else {
            placementError = true
            return
        }
        placements[index] = book
    }

    private func removeSelected(_ item: Furniture) {
        var updated = placements.filter { $0.id != item.id }
        if let index = updated.firstIndex(where: { $0.supportID == item.id }) {
            guard let books = Furniture.shelfBooks(in: updated) else {
                placementError = true
                return
            }
            updated[index] = books
        }
        placements = updated
        selected = nil
    }

    private func furnitureDetails(_ item: Furniture) -> some View {
        let unlocked = store.stars >= item.threshold
        return NavigationStack {
            VStack(spacing: 14) {
                FurnitureIllustration(item: item).frame(height: 210)
                Text(item.title).font(.title2.weight(.semibold))
                Label(unlocked ? "已解锁" : "未解锁", systemImage: unlocked ? "checkmark.circle.fill" : "lock")
                    .foregroundStyle(unlocked ? Palette.blue : Color.gray)
                if unlocked {
                    PrimaryButton(title: visiblePlacements.contains { $0.id == item.id } ? "调整位置" : "放入小屋") {
                        detail = nil
                        enterEditing()
                        addOrSelect(item)
                    }
                } else {
                    ProgressView(value: Double(store.stars), total: Double(item.threshold)).tint(Palette.blue)
                    Text("\(store.stars) / \(item.threshold) ★").font(.headline)
                    Text("再运动 \(item.threshold - store.stars) 次解锁").font(.subheadline)
                }
                Spacer(minLength: 0)
            }
            .padding(24)
            .background(Color.white)
            .toolbar { Button("关闭") { detail = nil } }
        }
        .presentationDetents([.large])
    }

    private func enterEditing() {
        placements = room.placements
        selected = placements.first(where: { $0.id == "rug" })?.id ?? placements.first?.id
        draft.roomID = room.id
        editing = true
    }

    private func addOrSelect(_ item: Furniture) {
        guard store.stars >= item.threshold else { return }
        if placements.contains(where: { $0.id == item.id }) {
            selected = item.id
            return
        }
        if item.id == "books" {
            let support = placements.first { $0.id == "desk" } ?? placements.first { $0.id == "sill" }
            if let books = Furniture.books(on: support, in: placements) {
                placements.append(books)
                selected = books.id
            } else {
                placementError = true
            }
            return
        }
        var candidate = FurniturePlacement(id: item.id, x: item.defaultX, z: item.defaultZ, turns: 0)
        if Furniture.canPlace(candidate, in: placements) {
            placements.append(candidate)
            selected = item.id
            return
        }
        // Search for an available starting position; the user can adjust it before saving.
        for x in stride(from: Float(-1.2), through: Float(1.2), by: Float(0.24)) {
            for z in stride(from: Float(-1.2), through: Float(1.2), by: Float(0.24)) {
                candidate.x = x
                candidate.z = z
                if Furniture.canPlace(candidate, in: placements) {
                    placements.append(candidate)
                    selected = item.id
                    return
                }
            }
        }
        placementError = true
    }

    private func adjustSelected(_ transform: (inout FurniturePlacement) -> Void) {
        guard let index = placements.firstIndex(where: { $0.id == selected }) else { return }
        var candidate = placements[index]
        transform(&candidate)
        if Furniture.canPlace(candidate, in: placements) {
            placements[index] = candidate
        }
    }
}
