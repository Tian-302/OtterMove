import SwiftUI

struct OnboardingView: View {
    let onFinish: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var page = 0
    private let titles = [
        "你好，我是 Otter！",
        "每一种心情，\n都值得被看见。",
        "让每一天，\n都有温柔的回应。"
    ]
    private let subtitles = [
        "从今天开始，让我陪你一起记录生活中的小小快乐。",
        "开心、放松、焦虑或疲惫，都可以告诉我。",
        "记录今天的心情，和 Otter 一起慢慢成长。"
    ]

    var body: some View {
        VStack(spacing: 18) {
            TabView(selection: $page) {
                ForEach(titles.indices, id: \.self) { index in
                    ScrollView {
                        VStack(spacing: 22) {
                            Text(titles[index])
                                .font(WellnessPalette.font(.largeTitle, weight: .bold))
                                .accessibilityAddTraits(.isHeader)
                            Text(subtitles[index])
                                .font(WellnessPalette.font(.body))
                                .foregroundStyle(WellnessPalette.muted)
                            illustration(index)
                                .frame(maxWidth: 320)
                        }
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                        .padding(26)
                        .padding(.top, 28)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            HStack(spacing: 8) {
                ForEach(titles.indices, id: \.self) { index in
                    Circle().fill(page == index ? WellnessPalette.sageInk : WellnessPalette.sage.opacity(0.42))
                        .frame(width: 8, height: 8)
                }
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("第 \(page + 1) 页，共 \(titles.count) 页")
            WellnessButton(title: page == 2 ? "立即体验" : "下一步", color: WellnessPalette.blue) {
                if page == 2 { onFinish() }
                else { withAnimation(reduceMotion ? nil : .easeInOut) { page += 1 } }
            }
            .padding(.horizontal, 28)
            .padding(.bottom, 16)
        }
        .background(WellnessPalette.page.ignoresSafeArea())
    }

    @ViewBuilder
    private func illustration(_ index: Int) -> some View {
        if index == 1 {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach([MoodType.happy, .relaxed, .anxious, .tired]) { mood in
                    OtterArtworkImage(name: OtterArtwork.face(mood))
                        .frame(height: 100)
                        .frame(maxWidth: .infinity)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                }
            }
        } else {
            OtterMovingThumbnail(name: index == 0 ? OtterArtwork.hero : OtterArtwork.celebration)
                .frame(height: 255)
                .clipShape(RoundedRectangle(cornerRadius: 28))
        }
    }
}
