import SwiftUI
import Combine

struct HomeView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var moods: MoodStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.dynamicTypeSize) private var typeSize
    @Environment(\.scenePhase) private var scenePhase
    let openCheckin: () -> Void

    @State private var selected: MoodType?
    @State private var summary = ""
    @State private var draftDay: String?
    @State private var interaction: String?
    @State private var interactionTask: Task<Void, Never>?
    @State private var showsSettings = false
    @State private var showsGuide = false
    @State private var replayingGuide = false
    @State private var showsSuccess = false
    @State private var moodError: String?
    @State private var now = Date()
    private let clock = Timer.publish(every: 20, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geometry in
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 0) {
                        cover(height: geometry.size.height) {
                            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.4)) {
                                proxy.scrollTo("mood", anchor: .top)
                            }
                        }
                        .id("home-stage")
                        VStack(spacing: 18) {
                            moodPicker {
                                withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.35)) {
                                    proxy.scrollTo("home-stage", anchor: .top)
                                }
                            }
                            summaryCard
                            WellnessButton(title: moods.record(for: now) == nil ? "记录今日心情" : "更新今日心情",
                                           perform: saveMood)
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 24)
                        .padding(.bottom, 34)
                        .frame(maxWidth: 590)
                        .frame(maxWidth: .infinity)
                        .background(WellnessPalette.cream)
                        .id("mood")
                    }
                }
                .scrollIndicators(.hidden)
            }
        }
        .background {
            LinearGradient(colors: [Color(red: 0.93, green: 0.97, blue: 1),
                                    Color(red: 0.81, green: 0.90, blue: 0.98),
                                    Color(red: 0.74, green: 0.86, blue: 0.96)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
        }
        .onAppear { refreshDay(Date()) }
        .onReceive(clock) { refreshDay($0) }
        .onReceive(NotificationCenter.default.publisher(for: .NSCalendarDayChanged)) { _ in refreshDay(Date()) }
        .onChange(of: scenePhase) { phase in
            if phase == .active { refreshDay(Date()) }
        }
        .onDisappear {
            interactionTask?.cancel()
            interaction = nil
        }
        .sheet(isPresented: $showsSettings, onDismiss: showRequestedGuide) {
            SettingsView { showsGuide = true }
        }
        .fullScreenCover(isPresented: $replayingGuide) {
            OnboardingView { replayingGuide = false }
        }
        .sheet(isPresented: $showsSuccess) { successSheet }
        .alert("今日心情", isPresented: Binding(
            get: { moodError != nil }, set: { if !$0 { moodError = nil } }
        )) {
            Button("好的", role: .cancel) { moodError = nil }
        } message: { Text(moodError ?? "") }
    }

    private var greeting: some View {
        let hour = Calendar.current.component(.hour, from: now)
        let greeting = (5..<12).contains(hour) ? "早安" : (12..<18).contains(hour) ? "午安" : "晚安"
        return HStack(alignment: .top, spacing: 10) {
            VStack(alignment: .leading, spacing: 6) {
                Text("\(greeting)，Otter！")
                    .font(WellnessPalette.font(.largeTitle, weight: .bold))
                    .accessibilityAddTraits(.isHeader)
                Text("今天也要和水獭一起快乐生活呀～ 🌿")
                    .font(.subheadline)
                    .foregroundStyle(WellnessPalette.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
            Button { showsSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18))
                    .frame(width: 46, height: 46)
                    .background(.white, in: Circle())
                    .foregroundStyle(WellnessPalette.ink)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("设置")
        }
    }

    private func cover(height: CGFloat, openMoods: @escaping () -> Void) -> some View {
        VStack(spacing: 14) {
            greeting
                .padding(.top, 12)

            character
                .frame(height: max(250, min(540, height - 280)))

            HStack(spacing: 12) {
                Button(action: openMoods) {
                    Label("记录心情", systemImage: "face.smiling")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity, minHeight: 53)
                        .foregroundStyle(.white)
                        .background(Palette.ink, in: Capsule())
                }
                .buttonStyle(.plain)
                Button(action: openCheckin) {
                    Label("今日打卡", systemImage: "checkmark.square")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity, minHeight: 53)
                        .foregroundStyle(Palette.ink)
                        .background(.white.opacity(0.72), in: Capsule())
                }
                .buttonStyle(.plain)
            }
            statistics
        }
        .padding(.horizontal, 22)
        .padding(.bottom, 23)
        .frame(maxWidth: 590)
        .frame(maxWidth: .infinity, minHeight: height, alignment: .top)
    }

    private var character: some View {
        Button(action: greetOtter) {
            GeometryReader { geometry in
                let size = geometry.size
                ZStack {
                    Ellipse()
                        .fill(.white.opacity(0.60))
                        .blur(radius: 48)
                        .padding(24)
                    Ellipse()
                        .fill(Palette.blue.opacity(0.24))
                        .frame(width: size.width * 0.67, height: 21)
                        .blur(radius: 8)
                        .position(x: size.width * 0.51, y: size.height - 16)
                    OtterArtworkImage(name: selected.map(OtterArtwork.fullBody) ?? OtterArtwork.hero)
                        .frame(width: size.width * 0.94, height: size.height - 13)
                        .id(selected)
                        .transition(.opacity)
                        .position(x: size.width * 0.50, y: size.height * 0.50)
                }
                .overlay(alignment: .topTrailing) {
                    if let interaction {
                        Text(interaction)
                            .font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 14)
                            .padding(.vertical, 10)
                            .background(.white.opacity(0.90), in: Capsule())
                            .transition(.opacity)
                    }
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel("和水獭互动")
        .accessibilityValue(interaction ?? selected?.title ?? "")
    }

    private func moodPicker(showReaction: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("今天的你是什么状态呢？")
                .font(WellnessPalette.font(.headline, weight: .semibold))
                .accessibilityAddTraits(.isHeader)
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 9),
                                     count: typeSize.isAccessibilitySize ? 2 : 3), spacing: 9) {
                ForEach(MoodType.allCases) { mood in
                    Button {
                        let date = Date()
                        refreshDay(date)
                        let response = mood.summary(excluding: selected == mood ? summary : "")
                        guard moods.save(mood, summary: response, date: date) else {
                            moodError = "这次心情暂时无法保存，请稍后重试。"
                            return
                        }
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.22)) {
                            selected = mood
                            summary = response
                        }
                        showReaction()
                    } label: {
                        VStack(spacing: 4) {
                            OtterArtworkImage(name: OtterArtwork.face(mood))
                                .frame(height: 102)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            Text(mood.title).font(.subheadline.weight(.semibold))
                        }
                        .padding(7)
                        .frame(maxWidth: .infinity, minHeight: 128)
                        .background(selected == mood ? WellnessPalette.blue.opacity(0.38) : .white,
                                    in: RoundedRectangle(cornerRadius: 16))
                        .overlay {
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Palette.ink.opacity(selected == mood ? 1 : 0.08),
                                              lineWidth: selected == mood ? 1.5 : 1)
                        }
                        .overlay(alignment: .topTrailing) {
                            if selected == mood {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 15))
                                    .foregroundStyle(Palette.ink)
                                    .padding(5)
                            }
                        }
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(selected == mood ? .isSelected : [])
                }
            }
        }
    }

    private var summaryCard: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 9) {
                summaryText
                Spacer(minLength: 6)
                changeSentence
            }
            VStack(alignment: .leading, spacing: 4) {
                summaryText
                changeSentence
            }
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(WellnessPalette.blue.opacity(0.28), in: RoundedRectangle(cornerRadius: 24))
    }

    private var summaryText: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "star.fill").foregroundStyle(WellnessPalette.gold)
                .accessibilityHidden(true)
            Text(summary.isEmpty ? "选一种心情，听听 Otter 的回应。" : summary)
                .id(summary)
                .transition(.opacity)
                .font(.subheadline.weight(.medium))
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var changeSentence: some View {
        Button {
            guard let selected else { return }
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                summary = selected.summary(excluding: summary)
            }
        } label: {
            Label("换一句", systemImage: "arrow.triangle.2.circlepath")
                .font(.caption.weight(.semibold))
                .fixedSize()
                .foregroundStyle(WellnessPalette.sageInk)
                .frame(minHeight: 44)
        }
        .buttonStyle(.plain)
        .disabled(selected == nil)
        .opacity(selected == nil ? 0.5 : 1)
    }

    private var statistics: some View {
        let seconds = store.completedExercise(on: now).reduce(0) { $0 + $1.seconds }
        let duration = seconds == 0 || seconds >= 60 ? "\(seconds / 60) 分钟" : "\(seconds) 秒"
        let checked = store.careDay(on: now).completed.count
        return ViewThatFits(in: .horizontal) {
            HStack(spacing: 9) {
                stat("今日运动", value: duration, icon: "figure.run", color: WellnessPalette.blue)
                checkinStat(checked)
                stat("累计星星", value: "\(store.stars) 颗", icon: "star.fill", color: WellnessPalette.gold)
            }
            VStack(spacing: 9) {
                stat("今日运动", value: duration, icon: "figure.run", color: WellnessPalette.blue)
                checkinStat(checked)
                stat("累计星星", value: "\(store.stars) 颗", icon: "star.fill", color: WellnessPalette.gold)
            }
        }
    }

    private func checkinStat(_ checked: Int) -> some View {
        Button(action: openCheckin) {
            stat("健康打卡", value: "\(checked) / 6", icon: "checkmark.circle.fill", color: WellnessPalette.sage)
        }
        .buttonStyle(.plain)
    }

    private func stat(_ title: String, value: String, icon: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Image(systemName: icon).font(.subheadline.weight(.semibold))
                .foregroundStyle(color).accessibilityHidden(true)
            Text(title).font(.caption.weight(.medium)).foregroundStyle(Palette.ink.opacity(0.72))
            Text(value).font(WellnessPalette.font(.subheadline, weight: .bold)).monospacedDigit()
        }
        .fixedSize(horizontal: true, vertical: false)
        .padding(11)
        .frame(maxWidth: .infinity, minHeight: 76, alignment: .leading)
        .wellnessCard()
        .foregroundStyle(Palette.ink)
        .accessibilityElement(children: .combine)
    }

    private func showRequestedGuide() {
        guard showsGuide else { return }
        showsGuide = false
        replayingGuide = true
    }

    private var successSheet: some View {
        ScrollView {
            VStack(spacing: 12) {
                OtterMovingThumbnail(name: OtterArtwork.celebration).frame(height: 140)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                Text("心情记录成功！")
                    .font(WellnessPalette.font(.title2, weight: .bold))
                Text("今天的心情已保存，记得继续好好照顾自己哦～")
                    .font(.subheadline)
                    .foregroundStyle(WellnessPalette.muted)
                    .multilineTextAlignment(.center)
                WellnessButton(title: "好的", color: WellnessPalette.blue) { showsSuccess = false }
            }
            .padding(23)
            .frame(maxWidth: 440)
            .frame(maxWidth: .infinity)
        }
        .background(WellnessPalette.cream.ignoresSafeArea())
        .presentationDetents([.medium, .large])
    }

    private func refreshDay(_ date: Date) {
        now = date
        let key = AppStore.dayKey(date)
        guard draftDay != key else { return }
        draftDay = key
        let record = moods.record(for: date)
        selected = record?.mood
        summary = record?.summary ?? ""
    }

    private func saveMood() {
        let date = Date()
        refreshDay(date)
        guard let selected else { moodError = "请先选择今天的心情。"; return }
        guard moods.save(selected, summary: summary, date: date) else {
            moodError = "这次心情暂时无法保存，请稍后重试。"
            return
        }
        showsSuccess = true
    }

    private func greetOtter() {
        interactionTask?.cancel()
        let options = ["嘿嘿，被你发现啦！", "今天也要开心呀！", "抱抱你～", "Otter 一直陪着你！"]
        withAnimation(reduceMotion ? nil : .easeOut(duration: 0.12)) {
            interaction = options.filter { $0 != interaction }.randomElement()
        }
        interactionTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 2_050_000_000)
            guard !Task.isCancelled else { return }
            withAnimation(reduceMotion ? nil : .easeOut) {
                interaction = nil
            }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(openCheckin: {})
            .environmentObject(AppStore())
            .environmentObject(MoodStore())
            .environmentObject(HealthReference())
    }
}
