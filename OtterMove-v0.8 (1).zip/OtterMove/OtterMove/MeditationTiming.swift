import Foundation

enum LakeLight: String, Equatable, CaseIterable {
    case day, dusk, night

    private static let shanghai: Calendar = {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Asia/Shanghai") ?? TimeZone(secondsFromGMT: 8 * 3600) ?? .current
        return calendar
    }()

    static func at(_ date: Date) -> LakeLight {
        switch shanghai.component(.hour, from: date) {
        case 6..<17: return .day
        case 17..<19: return .dusk
        default: return .night
        }
    }
}

enum BreathPhase: Equatable {
    case inhale, hold, exhale

    var prompt: String {
        switch self {
        case .inhale: return "吸气"
        case .hold: return "屏气"
        case .exhale: return "呼气"
        }
    }
}

struct BreathCue: Equatable {
    let phase: BreathPhase
    let seconds: Int

    static func at(_ elapsed: TimeInterval) -> BreathCue {
        let step = max(0, elapsed).truncatingRemainder(dividingBy: 12)
        switch step {
        case ..<4: return BreathCue(phase: .inhale, seconds: Int(ceil(4 - step)))
        case ..<6: return BreathCue(phase: .hold, seconds: Int(ceil(6 - step)))
        default: return BreathCue(phase: .exhale, seconds: Int(ceil(12 - step)))
        }
    }
}

enum MeditationTrack: String, CaseIterable, Identifiable {
    case piano, ambient, water, silent
    var id: Self { self }

    var label: String {
        switch self {
        case .piano: return "轻柔钢琴"
        case .ambient: return "舒缓氛围"
        case .water: return "自然水声配乐"
        case .silent: return "无音乐"
        }
    }

    var filename: String? {
        switch self {
        case .piano: return "MeditationPiano"
        case .ambient: return "MeditationAmbient"
        case .water: return "MeditationWater"
        case .silent: return nil
        }
    }

    var icon: String {
        switch self {
        case .piano: return "pianokeys"
        case .ambient: return "sparkles"
        case .water: return "water.waves"
        case .silent: return "speaker.slash"
        }
    }
}
