import SwiftUI
import Combine
import AVFoundation

struct ExerciseView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let activity: Activity
    let openRoom: () -> Void
    var chooseNext: (Activity) -> Void = { _ in }

    @State private var progress = SessionProgress(seconds: 20)
    @State private var sessionID = UUID()
    @State private var demo = false
    @State private var started = false
    @State private var ended = false
    @State private var saved = false
    @State private var complete = false
    @State private var reward: Reward?
    @State private var confirmExit = false
    @State private var wasRunning = false
    @State private var speech = AVSpeechSynthesizer()
    private let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()

    var body: some View {
        VStack {
            HStack {
                Button(action: requestExit) {
                    Image(systemName: "chevron.left").frame(width: 44, height: 44)
                }
                .accessibilityLabel("结束并返回")
                Spacer()
                Text(ended ? "这次小休息" : activity.title).font(.headline)
                Spacer()
                Button(action: speak) {
                    Image(systemName: "speaker.wave.2").frame(width: 44, height: 44)
                }
                .accessibilityLabel("朗读指引")
                .disabled(ended)
            }
            .padding(.horizontal, 10)
            GeometryReader { geometry in
                ScrollView {
                    if ended { result }
                    else { running(stageHeight: max(300, geometry.size.height * 0.56)) }
                }
                .scrollIndicators(.hidden)
            }
        }
        .padding(.bottom, 4)
        .foregroundStyle(Palette.ink)
        .background((ended ? ExerciseStyle.warm : ExerciseStyle.stage(for: activity)).ignoresSafeArea())
        .buttonStyle(.plain)
        .onAppear {
            guard !started else { return }
            started = true
            demo = store.demoMode
            progress = SessionProgress(seconds: demo ? 5 : activity.seconds)
            progress.resume(at: Date())
        }
        .onReceive(timer) { now in
            guard !ended else { return }
            progress.tick(at: now)
            if progress.isFinished { finish(full: true) }
        }
        .onChange(of: scenePhase) { phase in
            if phase != .active {
                progress.pause(at: Date())
                speech.stopSpeaking(at: .immediate)
            }
        }
        .onDisappear { speech.stopSpeaking(at: .immediate) }
        .alert("结束这次运动？", isPresented: $confirmExit) {
            Button("继续", role: .cancel) {
                if wasRunning { progress.resume(at: Date()) }
            }
            Button("结束", role: .destructive) { finish(full: false) }
        } message: { Text("已活动的时间会保留。") }
    }

    private func running(stageHeight: CGFloat) -> some View {
        VStack(spacing: 8) {
            if demo {
                Text("快速演示").font(.caption.weight(.medium)).foregroundStyle(.secondary)
            }
            OtterTechniqueStage(activity: activity)
                .frame(height: stageHeight)
                .frame(maxWidth: 550)
            Text(activity.cue)
                .font(.subheadline.weight(.medium))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            Text(SessionProgress.clockText(progress.remaining))
                .font(.system(size: 71, weight: .light, design: .rounded))
                .monospacedDigit()
                .accessibilityLabel("剩余 \(progress.remaining) 秒")
            ProgressView(value: progress.elapsed, total: progress.duration)
                .tint(Palette.ink)
                .frame(maxWidth: 152)
                .accessibilityHidden(true)
                .padding(.bottom, 4)
            RoundControl(symbol: progress.running ? "pause.fill" : "play.fill",
                         label: progress.running ? "暂停" : "继续") {
                if progress.running {
                    progress.pause(at: Date())
                    speech.stopSpeaking(at: .immediate)
                } else {
                    progress.resume(at: Date())
                }
            }
            Button("提前结束", action: requestExit)
                .frame(minHeight: 44)
                .font(.subheadline)
        }
        .padding(.horizontal, 23)
        .padding(.bottom, 14)
        .frame(maxWidth: .infinity)
    }

    private var result: some View {
        VStack(spacing: 18) {
            Text(complete ? "运动完成" : "这次先休息到这里")
                .font(.title2.weight(.semibold))
            Text("活动了 \(Int(progress.elapsed)) 秒")
                .font(.subheadline)
            if demo {
                Text("演示模式，不计入星星和记录").font(.caption)
            } else if complete && saved {
                Label("+1", systemImage: "star.fill")
                    .font(.title2.weight(.semibold)).foregroundStyle(Palette.blue)
            }

            if let next = reward?.newActivity, complete {
                Text("恭喜，解锁新运动").font(.headline)
                UnlockCard(activity: next)
                    .frame(height: 300)
                HStack {
                    Button("稍后再练") { dismiss() }.frame(maxWidth: .infinity, minHeight: 48)
                    PrimaryButton(title: "立即练习") { chooseNext(next) }
                }
            } else {
                OtterMovingThumbnail(name: complete ? OtterArtwork.celebration : OtterArtwork.mood(.relaxed))
                    .frame(height: 310)
            }

            if let furniture = reward?.furniture.first {
                VStack(spacing: 5) {
                    Text("解锁\(furniture.title)").font(.headline)
                    FurnitureIllustration(item: furniture).frame(height: 140)
                    PrimaryButton(title: "去小屋摆放", action: openRoom)
                }
                .otterCard()
            } else {
                PrimaryButton(title: "去小屋看看", action: openRoom)
            }
            if !demo && !saved {
                Text("记录尚未保存，可以重试。").font(.caption)
                Button("重新保存") { saveResult() }
                    .frame(minHeight: 44)
            }
            Button("返回运动") { dismiss() }.frame(minHeight: 44)
        }
        .padding(24)
    }

    private func finish(full: Bool) {
        guard !ended else { return }
        progress.pause(at: Date())
        speech.stopSpeaking(at: .immediate)
        complete = full
        ended = true
        if demo {
            reward = Reward(newActivity: full ? Activity.next(after: activity) : nil, furniture: [])
            saved = true
        } else {
            saveResult()
        }
    }

    private func saveResult() {
        guard !saved else { return }
        reward = store.finishExercise(id: sessionID, activity: activity,
                                      seconds: Int(progress.elapsed), complete: complete)
        saved = store.profile.records.contains { $0.id == sessionID }
    }

    private func requestExit() {
        if ended { dismiss(); return }
        wasRunning = progress.running
        progress.pause(at: Date())
        if progress.isFinished { finish(full: true); return }
        speech.stopSpeaking(at: .immediate)
        confirmExit = true
    }
    private func speak() {
        guard !ended else { return }
        speech.stopSpeaking(at: .immediate)
        let text = AVSpeechUtterance(string: activity.cue)
        text.voice = AVSpeechSynthesisVoice(language: "zh-CN")
        text.rate = 0.42
        speech.speak(text)
    }
}

private struct FaceVisibility: AnimatableModifier {
    var angle: Double
    let front: Bool
    var animatableData: Double {
        get { angle }
        set { angle = newValue }
    }
    func body(content: Content) -> some View {
        content.opacity((angle >= 90) == front ? 1 : 0)
    }
}

struct UnlockCard: View {
    let activity: Activity
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var angle = 0.0
    @State private var shine = false

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 28)
                .fill(Palette.sky)
                .overlay {
                    VStack(spacing: 16) {
                        Image(systemName: "pawprint").font(.system(size: 48, weight: .light))
                        Text("OtterMove").font(.caption.weight(.semibold))
                    }
                }
                .modifier(FaceVisibility(angle: angle, front: false))
            VStack(spacing: 2) {
                OtterTechniqueStage(activity: activity)
                    .frame(height: 205)
                Text(activity.title).font(.headline)
                Text("\(activity.seconds) 秒 · \(activity.place.rawValue)").font(.caption)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.white, in: RoundedRectangle(cornerRadius: 28))
            .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
            .modifier(FaceVisibility(angle: angle, front: true))
        }
        .overlay(RoundedRectangle(cornerRadius: 28).strokeBorder(Palette.blue.opacity(0.55), lineWidth: 2))
        .rotation3DEffect(.degrees(angle), axis: (x: 0, y: 1, z: 0), perspective: 0.45)
        .overlay {
            if !reduceMotion {
                LinearGradient(colors: [.clear, .white.opacity(0.85), .clear], startPoint: .leading, endPoint: .trailing)
                    .frame(width: 65).rotationEffect(.degrees(22))
                    .offset(x: shine ? 260 : -260)
                    .allowsHitTesting(false)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 28))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("新运动已解锁，\(activity.title)，\(activity.seconds) 秒")
        .task {
            if reduceMotion { angle = 180; return }
            try? await Task.sleep(nanoseconds: 150_000_000)
            guard !Task.isCancelled else { return }
            withAnimation(.easeInOut(duration: 0.8)) { angle = 180 }
            try? await Task.sleep(nanoseconds: 850_000_000)
            guard !Task.isCancelled else { return }
            withAnimation(.linear(duration: 0.65)) { shine = true }
        }
    }
}
