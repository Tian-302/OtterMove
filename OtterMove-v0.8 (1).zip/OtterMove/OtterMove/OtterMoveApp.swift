import SwiftUI

@main
struct OtterMoveApp: App {
    @StateObject private var store = AppStore()
    @StateObject private var moods = MoodStore()
    @StateObject private var health = HealthReference()
    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(store)
                .environmentObject(moods)
                .environmentObject(health)
        }
    }
}
