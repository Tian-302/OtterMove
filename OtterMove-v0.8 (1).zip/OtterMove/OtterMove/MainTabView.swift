import SwiftUI

struct MainTabView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("isFirstLaunch") private var firstLaunch = true
    @State private var page = AppPage.home
    @State private var choosingExerciseState = false
    @State private var shortExercise: Activity?
    @State private var roomDraft = RoomDraft()

    var body: some View {
        Group {
            if firstLaunch {
                OnboardingView { firstLaunch = false }
            } else {
                currentPage
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .safeAreaInset(edge: .top, spacing: 0) {
                        TopNavigation(page: $page)
                    }
                    .statusBarHidden(false)
                    .preferredColorScheme(page == .meditation ? .dark : .light)
            }
        }
        .font(WellnessPalette.font(.body))
        .foregroundStyle(WellnessPalette.ink)
        .task(id: scenePhase) {
            if scenePhase == .active { await CareFocusState.refresh() }
        }
        .alert("暂时无法保存", isPresented: Binding(
            get: { store.errorMessage != nil },
            set: { if !$0 { store.errorMessage = nil } }
        )) {
            Button("知道了", role: .cancel) { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
        .fullScreenCover(item: $shortExercise) { activity in
            ExerciseView(activity: activity, openRoom: {
                shortExercise = nil
                page = .room
            })
            .environmentObject(store)
        }
    }

    @ViewBuilder
    private var currentPage: some View {
        switch page {
        case .home:
            HomeView(openCheckin: { page = .checkin })
        case .exercise:
            exercise
        case .meditation:
            MeditationView()
        case .checkin:
            CheckinPage(startStretch: startStretch, openMeditation: { page = .meditation })
        case .room:
            RoomView(draft: $roomDraft)
        }
    }

    private var exercise: some View {
        Group {
            if choosingExerciseState || !store.profile.hasChosenState {
                StateSelectionView { choosingExerciseState = false }
            } else {
                ExerciseSelectionView(openRoom: { page = .room }, changeState: { choosingExerciseState = true })
                    .id(store.profile.place.rawValue + store.profile.energy.rawValue)
            }
        }
    }

    private func startStretch() {
        page = .exercise
        shortExercise = .careStretch
    }
}

private struct TopNavigation: View {
    @Binding var page: AppPage
    @Environment(\.dynamicTypeSize) private var typeSize

    private var night: Bool { page == .meditation }
    private let destinations: [AppPage] = [.exercise, .meditation, .checkin, .room]

    var body: some View {
        HStack(spacing: 9) {
            Button { page = .home } label: {
                OtterArtworkImage(name: OtterArtwork.hero)
                    .padding(.horizontal, 5)
                    .offset(y: 8)
                    .frame(width: 46, height: 46)
                    .background(
                        LinearGradient(colors: [Color.white, Palette.sky],
                                       startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle()
                    )
                    .clipShape(Circle())
                    .overlay(Circle().strokeBorder(.white.opacity(0.65), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("首页")
            .accessibilityAddTraits(page == .home ? .isSelected : [])

            HStack(spacing: 2) {
                ForEach(destinations, id: \.self) { destination in
                    tab(destination)
                }
            }
            .padding(4)
            .background(night ? Color.white.opacity(0.13) : Color.white.opacity(0.74), in: Capsule())
            .overlay(Capsule().strokeBorder(.white.opacity(night ? 0.22 : 0.85), lineWidth: 1))
        }
        .frame(maxWidth: 500)
        .padding(.horizontal, 18)
        .padding(.top, 4)
        .padding(.bottom, 7)
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("顶部导航")
    }

    private func tab(_ destination: AppPage) -> some View {
        let selected = destination == page
        return Button { page = destination } label: {
            HStack(spacing: 5) {
                Image(systemName: destination.symbol).font(.system(size: 17, weight: .semibold))
                if selected && !typeSize.isAccessibilitySize {
                    Text(destination.title).font(.system(size: 13, weight: .semibold))
                        .fixedSize()
                }
            }
            .padding(.horizontal, selected ? 7 : 3)
            .frame(maxWidth: .infinity, minHeight: 44)
            .foregroundStyle(selected ? (night ? Palette.ink : .white) : (night ? .white : Palette.ink))
            .background {
                if selected {
                    Capsule().fill(night ? Color.white.opacity(0.94) : Palette.ink)
                }
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(destination.title)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}
