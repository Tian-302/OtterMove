import Foundation
import Combine

@MainActor
final class MoodStore: ObservableObject {
    @Published private(set) var history: [String: MoodRecord] = [:]
    private let defaults: UserDefaults
    private let key = "otter.moods"
    private var readable = true

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        guard let data = defaults.data(forKey: key) else { return }
        do {
            history = try JSONDecoder().decode([String: MoodRecord].self, from: data)
        } catch {
            readable = false
        }
    }

    func record(for day: Date) -> MoodRecord? { history[AppStore.dayKey(day)] }

    func save(_ mood: MoodType, summary: String, date: Date) -> Bool {
        guard readable else { return false }
        let day = AppStore.dayKey(date)
        var updated = history
        updated[day] = MoodRecord(id: updated[day]?.id ?? UUID(), date: date, mood: mood, summary: summary)
        guard let data = try? JSONEncoder().encode(updated) else { return false }
        defaults.set(data, forKey: key)
        history = updated
        return true
    }
}
