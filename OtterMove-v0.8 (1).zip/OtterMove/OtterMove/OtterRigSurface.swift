import SceneKit
import SwiftUI
import UIKit
import simd

struct OtterRigSurface: UIViewRepresentable {
    let pose: OtterPose
    let animated: Bool

    final class Coordinator {
        let rig = PlushOtterRig()
        weak var camera: SCNNode?
        var lastAspect: CGFloat = 0
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> SCNView {
        let view = SCNView(frame: .zero)
        view.backgroundColor = .clear
        view.isOpaque = false
        view.isUserInteractionEnabled = false
        view.antialiasingMode = .multisampling4X
        view.preferredFramesPerSecond = 30
        view.rendersContinuously = false

        let scene = SCNScene()
        scene.background.contents = UIColor.clear
        scene.rootNode.addChildNode(context.coordinator.rig.model)

        let camera = SCNNode()
        let lens = SCNCamera()
        lens.usesOrthographicProjection = true
        lens.orthographicScale = 3.35
        lens.zNear = 0.2
        lens.zFar = 30
        camera.camera = lens
        camera.position = SCNVector3(0, 1.94, 8.5)
        scene.rootNode.addChildNode(camera)
        camera.look(at: SCNVector3(0, 1.48, 0))

        let key = Self.light(.directional, intensity: 780, color: UIColor(red: 1, green: 0.94, blue: 0.86, alpha: 1))
        key.eulerAngles = SCNVector3(-0.65, -0.38, 0)
        let fill = Self.light(.ambient, intensity: 730, color: UIColor(red: 0.92, green: 0.96, blue: 1, alpha: 1))
        let rim = Self.light(.directional, intensity: 280, color: .white)
        rim.eulerAngles = SCNVector3(-0.43, 2.4, 0)
        for light in [key, fill, rim] { scene.rootNode.addChildNode(light) }

        view.scene = scene
        view.pointOfView = camera
        view.isPlaying = true
        context.coordinator.camera = camera

        context.coordinator.rig.apply(pose)
        return view
    }

    func updateUIView(_ view: SCNView, context: Context) {
        // Camera, chair and scene stay in place while the practice clock drives joints.
        context.coordinator.rig.apply(pose)
        view.isPlaying = animated
        if view.bounds.height > 1 {
            let aspect = view.bounds.width / view.bounds.height
            if abs(aspect - context.coordinator.lastAspect) > 0.01 {
                context.coordinator.camera?.camera?.orthographicScale = Double(max(3.35, 1.85 / max(0.1, aspect)))
                context.coordinator.lastAspect = aspect
            }
        }
    }

    private static func light(_ type: SCNLight.LightType, intensity: CGFloat, color: UIColor) -> SCNNode {
        let node = SCNNode()
        let light = SCNLight()
        light.type = type
        light.intensity = intensity
        light.color = color
        node.light = light
        return node
    }
}

final class PlushOtterRig {
    let model = SCNNode()
    private let root = SCNNode()
    private let torso = SCNNode()
    private let head = SCNNode()
    private let tail = SCNNode()
    private let left = ArmRig()
    private let right = ArmRig()
    private let leftLeg = LegRig()
    private let rightLeg = LegRig()
    private let chair = SCNNode()
    private let openEyes = SCNNode()
    private let closedEyes = SCNNode()
    private let smileEyes = SCNNode()
    private let sleepyEyes = SCNNode()
    private let focusedBrows = SCNNode()
    private let worriedBrows = SCNNode()
    private var eyes: [SCNNode] = []
    private var mouths: [OtterMouth: SCNNode] = [:]

    private let fur = RigMesh.material(UIColor(red: 0.96, green: 0.91, blue: 0.84, alpha: 1), fur: true)
    private let cream = RigMesh.material(UIColor(red: 1.0, green: 0.94, blue: 0.86, alpha: 1), fur: true)
    private let warmFur = RigMesh.material(UIColor(red: 0.87, green: 0.79, blue: 0.68, alpha: 1), fur: true)
    private let innerEar = RigMesh.material(UIColor(red: 0.71, green: 0.54, blue: 0.41, alpha: 1), fur: true)
    private let dark = RigMesh.material(UIColor(red: 0.16, green: 0.10, blue: 0.075, alpha: 1), roughness: 0.40)
    private let nose = RigMesh.material(UIColor(red: 0.42, green: 0.27, blue: 0.19, alpha: 1), roughness: 0.56)
    private let whisker = RigMesh.material(UIColor(red: 0.48, green: 0.37, blue: 0.27, alpha: 1))
    private let catchlight = RigMesh.material(.white, roughness: 0.5)
    private let mouthInterior = RigMesh.material(UIColor(red: 0.27, green: 0.13, blue: 0.10, alpha: 1))
    private let tongue = RigMesh.material(UIColor(red: 0.75, green: 0.38, blue: 0.33, alpha: 1))

    init() {
        model.addChildNode(chair)
        model.addChildNode(root)
        root.addChildNode(torso)
        torso.position = SCNVector3(0, 1.05, 0)
        let shadow = SCNNode(geometry: SCNPlane(width: 2.15, height: 1.05))
        shadow.geometry?.firstMaterial = RigMesh.contactShadow
        shadow.eulerAngles.x = -.pi / 2
        shadow.position = SCNVector3(0, -0.02, 0.08)
        model.addChildNode(shadow)

        RigMesh.body(torso, material: fur, profile: [
            (-0.76, 0.006, 0.010, 0.025), (-0.70, 0.230, 0.200, 0.020),
            (-0.60, 0.355, 0.305, 0.014), (-0.38, 0.431, 0.366, 0.010),
            (-0.12, 0.447, 0.388, 0.006), (0.15, 0.414, 0.372, 0.001),
            (0.39, 0.362, 0.322, 0), (0.59, 0.312, 0.272, 0),
            (0.76, 0.267, 0.238, 0.012), (0.89, 0.203, 0.193, 0.024),
            (1.00, 0.010, 0.010, 0.027)
        ])

        torso.addChildNode(head)
        head.position = SCNVector3(0, 0.757, 0)
        buildHead()
        torso.addChildNode(tail)
        tail.position = SCNVector3(0, -0.350, -0.21)
        RigMesh.shell(tail, f: warmFur, points: [
            (0, 0, 0, 0.165), (-0.13, -0.11, -0.18, 0.155),
            (-0.31, -0.29, -0.27, 0.135), (-0.51, -0.40, -0.33, 0.116),
            (-0.72, -0.42, -0.38, 0.098), (-0.89, -0.34, -0.40, 0.066),
            (-0.98, -0.25, -0.40, 0.012)
        ], sides: 18)

        attachArm(left, side: -1)
        attachArm(right, side: 1)
        attachLeg(leftLeg, side: -1)
        attachLeg(rightLeg, side: 1)
        buildChair()
    }

    func apply(_ p: OtterPose) {
        SCNTransaction.begin()
        SCNTransaction.disableActions = true
        root.position = SCNVector3(Float(p.rootX), Float(p.rootY), 0)
        root.eulerAngles.y = Float(p.rootYaw)
        torso.eulerAngles = vector(p.body)
        head.eulerAngles = vector(p.head)
        tail.eulerAngles = vector(p.tail)
        chair.isHidden = !p.seated
        moveArm(left, p.left, side: -1)
        moveArm(right, p.right, side: 1)
        moveLeg(leftLeg, p.leftLeg)
        moveLeg(rightLeg, p.rightLeg)
        expression(p)
        SCNTransaction.commit()
    }

    private func buildHead() {
        RigMesh.body(head, material: fur, profile: [
            (-0.074, 0.006, 0.008, 0.029), (0.018, 0.229, 0.246, 0.031),
            (0.13, 0.403, 0.372, 0.029), (0.26, 0.514, 0.442, 0.027),
            (0.38, 0.557, 0.478, 0.018), (0.51, 0.548, 0.457, 0.011),
            (0.65, 0.480, 0.390, 0.002), (0.76, 0.358, 0.291, 0),
            (0.835, 0.218, 0.183, 0), (0.88, 0.006, 0.008, 0)
        ])
        head.addChildNode(openEyes)
        for sign: Float in [-1, 1] {
            RigMesh.egg(head, f: warmFur, at: (sign * 0.505, 0.369, -0.010), radius: (0.112,0.129,0.087))
            RigMesh.egg(head, f: innerEar, at: (sign * 0.532, 0.358, 0.057), radius: (0.063,0.077,0.027))
            RigMesh.egg(head, f: cream, at: (sign * 0.092, 0.234, 0.422), radius: (0.158,0.111,0.102))

            let iris = RigMesh.egg(openEyes, f: dark, at: (sign * 0.210,0.424,0.465), radius: (0.054,0.060,0.026))
            iris.eulerAngles.y = sign * 0.21
            eyes.append(iris)
            RigMesh.egg(openEyes, f: catchlight, at: (sign * 0.208 - 0.009,0.445,0.488),
                        radius: (0.014,0.014,0.006))

            for index in 0..<3 {
                let row = Float(index)
                RigMesh.curve(head, f: whisker, radius: 0.0047, from: (sign*0.225,0.261-row*0.047,0.488),
                              control: (sign*(0.39+row*0.026),0.290-row*0.065,0.430),
                              to: (sign*(0.570+row*0.017),0.249-row*0.091,0.298))
            }

            RigMesh.curve(closedEyes, f: dark, radius: 0.0094, from: (sign*0.147,0.407,0.477),
                          control: (sign*0.214,0.436,0.491), to: (sign*0.277,0.415,0.426))
            RigMesh.curve(smileEyes, f: dark, radius: 0.011, from: (sign*0.147,0.411,0.477),
                          control: (sign*0.214,0.485,0.506), to: (sign*0.281,0.424,0.426))
            RigMesh.curve(sleepyEyes, f: dark, radius: 0.010, from: (sign*0.149,0.425,0.478),
                          control: (sign*0.215,0.370,0.490), to: (sign*0.278,0.420,0.426))
            RigMesh.curve(focusedBrows, f: nose, radius: 0.016, from: (sign*0.145,0.467,0.469),
                          control: (sign*0.214,0.506,0.460), to: (sign*0.283,0.515,0.416))
            RigMesh.curve(worriedBrows, f: nose, radius: 0.010, from: (sign*0.145,0.527,0.466),
                          control: (sign*0.201,0.528,0.466), to: (sign*0.263,0.503,0.422))
        }
        for group in [closedEyes, smileEyes, sleepyEyes, focusedBrows, worriedBrows] { head.addChildNode(group) }

        RigMesh.egg(head, f: nose, at: (0,0.336,0.518), radius: (0.099,0.056,0.047))
        RigMesh.egg(head, f: nose, at: (0,0.307,0.540), radius: (0.053,0.046,0.025))
        let highlight = RigMesh.egg(head, f: innerEar, at: (-0.031,0.356,0.548), radius: (0.037,0.009,0.009))
        highlight.opacity = 0.47

        for mood in [OtterMouth.gentle, .laugh, .worried, .yawn, .surprised, .focused] {
            let mouth = SCNNode()
            head.addChildNode(mouth)
            mouths[mood] = mouth
            switch mood {
            case .gentle:
                for sign: Float in [-1, 1] {
                    RigMesh.curve(mouth, f: nose, radius: 0.0066, from: (0,0.262,0.531),
                                  control: (sign*0.051,0.204,0.526), to: (sign*0.102,0.243,0.518))
                }
            case .laugh:
                RigMesh.egg(mouth, f: mouthInterior, at: (0,0.156,0.493), radius: (0.133,0.080,0.021))
                RigMesh.egg(mouth, f: tongue, at: (0,0.119,0.509), radius: (0.071,0.030,0.012))
            case .worried:
                RigMesh.curve(mouth, f: nose, radius: 0.008, from: (-0.069,0.159,0.497),
                              control: (0,0.224,0.522), to: (0.069,0.159,0.497))
            case .yawn:
                RigMesh.egg(mouth, f: mouthInterior, at: (0,0.152,0.493), radius: (0.091,0.100,0.027))
                RigMesh.egg(mouth, f: tongue, at: (0,0.098,0.508), radius: (0.053,0.035,0.015))
            case .surprised:
                RigMesh.egg(mouth, f: mouthInterior, at: (0,0.166,0.508), radius: (0.042,0.061,0.018))
            case .focused:
                RigMesh.curve(mouth, f: nose, radius: 0.008, from: (-0.078,0.187,0.510),
                              control: (0,0.174,0.522), to: (0.078,0.187,0.510))
            }
        }
    }

    private func attachArm(_ arm: ArmRig, side: Float) {
        torso.addChildNode(arm.shoulder)
        arm.shoulder.position = SCNVector3(side * 0.325, 0.535, 0.02)
        arm.shoulder.addChildNode(arm.skin)
        arm.shoulder.addChildNode(arm.elbow)
        arm.elbow.position.y = -0.304
        arm.elbow.addChildNode(arm.wrist)
        arm.wrist.position.y = -0.231
        for j in 0..<4 {
            let digit = SCNNode()
            digit.position = SCNVector3((Float(j) - 1.5) * 0.043, -0.118, 0.017)
            RigMesh.egg(digit, f: cream, at: (0,-0.026,0.001),
                        radius: (0.030,0.058-(Float(abs(j-1))*0.007),0.036))
            arm.wrist.addChildNode(digit)
            arm.fingers.append(digit)
        }
        RigMesh.egg(arm.wrist, f: cream, at: (-side*0.09,-0.061,0.021), radius: (0.057,0.065,0.054))
    }

    private func attachLeg(_ leg: LegRig, side: Float) {
        root.addChildNode(leg.hip)
        leg.hip.position = SCNVector3(side * 0.192,Float(OtterPose.hipHeight),0)
        leg.hip.addChildNode(leg.skin)
        leg.hip.addChildNode(leg.knee)
        leg.knee.position.y = -Float(OtterPose.thigh)
        leg.knee.addChildNode(leg.ankle)
        leg.ankle.position.y = -Float(OtterPose.shin)
        RigMesh.egg(leg.ankle, f: cream, at: (0,-0.019,0.084), radius: (0.155,0.099,0.206))
    }

    private func buildChair() {
        let cushion = RigMesh.material(UIColor(red: 0.87, green: 0.77, blue: 0.64, alpha: 1))
        let wood = RigMesh.material(UIColor(red: 0.67, green: 0.47, blue: 0.30, alpha: 1))
        RigMesh.egg(chair, f: cushion, at: (0,0.841,-0.053), radius: (0.558,0.109,0.468))
        let backrest = RigMesh.egg(chair, f: cushion, at: (0,1.202,-0.461), radius: (0.554,0.478,0.136))
        backrest.eulerAngles.x = -0.12
        for x: Float in [-0.38,0.38] {
            for z: Float in [-0.32,0.19] {
                let leg = RigMesh.egg(chair, f: wood, at: (x,0.396,z), radius: (0.065,0.427,0.070))
                leg.eulerAngles.z = x < 0 ? -0.11 : 0.11
            }
        }
    }

    private func moveArm(_ rig: ArmRig, _ p: OtterArmPose, side: Float) {
        rig.shoulder.position = SCNVector3(side * 0.325, 0.535 + Float(p.lift), 0.02 + Float(p.reach))
        rig.shoulder.eulerAngles = vector(p.shoulder)
        rig.elbow.eulerAngles.x = Float(p.elbow)
        rig.wrist.eulerAngles.x = Float(p.wrist)
        for (index, digit) in rig.fingers.enumerated() {
            digit.eulerAngles.x = Float(-1.23 * p.curl)
            digit.eulerAngles.z = (Float(index) - 1.5) * -0.13 * Float(1 - p.curl)
        }

        let angles = SIMD2<Float>(Float(p.elbow), Float(p.wrist))
        guard changed(from: rig.lastAngles, to: angles) else { return }
        rig.lastAngles = angles
        let elbow = SIMD3<Float>(0, -0.304, 0)
        let wrist = elbow + turnX(SIMD3<Float>(0, -0.231, 0), angles.x)
        let palmAngle = angles.x + angles.y
        let segments = [
            SIMD4<Float>(0,0.12,0,0.007), SIMD4<Float>(0,0.067,0,0.113),
            SIMD4<Float>(0,-0.033,0,0.155), SIMD4<Float>(0,-0.169,0,0.146),
            ring(elbow, radius: 0.123),
            ring(elbow + turnX(SIMD3<Float>(0,-0.107,0.004), angles.x), radius: 0.111),
            ring(wrist, radius: 0.107),
            ring(wrist + turnX(SIMD3<Float>(0,-0.067,0.012), palmAngle), radius: 0.105),
            ring(wrist + turnX(SIMD3<Float>(0,-0.122,0.018), palmAngle), radius: 0.077),
            ring(wrist + turnX(SIMD3<Float>(0,-0.155,0.018), palmAngle), radius: 0.006)
        ]
        rig.skin.geometry = RigMesh.taper(segments, material: fur)
    }

    private func moveLeg(_ rig: LegRig, _ p: OtterLegPose) {
        rig.hip.eulerAngles.x = Float(p.hip)
        rig.knee.eulerAngles.x = Float(p.knee)
        rig.ankle.eulerAngles.x = Float(p.ankle)
        let angle = Float(p.knee)
        guard abs(rig.lastKnee - angle) > 0.012 else { return }
        rig.lastKnee = angle
        let kneePosition = SIMD3<Float>(0, -Float(OtterPose.thigh), 0)
        let ankle = kneePosition + turnX(SIMD3<Float>(0,-Float(OtterPose.shin),0), angle)
        let segments = [
            SIMD4<Float>(0,0.10,0,0.017), SIMD4<Float>(0,0.045,0,0.132),
            SIMD4<Float>(0,-0.07,0,0.181), SIMD4<Float>(0,-0.199,0,0.151),
            ring(kneePosition, radius: 0.132),
            ring(kneePosition + turnX(SIMD3<Float>(0,-0.12,0), angle), radius: 0.110),
            ring(ankle, radius: 0.096),
            ring(ankle + turnX(SIMD3<Float>(0,-0.027,0), angle), radius: 0.032)
        ]
        rig.skin.geometry = RigMesh.taper(segments, material: fur)
    }

    private func ring(_ p: SIMD3<Float>, radius: Float) -> SIMD4<Float> {
        SIMD4<Float>(p.x,p.y,p.z,radius)
    }

    private func turnX(_ p: SIMD3<Float>, _ angle: Float) -> SIMD3<Float> {
        let cosA = cos(angle), sinA = sin(angle)
        return SIMD3(p.x, p.y * cosA - p.z * sinA, p.y * sinA + p.z * cosA)
    }

    private func changed(from a: SIMD2<Float>, to b: SIMD2<Float>) -> Bool {
        max(abs(a.x-b.x),abs(a.y-b.y)) > 0.012
    }

    private func expression(_ pose: OtterPose) {
        let closed = pose.eyes == .relaxed || pose.blinking
        let smiling = pose.eyes == .smiling && !pose.blinking
        let tired = pose.eyes == .sleepy && !pose.blinking
        openEyes.isHidden = closed || smiling || tired
        closedEyes.isHidden = !closed
        smileEyes.isHidden = !smiling
        sleepyEyes.isHidden = !tired
        focusedBrows.isHidden = pose.eyes != .focused
        worriedBrows.isHidden = pose.eyes != .worried
        let irisY: Float = pose.eyes == .focused ? 0.042 : pose.eyes == .wide ? 0.074 : 0.060
        let irisX: Float = pose.eyes == .wide || pose.eyes == .worried ? 0.062 : 0.054
        for eye in eyes { eye.scale = SCNVector3(irisX * 2, irisY * 2, 0.052) }
        for (mouth, node) in mouths { node.isHidden = mouth != pose.mouth }
    }

    private func vector(_ angles: JointAngles) -> SCNVector3 {
        SCNVector3(Float(angles.x), Float(angles.y), Float(angles.z))
    }

    private final class ArmRig {
        let shoulder = SCNNode()
        let skin = SCNNode()
        var lastAngles = SIMD2<Float>(999,999)
        let elbow = SCNNode()
        let wrist = SCNNode()
        var fingers: [SCNNode] = []
    }

    private final class LegRig {
        let hip = SCNNode()
        let skin = SCNNode()
        var lastKnee: Float = 999
        let knee = SCNNode()
        let ankle = SCNNode()
    }
}

private enum RigMesh {
    typealias Triple = (Float, Float, Float)
    typealias Ring = (Float, Float, Float, Float)

    static func material(_ color: UIColor, fur: Bool = false, roughness: CGFloat = 0.95) -> SCNMaterial {
        let mat = SCNMaterial()
        mat.lightingModel = .blinn
        mat.diffuse.contents = color
        mat.specular.contents = UIColor(white: 0.18, alpha: 1)
        mat.shininess = roughness < 0.6 ? 0.42 : 0.10
        if fur {
            mat.normal.contents = furNormal
            mat.normal.intensity = 0.31
            mat.normal.wrapS = .repeat
            mat.normal.wrapT = .repeat
        }
        return mat
    }

    private static let unitSphere: SCNSphere = {
        let sphere = SCNSphere(radius: 0.5)
        sphere.segmentCount = 36
        return sphere
    }()

    @discardableResult
    static func egg(_ parent: SCNNode, f material: SCNMaterial, at p: Triple, radius: Triple) -> SCNNode {
        let shape = (unitSphere.copy() as? SCNSphere) ?? SCNSphere(radius: 0.5)
        shape.firstMaterial = material
        let node = SCNNode(geometry: shape)
        node.scale = SCNVector3(radius.0 * 2,radius.1 * 2,radius.2 * 2)
        node.position = SCNVector3(p.0,p.1,p.2)
        parent.addChildNode(node)
        return node
    }

    static func curve(_ parent: SCNNode, f material: SCNMaterial, radius: Float, from: Triple,
                      control: Triple, to: Triple) {
        let segments = (0...8).map { j -> Ring in
            let t = Float(j) / 8
            let u = 1 - t
            let a = u * u, b = 2 * t * u, c = t * t
            let x = a * from.0 + b * control.0 + c * to.0
            let y = a * from.1 + b * control.1 + c * to.1
            let z = a * from.2 + b * control.2 + c * to.2
            return (x, y, z, radius * (1 - 0.71 * t))
        }
        shell(parent, f: material, points: segments, sides: 7)
    }

    static func shell(_ parent: SCNNode, f material: SCNMaterial, points: [Ring], sides: Int) {
        let profile = points.map { SIMD4<Float>($0.0,$0.1,$0.2,$0.3) }
        let geometry = tube(smooth(profile, steps: sides > 7 ? 4 : 1),
                            sides: sides, material: material)
        parent.addChildNode(SCNNode(geometry: geometry))
    }

    static func taper(_ profile: [SIMD4<Float>], material: SCNMaterial) -> SCNGeometry {
        tube(smooth(profile, steps: 3), sides: 18, material: material)
    }

    /// Body and face use continuous elliptical profiles for a soft silhouette.
    static func body(_ parent: SCNNode, material: SCNMaterial, profile: [Ring]) {
        let points = smooth(profile.map { SIMD4<Float>($0.0,$0.1,$0.2,$0.3) }, steps: 4)
        let sides = 56
        var rings: [[SIMD3<Float>]] = []
        for point in points {
            var contour: [SIMD3<Float>] = []
            for column in 0...sides {
                let angle = Float(column) / Float(sides) * 2 * .pi
                contour.append(SIMD3(max(0.002,point.y) * cos(angle), point.x,
                                    point.w + max(0.002,point.z) * sin(angle)))
            }
            rings.append(contour)
        }
        parent.addChildNode(SCNNode(geometry: mesh(rings, material: material, reversed: true)))
    }

    private static func tube(_ profile: [SIMD4<Float>], sides: Int, material: SCNMaterial) -> SCNGeometry {
        let centers = profile.map { SIMD3<Float>($0.x,$0.y,$0.z) }
        var rings: [[SIMD3<Float>]] = []
        var previousNormal: SIMD3<Float>?
        for i in profile.indices {
            let motion = centers[min(profile.count-1,i+1)] - centers[max(0,i-1)]
            let tangent = simd_normalize(motion)
            let reference: SIMD3<Float> = abs(tangent.z) > 0.85 ? SIMD3(1,0,0) : SIMD3(0,0,1)
            let normal: SIMD3<Float>
            if let old = previousNormal {
                let projected = old - tangent * simd_dot(old, tangent)
                normal = simd_length_squared(projected) > 0.0001
                    ? simd_normalize(projected) : simd_normalize(simd_cross(tangent, reference))
            } else {
                normal = simd_normalize(simd_cross(tangent, reference))
            }
            previousNormal = normal
            let bridge = simd_cross(tangent, normal)
            let radius = max(0.001,profile[i].w)
            let contour = (0...sides).map { column -> SIMD3<Float> in
                let angle = Float(column) / Float(sides) * 2 * .pi
                return centers[i] + radius * (normal * cos(angle) + bridge * sin(angle))
            }
            rings.append(contour)
        }
        return mesh(rings, material: material, reversed: false)
    }

    private static func mesh(_ rings: [[SIMD3<Float>]], material: SCNMaterial, reversed: Bool) -> SCNGeometry {
        let sides = rings[0].count - 1
        var vertices: [SCNVector3] = []
        var normals: [SCNVector3] = []
        var uv: [CGPoint] = []
        var indices: [UInt32] = []
        for row in rings.indices {
            let previous = max(0, row-1), next = min(rings.count-1, row+1)
            for column in 0...sides {
                let p = rings[row][column]
                let side = column % sides
                let alongRing = rings[row][(side+1)%sides] - rings[row][(side+sides-1)%sides]
                let alongLength = rings[next][column] - rings[previous][column]
                let raw = simd_cross(alongRing,alongLength)
                let n = simd_normalize(reversed ? -raw : raw)
                vertices.append(SCNVector3(p.x,p.y,p.z))
                normals.append(SCNVector3(n.x,n.y,n.z))
                uv.append(CGPoint(x: CGFloat(column)/CGFloat(sides),y: CGFloat(row)/CGFloat(rings.count-1)))
            }
        }
        for row in 0..<(rings.count-1) {
            for column in 0..<sides {
                let a = UInt32(row*(sides+1)+column), b = a + UInt32(sides+1)
                if reversed { indices += [a,b,a+1,a+1,b,b+1] }
                else { indices += [a,a+1,b,a+1,b+1,b] }
            }
        }
        let element = SCNGeometryElement(indices: indices, primitiveType: .triangles)
        let shape = SCNGeometry(sources: [SCNGeometrySource(vertices: vertices), SCNGeometrySource(normals: normals),
                                          SCNGeometrySource(textureCoordinates: uv)], elements: [element])
        shape.firstMaterial = material
        return shape
    }

    private static func smooth(_ points: [SIMD4<Float>], steps: Int) -> [SIMD4<Float>] {
        guard steps > 1 else { return points }
        var profile: [SIMD4<Float>] = []
        for i in 0..<(points.count-1) {
            let a = points[max(0,i-1)], b = points[i], c = points[i+1], d = points[min(points.count-1,i+2)]
            let f = (c - a) * Float(0.5)
            let g = (a - b * Float(2.5)) + (c * Float(2) - d * Float(0.5))
            let h = (d - a) * Float(0.5) + (b - c) * Float(1.5)
            for step in 0..<steps {
                let t = Float(step) / Float(steps)
                let quadratic = g + h * t
                let slope = f + quadratic * t
                profile.append(b + slope * t)
            }
        }
        profile.append(points[points.count-1])
        return profile
    }

    private static let furNormal: UIImage = {
        var bytes = [UInt8](repeating: 255, count: 96 * 96 * 4)
        var seed: UInt32 = 4609
        for i in stride(from: 0, to: bytes.count, by: 4) {
            seed = 1664525 &* seed &+ 1013904223
            bytes[i] = UInt8(107 + ((seed >> 20) % 43))
            bytes[i + 1] = UInt8(105 + ((seed >> 13) % 46))
            bytes[i + 2] = 251
        }
        let data = Data(bytes) as CFData
        let info = CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipLast.rawValue)
        if let provider = CGDataProvider(data: data),
           let image = CGImage(width: 96,height: 96,bitsPerComponent: 8,bitsPerPixel: 32,bytesPerRow: 384,
                               space: CGColorSpaceCreateDeviceRGB(),bitmapInfo: info,provider: provider,
                               decode: nil,shouldInterpolate: true,intent: .defaultIntent) {
            return UIImage(cgImage: image)
        }
        return UIImage()
    }()

    static let contactShadow: SCNMaterial = {
        let size = CGSize(width: 192, height: 96)
        let image = UIGraphicsImageRenderer(size: size).image { context in
            guard let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                            colors: [UIColor(white: 0.18, alpha: 0.22).cgColor,
                                                     UIColor.clear.cgColor] as CFArray,
                                            locations: [0, 1]) else { return }
            let cg = context.cgContext
            cg.translateBy(x: 96,y: 48)
            cg.scaleBy(x: 2,y: 1)
            cg.drawRadialGradient(gradient, startCenter: .zero, startRadius: 3,
                                  endCenter: .zero, endRadius: 47, options: [])
        }
        let material = SCNMaterial()
        material.lightingModel = .constant
        material.diffuse.contents = image
        material.writesToDepthBuffer = false
        return material
    }()
}
