import SwiftUI

struct StateSelectionView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let next: () -> Void
    @State private var place = Place.library
    @State private var energy = Energy.low

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 11) {
                    Text("现在，给自己一点空隙")
                        .font(WellnessPalette.font(.title2, weight: .bold))
                        .multilineTextAlignment(.center)
                        .padding(.top, 7)
                        .accessibilityAddTraits(.isHeader)
                    OtterArtworkImage(name: stateArt)
                        .frame(height: max(235, geometry.size.height - 365))
                        .frame(maxWidth: 490)
                        .id(stateArt)
                        .transition(.opacity)

                    selectionRow("你在哪里") {
                        ForEach([Place.library, .dorm, .outdoor]) { item in
                            stateCard(item.rawValue, art: OtterArtwork.place(item),
                                      phase: Double(Place.allCases.firstIndex(of: item) ?? 0),
                                      selected: place == item) { place = item }
                        }
                    }
                    selectionRow("还有多少电量") {
                        ForEach(Energy.allCases) { item in
                            stateCard(item.rawValue,
                                      art: item == .low ? OtterArtwork.mood(.tired) : "otter4_mood_excited",
                                      phase: item == .low ? 0.4 : 1.8,
                                      selected: energy == item) { energy = item }
                        }
                    }
                    PrimaryButton(title: "去选一个动作") {
                        if store.setState(place: place, energy: energy) { next() }
                    }
                    .padding(.top, 3)
                }
                .padding(.horizontal, 22)
                .padding(.bottom, 20)
                .frame(maxWidth: 570)
                .frame(maxWidth: .infinity, minHeight: geometry.size.height, alignment: .top)
            }
            .scrollIndicators(.hidden)
        }
        .foregroundStyle(Palette.ink)
        .background(ExerciseStyle.cool.ignoresSafeArea())
        .onAppear { place = store.profile.place; energy = store.profile.energy }
    }

    private var stateArt: String {
        if energy == .low && place == .library {
            return OtterArtwork.activity(.careStretch)
        }
        return OtterArtwork.place(place)
    }

    private func selectionRow<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.subheadline.weight(.semibold))
            HStack(spacing: 8, content: content)
        }
        .frame(maxWidth: .infinity)
    }

    private func stateCard(_ title: String, art: String, phase: Double, selected: Bool,
                           action: @escaping () -> Void) -> some View {
        Button {
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2), action)
        } label: {
            VStack(spacing: 3) {
                OtterMovingThumbnail(name: art, phase: phase)
                    .frame(height: 46)
                Text(title)
                    .font(.caption.weight(.semibold))
                    .multilineTextAlignment(.center)
            }
            .padding(6)
            .frame(maxWidth: .infinity, minHeight: 72)
            .background(selected ? Color.white.opacity(0.96) : Color.white.opacity(0.54),
                        in: RoundedRectangle(cornerRadius: 16))
            .overlay {
                RoundedRectangle(cornerRadius: 16)
                    .strokeBorder(selected ? Palette.ink : Color.white.opacity(0.42), lineWidth: selected ? 1.5 : 1)
            }
            .overlay(alignment: .topTrailing) {
                if selected {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.caption.weight(.bold))
                        .padding(6)
                }
            }
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}

enum ExerciseStyle {
    static let cool = LinearGradient(
        colors: [Color(red: 0.95, green: 0.98, blue: 1),
                 Color(red: 0.80, green: 0.90, blue: 0.98),
                 Color(red: 0.87, green: 0.94, blue: 0.99)],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
    static let warm = LinearGradient(
        colors: [Color(red: 0.99, green: 0.97, blue: 0.94),
                 Color(red: 0.96, green: 0.92, blue: 0.88),
                 Color(red: 1, green: 0.98, blue: 0.95)],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )

    static func stage(for activity: Activity) -> LinearGradient {
        let cooler = activity.place == .library ? activity.order != 1 && activity.order >= 0 : activity.order == 1
        return cooler ? cool : warm
    }
}

struct ExerciseSelectionView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let openRoom: () -> Void
    let changeState: () -> Void
    @State private var selectedID: String?
    @State private var session: Activity?
    @State private var pendingSession: Activity?

    private var activities: [Activity] { Activity.list(for: store.profile.place) }
    private var selected: Activity { activities.first { $0.id == selectedID } ?? activities[0] }
    private var selectedIndex: Int { activities.firstIndex(of: selected) ?? 0 }
    private var unlocked: Bool { store.isUnlocked(selected) }
    private var requiredAction: Activity? { activities.first { $0.order == selected.order - 1 } }

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 8) {
                    sceneHeader
                    OtterTechniqueStage(activity: selected)
                        .id(selected.id)
                        .transition(.opacity)
                        .frame(height: max(235, geometry.size.height - 324))
                        .frame(maxWidth: 520)
                        .contentShape(Rectangle())
                        .simultaneousGesture(swipeActions)
                    Text(selected.cue)
                        .font(.subheadline.weight(.medium))
                        .multilineTextAlignment(.center)
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(minHeight: 36)
                        .padding(.horizontal, 18)
                    actionStrip
                        .simultaneousGesture(swipeActions)
                    if unlocked {
                        PrimaryButton(title: "开始") { session = selected }
                            .accessibilityHint("开始\(selected.durationText)计时")
                    } else {
                        Label("完成「\(requiredAction?.title ?? "上一个动作")」后解锁", systemImage: "lock")
                            .font(.subheadline.weight(.semibold))
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity, minHeight: 52)
                            .background(Palette.ink.opacity(0.10), in: Capsule())
                    }
                }
                .padding(.horizontal, 18)
                .padding(.top, 5)
                .padding(.bottom, 14)
                .frame(maxWidth: 590)
                .frame(maxWidth: .infinity, minHeight: geometry.size.height, alignment: .top)
            }
            .scrollIndicators(.hidden)
        }
        .foregroundStyle(Palette.ink)
        .background(ExerciseStyle.stage(for: selected).ignoresSafeArea())
        .onAppear {
            if selectedID == nil {
                selectedID = store.recommendedID(for: store.profile.place, energy: store.profile.energy)
            }
        }
        .fullScreenCover(item: $session, onDismiss: {
            if let pending = pendingSession {
                pendingSession = nil
                selectedID = pending.id
                session = pending
            }
        }) { activity in
            ExerciseView(activity: activity, openRoom: {
                session = nil
                openRoom()
            }, chooseNext: { next in
                pendingSession = next
                session = nil
            })
            .environmentObject(store)
        }
    }

    private var sceneHeader: some View {
        VStack(spacing: 4) {
            Button(action: changeState) {
                HStack(spacing: 10) {
                    Rectangle().fill(Palette.ink.opacity(0.22)).frame(width: 36, height: 1)
                    Text("\(store.profile.place.rawValue) · \(store.profile.energy.rawValue)")
                        .font(.caption.weight(.semibold))
                    Image(systemName: "chevron.down").font(.system(size: 9, weight: .semibold))
                    Rectangle().fill(Palette.ink.opacity(0.22)).frame(width: 36, height: 1)
                }
                .frame(minHeight: 40)
            }
            .buttonStyle(.plain)
            .accessibilityHint("修改场景和电量")
            Text(selected.title)
                .font(WellnessPalette.font(.title, weight: .bold))
                .multilineTextAlignment(.center)
                .accessibilityAddTraits(.isHeader)
            Text(selected.durationText)
                .font(.subheadline.weight(.semibold))
                .monospacedDigit()
        }
    }

    private var actionStrip: some View {
        HStack(spacing: 6) {
            arrow(-1)
            ForEach(activities) { activity in
                actionCard(activity)
            }
            arrow(1)
        }
    }

    private var swipeActions: some Gesture {
        DragGesture(minimumDistance: 22).onEnded { value in
            let dx = value.translation.width
            guard abs(dx) > max(26, abs(value.translation.height) * 1.5) else { return }
            shift(dx < 0 ? 1 : -1)
        }
    }

    private func arrow(_ direction: Int) -> some View {
        let canShift = activities.indices.contains(selectedIndex + direction)
        return Button { shift(direction) } label: {
            Image(systemName: direction < 0 ? "chevron.left" : "chevron.right")
                .font(.system(size: 14, weight: .semibold))
                .frame(width: 22, height: 50)
                .opacity(canShift ? 1 : 0.28)
        }
        .buttonStyle(.plain)
        .disabled(!canShift)
        .accessibilityLabel(direction < 0 ? "上一个动作" : "下一个动作")
    }

    private func actionCard(_ activity: Activity) -> some View {
        let chosen = selected.id == activity.id
        let available = store.isUnlocked(activity)
        return Button { select(activity) } label: {
            VStack(spacing: 3) {
                OtterArtworkImage(name: OtterArtwork.activity(activity))
                    .frame(height: 56)
                Text(activity.title)
                    .font(.caption2.weight(.semibold))
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(5)
            .frame(maxWidth: .infinity, minHeight: 88)
            .background(.white.opacity(chosen ? 0.90 : 0.65), in: RoundedRectangle(cornerRadius: 13))
            .overlay {
                RoundedRectangle(cornerRadius: 13)
                    .strokeBorder(chosen ? Palette.ink : Palette.ink.opacity(0.08), lineWidth: chosen ? 1.8 : 1)
            }
            .overlay(alignment: .topTrailing) {
                if chosen {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 14, weight: .semibold))
                        .padding(6)
                } else if !available {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(Palette.ink.opacity(0.62))
                        .padding(6)
                }
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(activity.title + (available ? "" : "，待解锁"))
        .accessibilityAddTraits(chosen ? .isSelected : [])
    }

    private func select(_ activity: Activity) {
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.24)) { selectedID = activity.id }
    }

    private func shift(_ direction: Int) {
        let target = selectedIndex + direction
        if activities.indices.contains(target) { select(activities[target]) }
    }
}

struct OtterTechniqueStage: View {
    let activity: Activity

    private var hasEmptyChair: Bool {
        activity.place == .dorm && (activity.motion == "stand" || activity.motion == "walk")
    }

    var body: some View {
        VStack(spacing: 3) {
            GeometryReader { geometry in
                let side = min(geometry.size.width, geometry.size.height / 1.04)
                illustration(side: side)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            if activity.motion == "paws" { pawGuide }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(activity.title)的水獭动作示范。\(activity.cue)")
    }

    private func illustration(side: CGFloat) -> some View {
        let center = side * (hasEmptyChair ? 0.58 : 0.5)
        return ZStack {
            Ellipse()
                .fill(Palette.ink.opacity(0.11))
                .frame(width: side * 0.68, height: side * 0.085)
                .blur(radius: 9)
                .position(x: side * 0.50, y: side * 0.968)
            if activity.motion == "look" {
                Image(systemName: "rectangle.split.2x2")
                    .font(.system(size: side * 0.17, weight: .light))
                    .rotationEffect(.degrees(-8))
                    .foregroundStyle(Palette.blue.opacity(0.53))
                    .position(x: side * 0.88, y: side * 0.235)
            }
            if hasEmptyChair {
                Image("otter6_chair")
                    .resizable()
                    .interpolation(.high)
                    .scaledToFit()
                    .frame(width: side * 0.37, height: side * 0.47)
                    .position(x: side * 0.245, y: side * 0.67)
            }
            if activity.motion == "walk" { footprints(side: side) }

            OtterArtworkImage(name: OtterArtwork.activity(activity))
                .frame(width: side * 0.77, height: side * 0.93)
                .position(x: center, y: side * 0.52)
            directionalCue(side: side)
        }
        .frame(width: side, height: side * 1.04)
    }

    @ViewBuilder
    private func directionalCue(side: CGFloat) -> some View {
        switch activity.motion {
        case "stretch":
            pairedArrows("arrow.up", side: side, width: 0.70, height: 0.43)
        case "shrug":
            pairedArrows("arrow.up.and.down", side: side, width: 0.64, height: 0.41)
        case "circle":
            pairedArrows("arrow.clockwise", side: side, width: 0.67, height: 0.44)
        case "stand" where hasEmptyChair:
            Image(systemName: "arrow.up")
                .font(.system(size: side * 0.065, weight: .medium))
                .foregroundStyle(Palette.ink.opacity(0.55))
                .position(x: side * 0.22, y: side * 0.40)
        default:
            EmptyView()
        }
    }

    private func pairedArrows(_ symbol: String, side: CGFloat, width: CGFloat, height: CGFloat) -> some View {
        HStack {
            Image(systemName: symbol)
            Spacer()
            Image(systemName: symbol)
        }
        .font(.system(size: side * 0.07, weight: .medium))
        .foregroundStyle(Palette.ink.opacity(0.63))
        .frame(width: side * width)
        .position(x: side * 0.5, y: side * height)
    }

    private func footprints(side: CGFloat) -> some View {
        ForEach(0..<4) { index in
            let step = CGFloat(index)
            let stagger: CGFloat = index.isMultiple(of: 2) ? 0 : 0.016
            Ellipse()
                .fill(Palette.ink.opacity(0.15))
                .frame(width: side * 0.043, height: side * 0.023)
                .rotationEffect(.degrees(25))
                .position(x: side * (0.25 + 0.060 * step),
                          y: side * (0.845 + 0.030 * step + stagger))
        }
    }

    private var pawGuide: some View {
        HStack(spacing: 7) {
            paw("otter6_paw_open")
            Text("张开")
            Image(systemName: "arrow.right")
                .padding(.horizontal, 4)
                .foregroundStyle(Palette.ink.opacity(0.64))
            paw("otter6_paw_closed")
            Text("轻合")
        }
        .font(.caption2.weight(.semibold))
        .foregroundStyle(Palette.ink)
        .padding(.horizontal, 13)
        .padding(.vertical, 3)
        .background(.white.opacity(0.74), in: Capsule())
    }

    private func paw(_ name: String) -> some View {
        Image(name)
            .resizable()
            .interpolation(.high)
            .scaledToFit()
            .frame(width: 32, height: 31)
    }
}
