import Foundation

enum Place: String, CaseIterable, Codable, Identifiable {
    case outdoor = "室外", library = "图书馆", dorm = "宿舍"
    var id: String { rawValue }
}

enum Energy: String, CaseIterable, Codable, Identifiable {
    case low = "低电量", ready = "有余力"
    var id: String { rawValue }
}

struct Activity: Identifiable, Hashable {
    let id: String
    let title: String
    let place: Place
    let seconds: Int
    let cue: String
    let motion: String
    let order: Int

    var durationText: String { "\(seconds) 秒" }
    static let careStretch = Activity(
        id: "care.shoulder", title: "1 分钟肩颈放松", place: .library, seconds: 60,
        cue: "坐稳，轻轻抬起双肩，再慢慢放下。", motion: "shrug", order: -1
    )
    static let all: [Activity] = [
        .init(id: "library.paws", title: "爪爪下班", place: .library, seconds: 20,
              cue: "双手缓慢张开，再轻轻合拢。", motion: "paws", order: 0),
        .init(id: "library.shoulders", title: "肩膀松一松", place: .library, seconds: 20,
              cue: "轻轻抬起双肩，再慢慢放下。", motion: "shrug", order: 1),
        .init(id: "library.look", title: "看看远方", place: .library, seconds: 20,
              cue: "转头看向窗边，让视线停在远处。", motion: "look", order: 2),
        .init(id: "dorm.stand", title: "站成一只獭", place: .dorm, seconds: 30,
              cue: "从椅子上起身，双脚踩稳，双手自然垂下。", motion: "stand", order: 0),
        .init(id: "dorm.stretch", title: "伸个懒腰", place: .dorm, seconds: 20,
              cue: "双脚站稳，双臂慢慢举过头顶。", motion: "stretch", order: 1),
        .init(id: "dorm.walk", title: "小獭散步", place: .dorm, seconds: 60,
              cue: "左右脚交替慢走，双臂自然摆动。", motion: "walk", order: 2),
        .init(id: "outdoor.walk", title: "出门走走", place: .outdoor, seconds: 60,
              cue: "找一段安全平坦的路，慢慢走。", motion: "walk", order: 0),
        .init(id: "outdoor.shoulders", title: "肩膀转一转", place: .outdoor, seconds: 20,
              cue: "站稳，手臂放松，肩膀缓慢向后绕动。", motion: "circle", order: 1),
        .init(id: "outdoor.wind", title: "风里站一会儿", place: .outdoor, seconds: 30,
              cue: "放松双手，感受周围环境。", motion: "wind", order: 2)
    ]
    static func list(for place: Place) -> [Activity] {
        all.filter { $0.place == place }.sorted { $0.order < $1.order }
    }
    static func next(after activity: Activity) -> Activity? {
        guard activity.order >= 0 else { return nil }
        return list(for: activity.place).first { $0.order == activity.order + 1 }
    }
}

struct ActivityRecord: Codable, Identifiable {
    var id: UUID
    var date: Date
    var kind: String
    var activityID: String
    var title: String
    var seconds: Int
    var complete: Bool
}

struct FurniturePlacement: Codable, Equatable, Identifiable {
    var id: String
    var x: Float
    var z: Float
    var turns: Int
    var finish: FurnitureFinish? = nil
    var supportID: String? = nil

    func rotateOffset(_ x: Float, _ z: Float, inverse: Bool = false) -> (x: Float, z: Float) {
        let rotation = inverse ? (4 - turns) % 4 : turns % 4
        switch rotation {
        case 1: return (-z, x)
        case 2: return (-x, -z)
        case 3: return (z, -x)
        default: return (x, z)
        }
    }
}

enum FurnitureFinish: String, Codable, CaseIterable, Identifiable {
    case cream, wood, mistBlue, blush
    var id: Self { self }

    var title: String {
        switch self {
        case .cream: "奶油白"
        case .wood: "浅木色"
        case .mistBlue: "雾霾蓝"
        case .blush: "浅粉色"
        }
    }
}

enum FurnitureSurface: Hashable {
    case floor, rug, windowWall, sideWall, tabletop

    var isWall: Bool { self == .windowWall || self == .sideWall }
}

struct RoomSpace: Codable, Equatable, Identifiable {
    static let limit = 3
    static let legacyID = UUID(uuid: (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1))

    let id: UUID
    var title: String
    var placements: [FurniturePlacement]

    static func cleanTitle(_ title: String) -> String {
        String(title.trimmingCharacters(in: .whitespacesAndNewlines).prefix(18))
    }
}

struct Furniture: Identifiable, Hashable {
    let id: String
    let title: String
    let symbol: String
    let threshold: Int
    let width: Float
    let depth: Float
    let defaultX: Float
    let defaultZ: Float
    var surface: FurnitureSurface = .floor

    var defaultFinish: FurnitureFinish? {
        switch id {
        case "desk": .wood
        case "chair", "lamp", "sofa": .cream
        default: nil
        }
    }

    var topHeight: Float? {
        switch id {
        case "desk": 0.71
        case "sill": 0.41
        default: nil
        }
    }

    static let all: [Furniture] = [
        .init(id: "rug", title: "圆地毯", symbol: "circle", threshold: 0, width: 1.15, depth: 1.15, defaultX: 0, defaultZ: 0.1, surface: .rug),
        .init(id: "plant", title: "绿植", symbol: "leaf", threshold: 1, width: 0.38, depth: 0.38, defaultX: -1.15, defaultZ: 0.25),
        .init(id: "desk", title: "书桌", symbol: "desktopcomputer", threshold: 3, width: 1.15, depth: 0.58, defaultX: -0.65, defaultZ: -1.08),
        .init(id: "chair", title: "椅子", symbol: "chair", threshold: 5, width: 0.42, depth: 0.48, defaultX: -0.65, defaultZ: -0.35),
        .init(id: "lamp", title: "落地灯", symbol: "lamp.floor", threshold: 7, width: 0.35, depth: 0.35, defaultX: 1.17, defaultZ: -1.14),
        .init(id: "sofa", title: "小沙发", symbol: "sofa", threshold: 9, width: 0.75, depth: 1.03, defaultX: 1.0, defaultZ: -0.25),
        .init(id: "sill", title: "窗边矮柜", symbol: "cabinet", threshold: 11, width: 0.7, depth: 0.38, defaultX: -1.0, defaultZ: 1.0),
        .init(id: "easel", title: "画板", symbol: "easel", threshold: 15, width: 0.5, depth: 0.4, defaultX: 0.5, defaultZ: 1.1)
    ] + decorations

    static let decorations: [Furniture] = [
        .init(id: "curtain", title: "窗帘", symbol: "curtains.closed", threshold: 0, width: 2.07, depth: 1.12,
              defaultX: -0.24, defaultZ: 1.04, surface: .windowWall),
        .init(id: "wallArt", title: "墙壁挂画", symbol: "photo", threshold: 0, width: 0.73, depth: 0.55,
              defaultX: -0.22, defaultZ: 1.22, surface: .sideWall),
        .init(id: "wallClock", title: "墙壁挂钟", symbol: "clock", threshold: 0, width: 0.43, depth: 0.43,
              defaultX: 0.67, defaultZ: 1.34, surface: .sideWall),
        .init(id: "books", title: "书本摆件", symbol: "books.vertical", threshold: 0, width: 0.30, depth: 0.15,
              defaultX: -1.04, defaultZ: shelfHeight, surface: .tabletop)
    ]
    static func find(_ id: String) -> Furniture? { all.first { $0.id == id } }

    static let shelfHeight: Float = 1.06

    static func shelfBooks(in placements: [FurniturePlacement]) -> FurniturePlacement? {
        let shelfPositions: [Float] = [-1.04, 0.07, 0.82, -1.15, 1.15, -0.28, 0.43]
        return shelfPositions.lazy.map {
            FurniturePlacement(id: "books", x: $0, z: shelfHeight, turns: 0)
        }.first { canPlace($0, in: placements) }
    }

    static func books(on support: FurniturePlacement?, in placements: [FurniturePlacement]) -> FurniturePlacement? {
        guard let support else { return shelfBooks(in: placements) }
        let offset: Float = support.id == "desk" ? 0.34 : 0
        let candidate = FurniturePlacement(id: "books", x: offset, z: 0, turns: 0, supportID: support.id)
        return canPlace(candidate, in: placements) ? candidate : nil
    }

    static func migrateDecorations(_ placements: [FurniturePlacement]) -> [FurniturePlacement] {
        var layout = placements.filter { $0.id != "smallPlant" && $0.id != "smallRug" }
        if placements.contains(where: { $0.id == "smallPlant" }), !layout.contains(where: { $0.id == "wallClock" }),
           let clock = find("wallClock") {
            let locations: [(Float, Float)] = [(clock.defaultX, clock.defaultZ), (1.14, 1.35), (-1.15, 1.32),
                                               (0.67, 0.67), (-0.67, 0.67)]
            if let replacement = locations.lazy.map({
                FurniturePlacement(id: clock.id, x: $0.0, z: $0.1, turns: 0)
            }).first(where: { canPlace($0, in: layout) }) {
                layout.append(replacement)
            }
        }
        if placements.contains(where: { $0.id == "smallRug" }), !layout.contains(where: { $0.id == "books" }) {
            let support = layout.first { $0.id == "desk" } ?? layout.first { $0.id == "sill" }
            if let replacement = books(on: support, in: layout) {
                layout.append(replacement)
            }
        }
        return layout
    }

    static func canPlace(_ candidate: FurniturePlacement, in placements: [FurniturePlacement]) -> Bool {
        guard let furniture = find(candidate.id), candidate.x.isFinite, candidate.z.isFinite,
              (0...3).contains(candidate.turns),
              candidate.finish == nil || furniture.defaultFinish != nil else { return false }
        if furniture.surface == .tabletop {
            guard candidate.turns == 0 else { return false }
            if let id = candidate.supportID {
                guard placements.contains(where: { $0.id == id }), let support = find(id),
                      support.topHeight != nil else { return false }
                return abs(candidate.x) + furniture.width / 2 <= support.width / 2 - 0.03 &&
                    abs(candidate.z) + furniture.depth / 2 <= support.depth / 2 - 0.03 &&
                    (id != "desk" || candidate.x >= 0.16)
            }
            return abs(candidate.x) <= 1.25 && abs(candidate.z - shelfHeight) < 0.01 &&
                wallHasSpace(itemID: candidate.id, x: candidate.x, y: shelfHeight + 0.09, width: 0.49, height: 0.30,
                             in: placements)
        }
        guard candidate.supportID == nil else { return false }
        if furniture.surface.isWall {
            let halfWidth = furniture.width / 2, halfHeight = furniture.depth / 2
            return candidate.turns == 0 && abs(candidate.x) + halfWidth <= 1.49 &&
                candidate.z - halfHeight >= 0.12 && candidate.z + halfHeight <= 1.78 &&
                (furniture.surface != .sideWall ||
                 wallHasSpace(itemID: candidate.id, x: candidate.x, y: candidate.z,
                              width: furniture.width, height: furniture.depth, in: placements))
        }
        func extent(_ item: Furniture, turns: Int) -> (Float, Float) {
            turns % 2 == 0 ? (item.width / 2, item.depth / 2) : (item.depth / 2, item.width / 2)
        }
        let (halfX, halfZ) = extent(furniture, turns: candidate.turns)
        guard abs(candidate.x) + halfX <= 1.48, abs(candidate.z) + halfZ <= 1.48 else { return false }
        if furniture.surface == .rug { return true }
        for other in placements where other.id != candidate.id {
            guard let item = find(other.id), item.surface == .floor else { continue }
            let (otherX, otherZ) = extent(item, turns: other.turns)
            if abs(candidate.x - other.x) < halfX + otherX + 0.03 &&
                abs(candidate.z - other.z) < halfZ + otherZ + 0.03 { return false }
        }
        // Keep a small space for the otter at the front of the room.
        return !(abs(candidate.x) < halfX + 0.24 && abs(candidate.z - 0.9) < halfZ + 0.20)
    }

    private static func wallHasSpace(itemID: String, x: Float, y: Float, width: Float, height: Float,
                                     in placements: [FurniturePlacement]) -> Bool {
        for other in placements where other.id != itemID {
            if other.id == "books", other.supportID == nil {
                if abs(x - other.x) < (width + 0.49) / 2 &&
                    abs(y - (shelfHeight + 0.09)) < (height + 0.30) / 2 {
                    return false
                }
            } else if let item = find(other.id), item.surface == .sideWall,
                      abs(x - other.x) < (width + item.width) / 2 &&
                      abs(y - other.z) < (height + item.depth) / 2 {
                return false
            }
        }
        return true
    }
}

struct Reward {
    var newActivity: Activity?
    var furniture: [Furniture]
}

struct SessionProgress {
    let duration: Double
    private(set) var elapsed = 0.0
    private(set) var running = false
    private var lastDate: Date?
    var isFinished: Bool { elapsed >= duration }
    var remaining: Int { max(0, Int(ceil(duration - elapsed))) }

    init(seconds: Int) { duration = Double(max(1, seconds)) }
    mutating func resume(at date: Date) {
        guard !isFinished, !running else { return }
        running = true
        lastDate = date
    }
    mutating func tick(at date: Date) {
        guard running, let previous = lastDate else { return }
        elapsed = min(duration, elapsed + max(0, date.timeIntervalSince(previous)))
        lastDate = max(previous, date)
        if isFinished { running = false; lastDate = nil }
    }
    mutating func pause(at date: Date) {
        tick(at: date)
        running = false
        lastDate = nil
    }
    static func clockText(_ seconds: Int) -> String {
        String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }
}
