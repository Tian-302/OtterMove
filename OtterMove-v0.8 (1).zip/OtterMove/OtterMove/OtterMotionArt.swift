import SwiftUI
import UIKit

enum OtterArtwork {
    static let hero = "otter4_hero"
    static let celebration = "otter4_reward"

    static func mood(_ mood: MoodType) -> String { "otter4_mood_" + mood.rawValue }
    static func face(_ mood: MoodType) -> String { "otter7_mood_" + mood.rawValue }

    static func fullBody(_ mood: MoodType) -> String {
        switch mood {
        case .happy: "otter4_mood_excited"
        case .annoyed: "otter4_mood_hardworking"
        case .sad: "otter8_home_sad"
        default: self.mood(mood)
        }
    }

    static func activity(_ activity: Activity) -> String {
        switch activity.id {
        case Activity.careStretch.id: return "otter4_pose_library_shoulders"
        case "outdoor.walk": return "otter4_pose_dorm_walk"
        case "outdoor.wind": return "otter4_pose_dorm_stand"
        case "outdoor.shoulders": return hero
        default: return "otter4_pose_" + activity.id.replacingOccurrences(of: ".", with: "_")
        }
    }

    static func place(_ place: Place) -> String { activity(Activity.list(for: place)[0]) }

    static func image(_ name: String) -> UIImage? {
        UIImage(named: name) ?? UIImage(named: hero) ?? UIImage(named: "OtterIdle")
    }
}

struct OtterArtworkImage: View {
    let name: String

    var body: some View {
        if let image = OtterArtwork.image(name) {
            Image(uiImage: image)
                .resizable()
                .interpolation(.high)
                .scaledToFit()
                .accessibilityHidden(true)
        }
    }
}

/// Rigid-body movement for decorative art outside the exercise demonstrations.
struct OtterMovingThumbnail: View {
    let name: String
    var phase = 0.0
    var amplitude: CGFloat = 1
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        let paused = reduceMotion || scenePhase != .active
        TimelineView(.animation(minimumInterval: 1.0 / 20, paused: paused)) { context in
            let t = context.date.timeIntervalSinceReferenceDate + phase
            let sway = paused ? 0 : sin(t * 1.9)
            OtterArtworkImage(name: name)
                .rotationEffect(.degrees(2.0 * sway * Double(amplitude)), anchor: .bottom)
                .offset(y: -1.5 * CGFloat(sway) * amplitude)
        }
        .accessibilityHidden(true)
    }
}

