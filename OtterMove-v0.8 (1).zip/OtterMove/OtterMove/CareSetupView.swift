import SwiftUI

struct CareSetupView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var health: HealthReference
    @Environment(\.dismiss) private var dismiss
    @State private var enablesGoal = false
    @State private var goal = 4
    @State private var showsSleep = false
    @State private var newHabit = ""
    @State private var habitError = false

    var body: some View {
        NavigationStack {
            Form {
                Section("喝水") {
                    Toggle("设置我的喝水目标", isOn: $enablesGoal)
                    if enablesGoal { Stepper("\(goal) 杯", value: $goal, in: 1...99) }
                    Text("目标由你决定。喝水杯数和打卡都可以手动修改。")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("我的小习惯") {
                    ForEach(store.care.customHabits) { habit in
                        Text(habit.title)
                    }
                    .onDelete { indices in
                        let ids = indices.map { store.care.customHabits[$0].id }
                        for id in ids { store.removeHabit(id) }
                    }
                    TextField("例如：课间走一走", text: $newHabit)
                        .submitLabel(.done)
                        .onSubmit(addHabit)
                    Button("添加习惯", action: addHabit)
                        .disabled(newHabit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }

                Section("可选记录") {
                    Toggle("在首页显示睡眠记录", isOn: $showsSleep)
                }

                Section {
                    if health.enabled {
                        Button("刷新健康参考") { Task { await health.refresh() } }
                        Button("停用健康参考") { health.disable() }
                    } else {
                        Button("连接 Apple 健康") {
                            Task { await health.connect() }
                        }
                        .disabled(health.loading)
                    }
                    if let message = health.message {
                        Text(message).font(.footnote).foregroundStyle(.secondary)
                    }
                    if let steps = health.steps, health.matches(Date()) {
                        LabeledContent("今日步数", value: "\(steps) 步")
                    }
                } header: {
                    Text("Apple 健康")
                } footer: {
                    Text("可选读取饮水、步数和 Apple Watch 的站立记录，仅用于参考。打卡由你确认。")
                }
            }
            .tint(WellnessPalette.sageInk)
            .navigationTitle("打卡设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        if store.configureCare(goal: enablesGoal ? goal : nil, showsSleep: showsSleep) { dismiss() }
                    }
                }
            }
            .onAppear {
                enablesGoal = store.care.waterGoal != nil
                goal = store.care.waterGoal ?? 4
                showsSleep = store.care.showsSleep
            }
            .alert("暂时无法添加", isPresented: $habitError) {
                Button("好的", role: .cancel) {}
            } message: {
                Text("请用不重复的名称，最多 24 个字。可以添加 12 项习惯。")
            }
        }
    }

    private func addHabit() {
        if store.addHabit(newHabit) { newHabit = "" }
        else if store.errorMessage == nil { habitError = true }
    }
}

struct SleepEntryView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let day: Date
    @State private var hours = 7.0

    var body: some View {
        NavigationStack {
            Form {
                Stepper(value: $hours, in: 0...24, step: 0.5) {
                    Text("约 \(hours.formatted(.number.precision(.fractionLength(0...1)))) 小时")
                }
                if store.careDay(on: day).sleepHours != nil {
                    Button("移除今天的睡眠记录", role: .destructive) {
                        if store.setSleep(nil, on: day) { dismiss() }
                    }
                }
            }
            .tint(WellnessPalette.sageInk)
            .navigationTitle("记录睡眠")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { if store.setSleep(hours, on: day) { dismiss() } }
                }
            }
            .onAppear { hours = store.careDay(on: day).sleepHours ?? 7 }
        }
        .presentationDetents([.medium, .large])
    }
}
