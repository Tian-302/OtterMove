import Foundation

struct MoodRecord: Codable, Identifiable {
    let id: UUID
    let date: Date
    let mood: MoodType
    let summary: String

    init(id: UUID, date: Date, mood: MoodType, summary: String) {
        self.id = id
        self.date = date
        self.mood = mood
        self.summary = summary
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(UUID.self, forKey: .id)
        date = try values.decode(Date.self, forKey: .date)
        let stored = try values.decode(String.self, forKey: .mood)
        switch stored {
        case "hardworking":
            mood = .tired
            summary = MoodType.tired.summaries[0]
        case "excited":
            mood = .happy
            summary = try values.decode(String.self, forKey: .summary)
        default:
            mood = try values.decode(MoodType.self, forKey: .mood)
            summary = try values.decode(String.self, forKey: .summary)
        }
    }
}
